/***********************************************************************
* Program:
*    Checkpoint 08a, Inheritance
*    Brother Burton, CS165
* Author:
*    Conner Charles
* Summary: 
*    Summaries are not necessary for checkpoint assignments.
* ***********************************************************************/

#include <iostream>
#include <string>
using namespace std;

// For this assignment, for simplicity, you may put all of your classes
// in this file.

// TODO: Define your Book class here
class Book
{  
private:
   string title;
   string author;
   int publicationYear;

public:
   // Getters
   string getTitle() const { return title; }
   string getAuthor() const { return author; }
   int getPubYear() const { return publicationYear; }
   
   // Setters
   void setTitle(string title)
   {
      this->title = title;
   }
   
   void setAuthor(string author)
   {
      this->author = author;
   }
   
   void setPubYear(int publicationYear)
   {
      this->publicationYear = publicationYear;
   }

   
   void promptBookInfo()
   {
      cout << "Title: ";
      getline(cin, title);

      cout << "Author: ";
      getline(cin, author);

      cout << "Publication Year: ";
      cin >> publicationYear;
      cin.ignore();
   }

   void displayBookInfo() const
   {
      cout << endl << title << " (" << publicationYear << ")";
      cout << " by " << author << endl;
   }
   
};

// TODO: Define your TextBook class here
class TextBook : public Book
{
private:
   string subject;

public:
   string getSubject() const { return subject; }

   void setSubject(string subject)
   {
      this->subject = subject;
   }

   void promptSubject()
   {
      cout << "Subject: ";
      getline(cin, subject);
   }

   void displaySubject() const
   {
      cout << "Subject: " << subject << endl << endl;
   }
   
};

// TODO: Add your PictureBook class here
class PictureBook : public Book
{
private:
   string illustrator;

public:
   string getIllustrator() const { return illustrator; }

   void setIllustrator(string illustrator)
   {
      this->illustrator = illustrator;
   }

   void promptIllustrator()
   {
      cout << "Illustrator: ";
      getline(cin, illustrator);
   }

   void displayIllustrator() const
   {
      cout << "Illustrated by " << illustrator << endl;
   }
};

/**********************************************************************
 * Function: main
 * Purpose: This is the entry point and driver for the program.
 ***********************************************************************/
int main()
{
   // Declare a Book object here and call its methods
   Book book;

   book.promptBookInfo();
   book.displayBookInfo();
   cout << endl;
   // Declare a TextBook object here and call its methods
   TextBook textBook;

   textBook.promptBookInfo();
   textBook.promptSubject();
   textBook.displayBookInfo();
   textBook.displaySubject();
   
   // Declare a PictureBook object here and call its methods
   PictureBook pictureBook;

   pictureBook.promptBookInfo();
   pictureBook.promptIllustrator();
   pictureBook.displayBookInfo();
   pictureBook.displayIllustrator();

   return 0;
}


