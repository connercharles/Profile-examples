/*******************
 * smartphone.cpp
 *******************/

#include "smartphone.h"
#include <iostream>

using namespace std;

// TODO: Put your SmartPhone methods here
void SmartPhone::prompt()
{
   promptNumber();

   cout << "Email: ";
   cin >> email;
}

void SmartPhone::display() const
{
   Phone::display();

   cout << getEmail() << endl;   
}
