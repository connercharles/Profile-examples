/****************
 * smartphone.h
 ****************/

#ifndef SMARTPHONE_H
#define SMARTPHONE_H

#include "phone.h"
#include <string>

// TODO: Put your SmartPhone definition here
class SmartPhone : public Phone
{
  private:
   std::string email;

  public:
   std::string getEmail() const { return email; }
   void setEmail(std::string email) { this->email = email; }

   void prompt();
   void display() const;
};

#endif
