/***************
 * phone.h
 ***************/

#ifndef PHONE_H
#define PHONE_H

// TODO: Put your phone class definition here...
class Phone
{
  private:
   int areaCode;
   int prefix;
   int suffix;
   
  public:
   int getAreaCode() const { return areaCode; }
   int getPrefix() const { return prefix; }
   int getSuffix() const { return suffix; }

   void setAreaCode(int areaCode) { this->areaCode = areaCode; }
   void setPrefix(int prefix) { this->prefix = prefix; }
   void setSuffix(int suffix) { this->suffix = suffix; }
   
   void promptNumber();
   void display() const;
};


#endif
