#ifndef CIRCLE_H
#define CIRCLE_H

#include "point.h"

class Circle : public Point
{
  private:
   float radius;
   
  public:
   float getRadius() const { return radius; }

   void setRadius(float radius);

   void promptForCircle();
   void display() const;
};


#endif
