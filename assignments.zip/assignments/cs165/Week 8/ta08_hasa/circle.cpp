#include "circle.h"
#include <iostream>

using namespace std;

void Circle::setCenter(Point center)
{
   this->center = center;
}

void Circle::setRadius(float radius)
{
   this->radius = radius;
}

void Circle::promptForCircle()
{
   center.promptForPoint();
   cout << "Radius: ";
   cin >> radius;
}

void Circle::display() const
{
   center.display();
   cout << " - Radius: " << getRadius() << endl;
}
