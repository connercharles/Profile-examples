#ifndef CIRCLE_H
#define CIRCLE_H

#include "point.h"

class Circle
{
  private:
   Point center;
   float radius;
   
  public:
   Point getCenter() const { return center; }
   float getRadius() const { return radius; }

   float getX() const { return center.getX(); }

   void setCenter(Point center);
   void setRadius(float radius);

   void promptForCircle();
   void display() const;
};

#endif
