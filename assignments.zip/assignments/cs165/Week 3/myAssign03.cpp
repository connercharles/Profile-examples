/***********************************************************************
* Program:
*    Assignment 03, Digital Forensics with Corrupt Files      
*    Brother Burton, CS165
* Author:
*    Conner Charles
* Summary: 
*    This program will prompt the user for a file name, then using that
*    it will read in the data in that file. If there are files that are
*    corrupted, then it will give an error message and skip that
*    information. It will then ask for a start and end time. Using
*    these times, it will sort through the data and display any files
*    that were accessed during that time period. 
*
*    Estimated:  3.0 hrs   
*    Actual:     2.0 hrs
*      I'm still super confused with the syntax of using throws and
*      catches. But after a while it seems I did it right.
************************************************************************/

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>

using namespace std;

const int COLUMN1 = 15;
const int COLUMN2 = 20;
const int COLUMN3_HEADER = 21;
const int COLUMN3_BODY = 20;
const long int MIN_TIME = 1000000000;
const long int MAX_TIME = 10000000000;

/**********************************************************************
 * Struct: AccessRecord
 * Purpose: Way to keep track of all the information in the files that
 * will be read in.
 ************************************************************************/
struct AccessRecord
{
   string userName;
   string fileName;
   long int timeStamp;
};

/**********************************************************************
 * Function: promptFile
 * Purpose: Prompts user for the file name, then it returns it.
 ***********************************************************************/
string promptFile()
{
   cout << "Enter the access record file: ";
   string file;
   cin >> file;
   
   return file;
}

/***********************************************************************
 * Function: parseLine
 * Purpose: Receives a line and parses it into the Access Record, if
 * there are an errors, it will display an error message. If there are
 * no errors, then it adds it to the vector.
 ************************************************************************/
void parseLine(vector<AccessRecord> &records, const string &line)
throw (string)
{
      istringstream ss(line);
      AccessRecord input;
      ss >> input.fileName >> input.userName >> input.timeStamp;

      // Error handling
      if (ss.fail() || input.timeStamp < MIN_TIME
          || input.timeStamp > MAX_TIME)
      {
         throw string("Error parsing line: ");
      }
      else
      {
         records.push_back(input);
      }
}

/***********************************************************************
 * Function: parseFile
 * Purpose: Reads in list of Access Records form the file and store it
 * in a vector.
 ************************************************************************/
int parseFile(vector<AccessRecord> &records)
{
   string file;
   file = promptFile();

   ifstream inFile(file.c_str());

   if (inFile.fail())
   {
      cout << "Error opening file." << endl;
      return -1;
   }
   
   string line;
   
   while (getline(inFile, line))
   {
      try
      {
         parseLine(records, line);
      }
      catch (string message)
      {
         cout << message << line << endl;
      }
   }

   inFile.close();

   return 0;
}

/**********************************************************************
 * Function: promptTime
 * Purpose: Prompts user for a start time and an end time. 
************************************************************************/
void promptTime(long int &startTime, long int &endTime)
{
   cout << endl;
   cout << "Enter the start time: ";
   cin >> startTime;

   cout << "Enter the end time: ";
   cin >> endTime;
   cout << endl;
}

/**********************************************************************
 * Function: displayRecord
 * Purpose: Reads through the records and displays the files and the
 * users that accessed them between the start and end times.
************************************************************************/
void displayRecord(const vector<AccessRecord> &records,
                   const long int &startTime, const long int &endTime)
{
   cout << "The following records match your criteria:\n\n";
   cout << setw(COLUMN1) << "Timestamp";
   cout << setw(COLUMN2) << "File";
   cout << setw(COLUMN3_HEADER) << "User\n";
   cout << "--------------- ------------------- -------------------\n";

   for (int i = 0; i < records.size(); i++)
   {
      if (records[i].timeStamp >= startTime &&
          records[i].timeStamp <= endTime)
      {
         cout << setw(COLUMN1) << records[i].timeStamp;
         cout << setw(COLUMN2) << records[i].fileName;
         cout << setw(COLUMN3_BODY) << records[i].userName << endl;
      }
   }

   cout << "End of records" << endl;
}

/**********************************************************************
 * Function: main
 * Purpose: Creates a vector of records and prompts the user for a
 * file record, then reads in the file, storing that data into the
 * vector. Then it prompts the user for a start time and an end time.
 * Using those times, it displays any file entries that happened between
 * those times.
 ***********************************************************************/
int main()
{
   vector<AccessRecord> records;
   long int startTime;
   long int endTime;

   parseFile(records);
   promptTime(startTime, endTime);
   displayRecord(records, startTime, endTime);
   
   return 0;
}
