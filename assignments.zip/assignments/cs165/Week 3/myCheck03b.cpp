/***********************************************************************
* Program:
*    Checkpoint 03b, Errors
*    Brother Burton, CS165
* Author:
*    Conner Charles
* Summary: 
*       
************************************************************************/

#include <iostream>
using namespace std;

int prompt()
{
   int userNum;

   while (true)
   {
      cout << "Enter a number: ";
      cin >> userNum;

      // Error check
      if (cin.fail())
      {
         cin.clear();
         cin.ignore(1000, '\n');
         cout << "Invalid input." << endl;
      }
      else
      {
         break;
      }
   }
   return userNum;
}

/**********************************************************************
 * Function: main
 * Purpose:
 ***********************************************************************/
int main()
{
   int number = prompt();

   cout << "The number is " << number << "." << endl;
   
   
   return 0;
}
