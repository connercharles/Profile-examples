/***********************************************************************
* Program:
*    Checkpoint 03a, Exceptions
*    Brother Burton, CS165
* Author:
*    Conner Charles
* Summary: 
*       
************************************************************************/

#include <iostream>

using namespace std;

const int LOWER_LIMIT = 0;
const int UPPER_LIMIT = 100;

int prompt()
{
   int userNum;

   while (true)
   {
      cout << "Enter a number: ";
      cin >> userNum;

      // Error check
      if (cin.fail())
      {
         cin.clear();
         cin.ignore(1000, '\n');
         cout << "Invalid input." << endl;
      }
      else
      {
         break;
      }
   }
   return userNum;
}

//***********
//what exactly does throwing and catching do? how do you impliment it??
//***********
void checkNumber(int number, bool &error)
{
   try
   {
      if (number < LOWER_LIMIT)
      {
         throw string("The number cannot be negative.");
      }
      else if (number > UPPER_LIMIT)
      {
         throw string("The number cannot be greater than 100.");
      }
      // If number is odd.
      else if (number % 2 == 1)
      {
         throw string("The number cannot be odd.");
      }
   }
   catch (string message)
   {
      error = true;
      cout << "Error: " << message << endl;
   }
}

/**********************************************************************
 * Function: main
 * Purpose:
 ***********************************************************************/
int main()
{
   bool error = false;
   int number = prompt();
   checkNumber(number, error);
   
   if (!error)
   {
   cout << "The number is " << number << "." << endl;
   }
   
   return 0;
}
