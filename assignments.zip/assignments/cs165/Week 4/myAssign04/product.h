/***************************************************************
 * File: product.h
 * Author: Conner Charles
 * Purpose: Keeps track of the product that the user inputs.
 * Class can display product information in a variety of ways.
 ***************************************************************/
#ifndef PRODUCT_H
#define PRODUCT_H

#include <string>

// put your class definition here

class Product
{
  public:
   std::string name;
   float basePrice;
   float weight;
   std::string desc; // desc = description

   // Book Keeping
   static const float TAX = .06;
   static const int MIN_WEIGHT = 5;
   static const float SHIPPING_BASE = 2.00;
   static const float SHIPPING_ADD_ON = .10;

   // Setters
   void setName(std::string name);
   void setBasePrice(float basePrice);
   void setWeight(float weight);
   void setDesc(std::string desc);

   void prompt();

   // Getters
   float getSalesTax();
   float getShippingCost();
   float getTotalPrice();

   // Displays
   void displayAd();
   void displayInventory();
   void displayReceipt();

   bool errorHandling(float numberInput);
};


#endif
