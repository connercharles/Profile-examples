/***************************************************************
 * File: product.cpp
 * Author: Conner Charles
 * Purpose: Contains the method implementations for the Product class.
 ***************************************************************/

#include "product.h"
#include <iostream>
#include <iomanip>

using namespace std;

// put your method bodies here

/***************************************************************
 * Method: setName
 * Purpose: Sets the passed in name as the product's name.
*****************************************************************/
void Product :: setName(string name)
{
   this->name = name;
}

/***************************************************************
 * Method: setBasePrice
 * Purpose: Sets the passed in price as the product's price.
 *****************************************************************/
void Product :: setBasePrice(float basePrice)
{
   this->basePrice = basePrice;
}

/***************************************************************
 * Method: setWeight
 * Purpose: Sets the passed in weight as the product's weight.
 *****************************************************************/
void Product :: setWeight(float weight)
{
   this->weight = weight;
}

/***************************************************************
 * Method: setDesc
 * Purpose: Sets the passed in description as the product's
 * description.
 *****************************************************************/
void Product :: setDesc(string desc)
{
   this->desc = desc;
}

/***************************************************************
 * Method: errorHandling
 * Purpose: Checks to see if user inputted invalid input. Like
 * negative numbers and words for numbers.
 *****************************************************************/
bool Product :: errorHandling(float numberInput)
{
   if (cin.fail())
   {
      cin.clear();
      cin.ignore(1000, '\n');
      return true;
   }
   else if (numberInput < 0) // To check if it's negative
   {
      return true;
   }
   
   return false;
}

/***************************************************************
 * Method: prompt
 * Purpose: Asks the user for product information, reprompts the
 * user if invalid input, then stores that information.
 *****************************************************************/
void Product :: prompt()
{
   string name;
   cout << "Enter name: ";
   getline(cin, name);
   
   string desc;
   cout << "Enter description: ";
   getline(cin, desc);   
  
   float weight;
   
   do
   {
      cout << "Enter weight: ";
      cin >> weight;
   }
   while (errorHandling(weight));
   
   float basePrice;
      
   do
   {
      cout << "Enter price: ";
      cin >> basePrice;
   }
   while (errorHandling(basePrice));
   
   setName(name);
   setDesc(desc); 
   setWeight(weight);     
   setBasePrice(basePrice);
}

/***************************************************************
 * Method: getSalesTax
 * Purpose: Returns the computed sales tax.
 *****************************************************************/
float Product :: getSalesTax()
{
   return basePrice * TAX;
}

/***************************************************************
 * Method: getShippingCost
 * Purpose: Computes shipping cost based on the weight, then
 * returns it. 
 *****************************************************************/
float Product :: getShippingCost()
{
   if (weight < MIN_WEIGHT)
   {
      return  SHIPPING_BASE;
   }
   else
   {
      int weightChange;
      weightChange = weight - MIN_WEIGHT;

      float add_on = weightChange * SHIPPING_ADD_ON;
      return  SHIPPING_BASE + add_on;
   }
}

/***************************************************************
 * Method: getTotalPrice
 * Purpose: Adds up the base price, sales tax, and the shipping
 * cost. Then returns it.
 *****************************************************************/
float Product :: getTotalPrice()
{
   return basePrice + getSalesTax() + getShippingCost();
}

/***************************************************************
 * Method: displayAd
 * Purpose: Displays product information in advertisement format.
 *****************************************************************/
void Product :: displayAd()
{
   cout << name << " - $" << basePrice << endl;
   cout << "(" << desc << ")" << endl;
}

/***************************************************************
 * Method: displayInvntory
 * Purpose: Displays inventory product information.
 *****************************************************************/
void Product :: displayInventory()
{
   
   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2);
   
   cout << "$" << basePrice << " - " << name;
   cout << " - ";
   cout << fixed << setprecision(1) << weight;
   cout << " lbs" << endl;
}

/***************************************************************
 * Method: displayReceipt
 * Purpose: Displays product information as a receipt.
 *****************************************************************/
void Product :: displayReceipt()
{
   cout << name << endl;

   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2);

   cout << "  Price:         $" << setw(8) << basePrice << endl;
   cout << "  Sales tax:     $" << setw(8) << getSalesTax() << endl;
   cout << "  Shipping cost: $" << setw(8) << getShippingCost() << endl;
   cout << "  Total:         $" << setw(8) << getTotalPrice() << endl;      
}
