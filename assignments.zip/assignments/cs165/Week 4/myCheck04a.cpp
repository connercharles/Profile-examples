/***********************************************************************
 * Program:
 *    Checkpoint 04a, Classes
 *    Brother Burton, CS165
 * Author:
 *    Conner Charles
 * Summary:
 *
 ************************************************************************/
#include <iostream>

using namespace std;

class Book
{
public:
   string title;
   string author;

   void prompt()
   {
      cout << "Title: ";
      getline(cin, title);

      cout << "Author: ";
      getline(cin, author);
   }

   void display()
   {
      cout << "\"" << title << "\" by " << author << endl;
   }
};


int main()
{
   Book userBook;
   userBook.prompt();
   userBook.display();
   
   return 0;
}
