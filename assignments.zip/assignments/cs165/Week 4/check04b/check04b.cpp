/*********************************************************************
 * File: check04b.cpp
 * Purpose: contains the main method to exercise the Date class.
 *********************************************************************/

#include "date.h"

#include <iostream>
using namespace std;


int main()
{
   int userMonth;
   int userDay;
   int userYear;
   // prompt for month, day, year
   cout << "Month: ";
   cin >> userMonth;

   cout << "Day: ";
   cin >> userDay;

   cout << "Year: ";
   cin >> userYear;

   cout << endl;
   
   // create a Date object
   Date userDate;
   
   // set its values
   userDate.set(userMonth, userDay, userYear);
   
   // call each display function
   userDate.displayAmerican();
   userDate.displayEuropean();
   userDate.displayISO();

   return 0;
}
