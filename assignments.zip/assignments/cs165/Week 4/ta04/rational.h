/***************************************************************
 * File: rational.h
 * Author: (your name here)
 * Purpose: Contains the definition of the Rational class
 ***************************************************************/
#ifndef RATIONAL_H
#define RATIONAL_H

#include <iostream>

using namespace std;

// put your class definition here

class Rational
{
  public:
   int top;
   int bottom;

   void prompt();
   void display();
   void displayDec();
   void mixedNum();
   void multiplyBy();
   void reduce();
};


#endif
