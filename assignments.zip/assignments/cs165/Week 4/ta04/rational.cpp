/***************************************************************
 * File: rational.cpp
 * Author: (your name here)
 * Purpose: Contains the method implementations for the Rational class.
 ***************************************************************/

#include "rational.h"

// put your method bodies here

void Rational::prompt()
{
   cout << "Top: ";
   cin >> top;

   cout << "Bottom: ";
   cin >> bottom;
}

void Rational::display()
{
   cout << top << "/" << bottom << endl;
}

void Rational::displayDec()
{
   float decimal;
   decimal = (float)top / (float)bottom;

   cout << decimal << endl;
}

void Rational::mixedNum()
{
   if (top > bottom)
   {
      int mixedNumber = 0;
      mixedNumber = top / bottom;

      int topRem;
      topRem = top % bottom;

      top = topRem;

      cout << mixedNumber << " ";
      display();
   }
}

void Rational::multiplyBy()
{
   int multTop;
   cout << "Multiply by top: ";
   cin >> multTop;

   int multBottom;
   cout << "Multiply by bottom: ";
   cin >> multBottom;

   top = top * multTop;
   bottom = bottom * multBottom;
}

void Rational::reduce()
{
   for (int i = 2; i < 20; i++)
   {
      if (top % i == 0 && bottom % i == 0)
      {
         top /= i;
         bottom /= i;
      }
   }
}
