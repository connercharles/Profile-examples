/***********************************************************************
* Program:
*    Checkpoint 02a, Structs  
*    Brother Burton, CS165
* Author:
*    Conner Charles
* Summary: 
*    Summaries are not necessary for checkpoint assignments.
* ***********************************************************************/

#include <iostream>
using namespace std;

struct user
{
   string firstName;
   string lastName;
   int id;
};

/**********************************************************************
 * Function: getUserInfo
 * Purpose: Prompts user to enter information for the struct user.
 ***********************************************************************/
user getUserInfo()
{
   user student;
   cout << "Please enter your first name: ";
   cin >> student.firstName;

   cout << "Please enter your last name: ";
   cin >> student.lastName;

   cout << "Please enter your id number: ";
   cin >> student.id;

   return student;
}

/**********************************************************************
 * Function: displayStudent
 * Purpose: displays user information that was previously entered.
************************************************************************/
void displayStudent(user student)
{
   cout << endl << "Your information:" << endl;
   cout << student.id << " - " << student.firstName << " ";
   cout << student.lastName << endl;
}

/**********************************************************************
 * Function: main
 * Purpose: This is the entry point and driver for the program.
 ***********************************************************************/
int main()
{
   user student;
   student = getUserInfo();
   displayStudent(student);
   return 0;
}
