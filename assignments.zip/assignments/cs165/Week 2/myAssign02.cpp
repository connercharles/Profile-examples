/***********************************************************************
* Program:
*    Assignment 02, Digital Forensics       
*    Brother Burton, CS165
* Author:
*    Conner Charles
* Summary: 
*    This program will prompt the user for a file name, then using that
*    it will read in the data in that file. It will then ask for a
*    start and end time. Using these times, it will sort through the
*    data and display any files that were accessed during that time
*    period.
*
*    Estimated:  4.0 hrs   
*    Actual:     4.0 hrs
*      The most difficult part was probably figuring out the display
*      that the testbed wanted when I displayed the files (using setw()).
*      Also, the style checker is telling me to put white space between
*      the < > 's of the vector, do you care that much about it? I
*      personally like not having white space there, but I can change it
*      if it's a specific style you guys like.
************************************************************************/

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <iomanip>

using namespace std;

const int COLUMN1 = 15;
const int COLUMN2 = 20;
const int COLUMN3_HEADER = 21;
const int COLUMN3_BODY = 20;

/**********************************************************************
 * Struct: AccessRecord
 * Purpose: Way to keep track of all the information in the files that
 * will be read in.
 ************************************************************************/
struct AccessRecord
{
   string userName;
   string fileName;
   long int timeStamp;
};

/**********************************************************************
 * Function: promptFile
 * Purpose: Prompts user for the file name, then it returns it.
 ***********************************************************************/
string promptFile()
{
   cout << "Enter the access record file: ";
   string file;
   cin >> file;
   cout << endl;
   
   return file;
}

/***********************************************************************
 * Function: readFile
 * Purpose: Reads in list of Access Records form the file and store it
 * in a vector.
 ************************************************************************/
void readFile(vector<AccessRecord> &records)
{
   string file;
   file = promptFile();

   ifstream inFile(file.c_str());
   string line;
   
   while (getline(inFile, line))
   {
      istringstream ss(line);
      AccessRecord input;
      ss >> input.fileName >> input.userName >> input.timeStamp;
      records.push_back(input);
   }

   inFile.close();
}

/**********************************************************************
 * Function: promptTime
 * Purpose: Prompts user for a start time and an end time. 
 ************************************************************************/
void promptTime(long int &startTime, long int &endTime)
{
   cout << "Enter the start time: ";
   cin >> startTime;

   cout << "Enter the end time: ";
   cin >> endTime;
   cout << endl;
}

/**********************************************************************
 * Function: displayRecord
 * Purpose: Reads through the records and displays the files and the
 * users that accessed them between the start and end times.
************************************************************************/
void displayRecord(const vector<AccessRecord> &records,
                   const long int &startTime, const long int &endTime)
{
   cout << "The following records match your criteria:\n\n";
   cout << setw(COLUMN1) << "Timestamp";
   cout << setw(COLUMN2) << "File";
   cout << setw(COLUMN3_HEADER) << "User\n";
   cout << "--------------- ------------------- -------------------\n";

   for (int i = 0; i < records.size(); i++)
   {
      if (records[i].timeStamp >= startTime &&
          records[i].timeStamp <= endTime)
      {
         cout << setw(COLUMN1) << records[i].timeStamp;
         cout << setw(COLUMN2) << records[i].fileName;
         cout << setw(COLUMN3_BODY) << records[i].userName << endl;
      }
   }

   cout << "End of records" << endl;
}

/**********************************************************************
 * Function: main
 * Purpose: Creates a vector of records and prompts the user for a
 * file record, then reads in the file, storing that data into the
 * vector. Then it prompts the user for a start time and an end time.
 * Using those times, it displays any file entries that happened between
 * those times.
 ***********************************************************************/
int main()
{
   vector<AccessRecord> records;
   long int startTime;
   long int endTime;
   
   readFile(records);
   promptTime(startTime, endTime);
   displayRecord(records, startTime, endTime);
   
   return 0;
}
