#include <iostream>
#include <string>
#include <istream>

using namespace std;

struct Scripture
{
   string bookName;
   int chap;
   int verse;
};

void promptScripture(Scripture s[], int i)
{
   cout << "Book: ";
   getline(cin, s[i].bookName);

   cout << "Chapter: ";
   cin >> s[i].chap;

   cout << "Verse: ";
   cin >> s[i].verse;
   cin.ignore();
}

void displayScripture(const Scripture s[], int i)
// const so it's a constant reference so it will not change it throughout the whole funciton.
{
   cout << s[i].bookName << " " << s[i].chap << ":" << s[i].verse << endl;
}

int main()
{
   Scripture s[3];
   for (int i = 0; i < 3; i++)
   {
      promptScripture(s, i);
      displayScripture(s, i);
   }
   
   return 0;
}
