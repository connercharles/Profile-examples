/***********************************************************************
* Program:
*    Checkpoint 02b, Complex Numbers
*    Brother Burton, CS165
* Author:
*    Conner Charles
* Summary: 
*    Summaries are not necessary for checkpoint assignments.
* ***********************************************************************/

#include <iostream>
#include <sstream>
using namespace std;

// TODO: Define your Complex struct here
struct Complex
{
   double realNum;
   double imagNum;
};

// TODO: Add your prompt function here
/*********************************************************************
 * Function: prompt
 * Purpose: Prompts user for input regarding real and imaginary nummbers.
 **********************************************************************/
void prompt(Complex & number)
{
   cout << "Real: ";
   cin >> number.realNum;
   cout << "Imaginary: ";
   cin >> number.imagNum;
}

// TODO: Add your display function here
/*********************************************************************
 * Function: display
 * Purpose: Reads in a number and displays it in the given format.
 **********************************************************************/
string display(Complex number)
{
   stringstream ss;
   ss << number.realNum << " + " << number.imagNum;
   ss << "i";
   return ss.str();
}

/**********************************************************************
 * Function: addComplex
 * Purpose: Adds two complex numbers together and returns the sum.
 ***********************************************************************/
Complex addComplex(const Complex & x, const Complex & y)
{
   // TODO: Fill in the body of the add function
   Complex newNum;
   newNum.realNum = x.realNum + y.realNum;
   newNum.imagNum = x.imagNum + y.imagNum;

   return newNum;

}

/**********************************************************************
 * Function: main
 * Purpose: This is the entry point and driver for the program.
 ***********************************************************************/
int main()
{
   // Declare two Complex objects, c1 and c2
   Complex c1;
   Complex c2;

   // Call your prompt function twice to fill in c1, and c2 
   prompt(c1);
   prompt(c2);

   // Declare another Complex for the sum
   Complex sum;

   // Call the addComplex function, putting the result in sum;
   sum = addComplex(c1, c2);
   
   cout << "\nThe sum is: ";
   cout << display(sum);
   cout << endl;
   
   return 0;
}


