/***********************************************************************
* Source File:
*    SHIP : A representation of what the user will use to play the game
* Author:
*    Conner Charles
* Summary:
*	This is the ship class where it is what the user moves around to
*	play the game. This ship can move left and right, and thrust forward
*	and it has a shotgun capability.
************************************************************************/

#include "ship.h"
#include "uiDraw.h"

#define _USE_MATH_DEFINES
#include <math.h> // used for sin, cos, and M_PI

const int BOOM_LIMIT = 3;

/***************************************
* SHIP :: CONSTRUCTOR
* Sets member variables to default values.
***************************************/
Ship::Ship()
{
	setRadius(10);
	setBoost(false);
	setSize(SHIP_SIZE);
	setDirection(0);
	setSonicBoom(BOOM_LIMIT);
}

/***************************************
* SHIP :: BOOM
* Decraments the ship's sonicboom value
***************************************/
void Ship::boom()
{
	sonicBoom--;
}

/***************************************
* SHIP :: DRAW
* Draws a ship...as easy as rocket science
***************************************/
void Ship::draw() const
{
	drawShip(position, direction, boost);
}

/***************************************
* SHIP :: TURN LEFT
* Moves the ship left
***************************************/
void Ship::turnLeft()
{
	setDirection(direction + ROTATE_AMOUNT);
}

/***************************************
* SHIP :: TURN RIGHT
* Moves the ship right
***************************************/
void Ship::turnRight()
{
	setDirection(direction - ROTATE_AMOUNT);
}

/***************************************
* SHIP :: THRUST
* Moves the ship forward
***************************************/
void Ship::thrust()
{
	setBoost(true);

	velocity.addOntoDx(-THRUST_AMOUNT * (sin(M_PI / 180.0 * direction)));
	velocity.addOntoDy(-THRUST_AMOUNT * (-cos(M_PI / 180.0 * direction)));
}
