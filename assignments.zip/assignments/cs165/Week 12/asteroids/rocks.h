/***********************************************************************
* Header File:
*    ROCKS : Representation of the different asteroids in the game
* Author:
*    Conner Charles
* Summary:
*	This is the .h for all the rock class methods. The base class rock
*	has a have some basic things for each rock. Big Rock has a break
*	apart function that is specific for itself. The Medium Rock has the
*	same thing, just for them. Small Rock has nothing really special.
************************************************************************/

#ifndef rocks_h
#define rocks_h

#define BIG_ROCK_SIZE 16
#define MEDIUM_ROCK_SIZE 8
#define SMALL_ROCK_SIZE 4

#define BIG_ROCK_SPIN 2
#define MEDIUM_ROCK_SPIN 5
#define SMALL_ROCK_SPIN 10

#include "flyingObject.h"
#include "point.h"
#include <list>

/**************************************
* Rock Class
* The initial class for all rocks in the game.
* This class cannot be instantiated.
***************************************/
class Rock : public FlyingObject
{
protected:
	int rotation;

	void fly(float speed);

public:
	Rock();

	// Getters
	int getRotation() const { return rotation; }

	// Setters
	void setRotation(int rotation) { this->rotation = rotation; }

	virtual void breakApart(std::list<Rock*> &rocks) = 0;
	virtual void draw() const = 0;
};

/**************************************
* Big Rock Class
* The class for the biggest of rocks.
***************************************/
class BigRock : public Rock
{
private:

public:
	BigRock(Point);

	virtual void breakApart(std::list<Rock*> &rocks);
	virtual void draw() const;
	virtual void advance();
};

/**************************************
* Medium Rock Class
* The class for the average sized rocks.
***************************************/
class MediumRock : public Rock
{
private:

public:
	MediumRock(Point);

	virtual void breakApart(std::list<Rock*> &rocks);
	virtual void draw() const;
	virtual void advance();
};

/**************************************
* Small Rock Class
* The class for the smallest of rocks.
***************************************/
class SmallRock : public Rock
{
private:

public:
	SmallRock(Point);

	virtual void breakApart(std::list<Rock*> &rocks) {} // does nothing
	virtual void draw() const;
	virtual void advance();
};

#endif /* rocks_h */
