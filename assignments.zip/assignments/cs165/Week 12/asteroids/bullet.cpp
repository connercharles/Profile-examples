/***********************************************************************
* Source File:
*    BULLET : This is a class that represents the objects that the user
* shoots to hit the asteroids
* Author:
*   Conner Charles
* Summary:
* 	 This class cannot do anything other than have a bullet shot at a
*	 specific velocity and the direction of the ship shooting.
************************************************************************/

#include <math.h> // used for sin, cos, and M_PI
#define _USE_MATH_DEFINES
const float BULLET_SPEED = 5.0;
//float angle = 60.0;

const int BULLET_LIFE = 40;

#include "bullet.h"
#include "ship.h"

/******************************************
* BULLET : CONSTRUCTOR
* Sets the ship with default values
*****************************************/
Bullet::Bullet(Ship &ship)
{
	setPosition(ship.getPosition());
	setAlive(true);
	setFrameLife(BULLET_LIFE);
	setVelocity(ship.getVelocity());
	setSize(1);

	// Gets the velocity according to ship's current direction
	shoot(ship.getDirection());
}

/******************************************
* BULLET : CONSTRUCTOR
* Sets the ship with default values, then using passed 
* in orienation to the velocity instead of the ship's direction
*****************************************/
Bullet::Bullet(Ship &ship, int orientation)
{
	setPosition(ship.getPosition());
	setAlive(true);
	setFrameLife(BULLET_LIFE);
	setVelocity(ship.getVelocity());
	setSize(1);

	// Gets the velocity according to ship's current direction
	shoot(ship.getDirection() + orientation);
}

/******************************************
* BULLET : DESTRUCTOR
* Does so much
*****************************************/
Bullet::~Bullet()
{
}

/******************************************
* BULLET : SHOOT
* Takes the passed in angle and sets the velocity
* according to the angle
*****************************************/
void Bullet::shoot(float angle)
{
	// Sets bullet's velocity
	velocity.addOntoDx( -BULLET_SPEED * (sin(M_PI / 180.0 * angle)));
	velocity.addOntoDy( -BULLET_SPEED * (-cos(M_PI / 180.0 * angle)));
}

/******************************************
* BULLET : DRAW
* Draws a dot
*****************************************/
void Bullet::draw() const
{
	drawDot(position);
}

/******************************************
* BULLET : ADVANCE
* Normal advance function except it decraments 
* the life of the bullet and eventually kills it
*****************************************/
void Bullet::advance()
{
	FlyingObject::advance();

	frameLife--;

	if (frameLife == 0)
	{
		kill();
	}
}
