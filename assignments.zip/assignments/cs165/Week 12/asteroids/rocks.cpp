/***********************************************************************
* Source File:
*   ROCKS : The representation of the different asteroids in the game
* Author:
*   Conner Charles
* Summary:
*	This is the .cpp for all the rock class methods. The base class rock
*	has a have some basic things for each rock. Big Rock has a break
*	apart function that is specific for itself. The Medium Rock has the 
*	same thing, just for them. Small Rock has nothing really special.
************************************************************************/
#include "rocks.h"
#include "uiDraw.h"
#include <list>

#define _USE_MATH_DEFINES
#include <math.h> // used for sin, cos, and M_PI

const int BIG_ROCK_VEL = 1;

//*****************************************************ROCK
/***************************************
* ROCK :: CONSTRUCTOR
* Sets member variables to default values
***************************************/
Rock::Rock()
{
	setDirection(random(0, 360));
	rotation = 0;
}

/***************************************
* ROCK :: FLY
* Sets the rock's velocity according to
* the direction and speed.
***************************************/
void Rock::fly(float speed)
{
	velocity.addOntoDx(-speed * (sin(M_PI / 180.0 * getDirection())));
	velocity.addOntoDy(-speed * (-cos(M_PI / 180.0 * getDirection())));
}

//*****************************************************BIG ROCK
/***************************************
* BIGROCK :: CONSTRUCTOR
* Sets member variables to default values
***************************************/
BigRock::BigRock(Point startingPt)
{
	setPosition(startingPt);
	setSize(BIG_ROCK_SIZE);
	fly(BIG_ROCK_VEL);
}

/***************************************
* BIGROCK :: DRAW
* Draws the big asteroid
***************************************/
void BigRock::draw() const
{
	drawLargeAsteroid(position, rotation);
}

/***************************************
* BIGROCK :: BREAK APART
* Creates 2 medium rocks, and 1 small rock
* when the rock is hit (killed)
***************************************/
void BigRock::breakApart(std::list<Rock*> &rocks)
{
	// First medium rock
	Rock* pRock1 = new MediumRock(position);
	pRock1->setVelocity(velocity + Velocity(0, 1)); // for an upward direction
	rocks.push_back(pRock1);

	// Second medium rock
	Rock* pRock2 = new MediumRock(position);
	pRock2->setVelocity(velocity + Velocity(0, -1)); // for a downward direction
	rocks.push_back(pRock2);

	// Small rock
	Rock* pRock3 = new SmallRock(position);
	pRock3->setVelocity(velocity + Velocity(2, 0)); // for a rightward direction
	rocks.push_back(pRock3);
}

/***************************************
* BIGROCK :: ADVANCE
* Does the normal advance thing and spins 
* the rock around each frame.
***************************************/
void BigRock::advance()
{
	FlyingObject::advance();

	rotation += BIG_ROCK_SPIN;
}

//*****************************************************MEDIUM ROCK
/***************************************
* MEDIUMROCK :: CONSTRUCTOR
* Sets member variables to default values
***************************************/
MediumRock::MediumRock(Point startingPt)
{
	setPosition(startingPt);
	setSize(MEDIUM_ROCK_SIZE);
}

/***************************************
* MEDIUMROCK :: DRAW
* Draws the medium asteroid
***************************************/
void MediumRock::draw() const
{
	drawMediumAsteroid(position, rotation);
}

/***************************************
* MEDIUMROCK :: BREAK APART
* Creates 2 small rocks when the medium 
* rock is hit (killed)
***************************************/
void MediumRock::breakApart(std::list<Rock*> &rocks)
{
	// First Small rock
	Rock* pRock1 = new SmallRock(position);
	pRock1->setVelocity(velocity + Velocity(3, 0)); // for a rightward direction
	rocks.push_back(pRock1);

	// Second Small rock
	Rock* pRock2 = new SmallRock(position);
	pRock2->setVelocity(velocity + Velocity(-3, 0)); // for a leftward direction
	rocks.push_back(pRock2);

}

/***************************************
* MEDIUMROCK :: ADVANCE
* Does the normal advance thing and spins
* the rock around each frame.
***************************************/
void MediumRock::advance()
{
	FlyingObject::advance();

	rotation += MEDIUM_ROCK_SPIN;
}

//*****************************************************SMALL ROCK
/***************************************
* SMALLROCK :: CONSTRUCTOR
* Sets member variables to default values
***************************************/
SmallRock::SmallRock(Point startingPt)
{
	setPosition(startingPt);
	setSize(SMALL_ROCK_SIZE);
}

/***************************************
* SMALLROCK :: DRAW
* Draws the medium asteroid
***************************************/
void SmallRock::draw() const
{
	drawSmallAsteroid(position, rotation);
}

/***************************************
* SMALLROCK :: ADVANCE
* Does the normal advance thing and spins
* the rock around each frame.
***************************************/
void SmallRock::advance()
{
	FlyingObject::advance();

	rotation += SMALL_ROCK_SPIN;
}