/***********************************************************************
* Source File:
*   FLYINGOBJECT : The representation of the moving objects in the game
* Author:
*   Conner Charles
* Summary:
*	This class cannot be instantiated. It keeps track of the the position
*	of the object and checks to see if it is within the screen, and it
*	moves the object according to its velocity.
************************************************************************/

#include "flyingObject.h"
#include "game.h"

/***************************************
* FLYINGOBJECT :: FLYINGOBJECT
* Does nothing b/c you cannot instantiate this class
***************************************/
FlyingObject::FlyingObject()
{
	direction = 0;
	radius = 10;
	alive = true;
}

/***************************************
* FLYINGOBJECT :: ~FLYINGOBJECT
* Does nothing
***************************************/
FlyingObject::~FlyingObject()
{
}

/***************************************
* FLYINGOBJECT :: KILL
* Kills whatever unforturate object is flying
***************************************/
void FlyingObject::kill()
{
	alive = false;
}

/***************************************
* FLYINGOBJECT :: ADVANCE
* Moves the object according to its velocity
***************************************/
void FlyingObject::advance()
{
	if (alive)
	{
		position += velocity;
		wrap();
	}
}

/***************************************
* FLYINGOBJECT :: WRAP
* Checks the position of the object to make sure
* it is in the bounds of the screen, if not then it 
* pushes it to the other side of the screen, thus wraping
***************************************/
void FlyingObject::wrap()
{
	// Basically if the point goes off the screen
	if (position.getX() > Game::getXMax()) // X too far right
	{
		position.setX(Game::getXMin());
	}

	if (position.getX() < Game::getXMin()) // X too far left
	{
		position.setX(Game::getXMax());
	}

	if (position.getY() > Game::getYMax()) // Y too high
	{
		position.setY(Game::getYMin());
	}

	if (position.getY() < Game::getYMin()) // Y too low
	{
		position.setY(Game::getYMax());
	}
}