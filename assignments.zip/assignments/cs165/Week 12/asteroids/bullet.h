/***********************************************************************
* Header File:
*    BULLET : This class is the object that goes from the ship and 
*	 interacts with the asteroids
* Author:
*    Conner Charles
* Summary:
*	 The bullet is able to take the current position of its firing object
*	 and have a set velocity added to it. It dies after a certain amount
*	 frames. 
************************************************************************/
#ifndef BULLET_H
#define BULLET_H

#include "flyingObject.h"
#include "ship.h"

/*********************************************
* BULLET
* The projectile class that hits the asteroids
*********************************************/
class Bullet : public FlyingObject
{
private:
	int frameLife;

	void shoot(float angle);

public:
	Bullet(Ship&);
	Bullet(Ship&, int);
	~Bullet();

	int getFrameLife() const { return frameLife; }

	void setFrameLife(int frameLife) { this->frameLife = frameLife; }

	virtual void advance();
	void draw() const;
};

#endif