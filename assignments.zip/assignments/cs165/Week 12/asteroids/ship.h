/***********************************************************************
* Header File:
*    SHIP : A representation of what the user will use to play the game
* Author:
*    Conner Charles
* Summary:
*	This is the ship class where it is what the user moves around to 
*	play the game. This ship can move left and right, and thrust forward
*	and it has a shotgun capability.
************************************************************************/

#ifndef ship_h
#define ship_h

#define SHIP_SIZE 10

#define ROTATE_AMOUNT 6
#define THRUST_AMOUNT 0.5

#include "flyingObject.h"

/**************************************
* Ship Class
* This is what the user will be using to play the game
***************************************/
class Ship : public FlyingObject
{
private:
	bool boost;
	int sonicBoom;

public:
	Ship();

	// Getters
	bool isBoost() const { return boost; }
	int getSonicBoom() const { return sonicBoom; }

	// Setters
	void setBoost(bool boost) { this->boost = boost; }
	void setSonicBoom(int sonicBoom) { this->sonicBoom = sonicBoom; }
	
	// Movement
	void turnLeft();
	void turnRight();
	void thrust();

	virtual void draw() const;
	void boom();
};

#endif /* ship_h */
