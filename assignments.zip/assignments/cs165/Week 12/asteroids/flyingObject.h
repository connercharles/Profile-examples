/***********************************************************************
* Header File:
*    FLYING OBJECT : A class that all flying objects will be inheriting from
* Author:
*    Conner Charles
* Summary:
*    This is the base class for all flying things in the game. It keeps 
*	 track of the direction of the object that it is facing. It also 
*	 keeps track of the movement and velocity of the object in advancing it.
************************************************************************/

#ifndef FLYINGOBJECT_H
#define FLYINGOBJECT_H

#include "velocity.h"
#include "point.h"
#include "uiDraw.h"

/**************************************
* Flying Object Class
* The initial class of all moving objects in the game.
* This class cannot be instantiated.
***************************************/
class FlyingObject
{
protected:
	Velocity velocity;
	Point position;
	float direction;
	bool alive;
	int radius;
	int size;

	void wrap();

public:
	// Constructors
	FlyingObject();
	~FlyingObject();

	// Getters
	Velocity getVelocity() const { return velocity; }
	Point getPosition() const { return position; }
	float getDirection() const { return direction; }
	bool isAlive() const { return alive; }
	int getRadius() const { return radius; }
	int getSize() const { return size; }

	// Setters
	void setVelocity(Velocity velocity) { this->velocity = velocity; }
	void setPosition(Point position) { this->position = position; }
	void setDirection(float direction) { this->direction = direction; }
	void setAlive(bool alive) { this->alive = alive; }
	void setRadius(int radius) { this->radius = radius; }
	void setSize(int size) { this->size = size; }

	// Good virtuals that will be over-written
	virtual void draw() const = 0;	
	virtual void advance();

	virtual void kill();
};

#endif