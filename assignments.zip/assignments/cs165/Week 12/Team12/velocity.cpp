#include "velocity.h"

#include <iostream>
using namespace std;

// TODO: Put your method bodies here

Velocity operator-(const Velocity &v1, const Velocity &v2)
{
   Velocity temp;
   temp.setDx(v1.getDx() - v2.getDx());
   temp.setDy(v1.getDy() - v2.getDy());

   return temp;
}

Velocity & operator-=(Velocity &v1, const Velocity &v2)
{
   v1.setDx(v1.getDx() - v2.getDx());
   v1.setDy(v1.getDy() - v2.getDy());

   return v1;
}

bool operator==(const Velocity &v1, const Velocity &v2)
{
   return (v1.getDx() == v2.getDx()
           && v2.getDy() == v2.getDy());
}

bool operator!=(const Velocity &v1, const Velocity &v2)
{
   return (!(v1 == v2));
}

bool operator>(const Velocity &v1, const Velocity &v2)
{
   return (v1.getDx() > v2.getDx()
           && v1.getDy() > v2.getDy());
}

bool operator<(const Velocity &v1, const Velocity &v2)
{
   return (v1.getDx() < v2.getDx()
           && v1.getDy() < v2.getDy());
}

bool operator<=(const Velocity &v1, const Velocity &v2)
{
   return (!(v1 > v2));
}

bool operator>=(const Velocity &v1, const Velocity &v2)
{
   return (!(v1 < v2));
}

void Velocity :: prompt()
{
   cout << "dx: ";
   cin >> dx;

   cout << "dy: ";
   cin >> dy;
}

void Velocity :: display() const 
{
   cout << "(dx=" << dx << ", dy=" << dy << ")";
}
