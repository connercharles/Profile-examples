/*******************
 * NumberList class
 *******************/
#ifndef NUMBER_LIST_H
#define NUMBER_LIST_H

#include <iostream>

class NumberList
{
private:
   int size;
   int* array;

public:
   NumberList()
   {
      size = 0;
      array = NULL;
   }


   // TODO: Add your constructor and destructor
   NumberList(int size)
   {
      array = new int[size];
      this->size = size;      
   }

   // Copy Constructor
   NumberList(const NumberList & old)
   {
      size = old.size;
      array = new int[size];

      for (unsigned int i = 0; i < size; i++)
      {
         array[i] = old.array[i];
      }
   }

   ~NumberList()
   {
      delete[] array;
      array = NULL;
      std::cout << "Freeing memory" << std::endl;
   }

   NumberList & operator=(const NumberList & rhs);

   int getNumber(int index) const;
   void setNumber(int index, int value);
   
   void displayList() const;

};

#endif
