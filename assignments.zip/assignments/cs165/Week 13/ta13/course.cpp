// course.cpp

#include "course.h"
#include <string>
#include <iostream>
using namespace std;

Student Course::getStudent(int index) const
{
   return classList[index];
}

void Course::setStudent(int index, const Student & student)
{
   classList[index] = student;
}

void Course::displayList() const
{
   cout << "Class list for course: " << name << endl;

   for (int i = 0; i < size; i++)
   {
      classList[i].display();
   }
}

ostream & operator<<(ostream & out, const Course & c)
{
   out << "Class list for course: " << name << endl;

   for (int i = 0; i < size; i++)
   {
      cout << classList[i];
   }

   return out;
}
