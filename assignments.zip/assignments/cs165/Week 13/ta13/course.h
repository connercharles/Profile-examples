// course.h

#ifndef COURSE_H
#define COURSE_H

#include <iostream>
#include "student.h"
#include <string>

class Course
{
private:
   std::string name;
   int size;
   Student* classList;

public:
   Course(int size)
   {
      setSize(size);

      classList = new Student[size];
   }

   ~Course()
   {
      delete[] classList;
      std::cout << "Cleaning up course " << name << std::endl;
   }

   Course(const Course & other)
   {
      size = other.size;
      classList = new Student[size];
      setName(other.getName());
      
      for (unsigned int i = 0; i < size; i++)
      {
         classList[i] = other.classList[i];
      }
   }
   
   std::string getName() const { return name; }
   void setName(std::string name) { this->name = name; }
   
   int getSize() const { return size; }
   void setSize(int size) { this->size = size; }

   Student getStudent(int index) const;
   void setStudent(int index, const Student &);

   void displayList() const;

   ostream & operator<<(ostream & out, const Course & c);

};

#endif
