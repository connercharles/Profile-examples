// student.cpp

#include "student.h"
#include <iostream>
using namespace std;

void Student::display() const 
{
   cout << id << " - " << name << endl;
}

ostream & operator<<(ostream & out, const Student & s)
{
   out << id << " - " << name << endl;
   return out;
}
