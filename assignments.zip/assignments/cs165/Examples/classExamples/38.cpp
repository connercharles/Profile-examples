/***********************************************************************
 * This program is designed to demonstrate:
 *      how to read words from a file
 ************************************************************************/

#include <iostream>
#include <fstream>
using namespace std;

#define NUM_WORDS 100

void getFilename(char filename[]);
int  read(char filename[], char words[][256]);
void displayNewAndHotness(char words[][256], int num);

/**********************************************************************
* open a file, read all the words into an array, and display the
* array of words backwards
***********************************************************************/
int main()
{
   // get the filename
   char filename[256];
   getFilename(filename);

   // read the array of words from the file
   int num = 0;
   char words[NUM_WORDS][256];
   num = read(filename, words);

   // display the contents backwards
   displayNewAndHotness(words, num);
   
   return 0;
}

/***********************************************
 * GET FILENAME
 * yep
 **********************************************/
void getFilename(char filename[])
{
   cout << "What is the filename? ";
   cin  >> filename;
}

/****************************************
 * READ
 * Read all the words from the file into words
 ***************************************/
int read(char filename[],   // input parameter
         char words[][256]) // output paramater
{
   // try to open the file
   ifstream fin(filename);
   if (fin.fail())
   {
      cout << "Unable to open file " << filename << endl;
      return 0; // no words found
   }

   // read the file, one word at a time
   int num = 0;
   while (num < NUM_WORDS && fin >> words[num])
      num++;
   
   // close the file and return the number found
   fin.close();
   return num;
}

/*****************************************
 * DISPLAY
 *****************************************/
void displayOldAndBusted(char words[][256], int num)
{
   // walk through the array of words backwards
   for (int i = num - 1; i >= 0; i--)
   {
      // for each letter in the word, display the letter and a space after
      cout << "word # " << i << ": ";
      for (char * p = words[i]; *p; p++)
         cout << *p << ' ';
      cout << endl;
   }
}

/*****************************************
 * DISPLAY
 *****************************************/
void displayNewAndHotness(char words[][256], int num)
{
   // walk through the array of words backwards
   for (int i = 0; i < num; i++)
   {
      cout << words[i];
      // if I am not at the beginning of the story and the word
      // before me begins with a period, then display a space
      if (words[i][0] != '.')
         cout << ' ';
   }
   cout << endl;
}
