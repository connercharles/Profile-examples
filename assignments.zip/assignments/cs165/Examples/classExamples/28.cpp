/***********************************************************************
* Program:
*    Test 2, Exponents
*    Brother Helfrich, CS124
* Author:
*    Br. Helfrich
* Summary: 
*    Display the first several powers of 2
*
*    Estimated:  0.5 hrs   
*    Actual:     0.0 hrs
*      Please describe briefly what was the most difficult part.
************************************************************************/

#include <iostream>
using namespace std;

int getNumber();
void displayPowers(int);

/**********************************************************************
 * MAIN
 * Prompt for number and display exponents
 ***********************************************************************/
int main()
{
   // prompt for number
   int number = getNumber();

   // display exponents
   displayPowers(number);
   
   return 0;
}

/*****************************************
 * GET NUMBER
 * Prompt the user for a number
 *****************************************/
int getNumber()
{
   int number;
   cout << "How many powers of two: ";
   cin  >> number;
   return number;
}

/***********************************
 * DISPLAY Austin
 ***********************************/
void displayPowers(int number)
{
   int exponent = 1;

   // loop through all the numbers
   for (int i = 0; i < number; i++)
   {
      cout << "\t" << "2^" << i
           << "\t" << exponent
           << endl;
      exponent *= 2;
   }
}

