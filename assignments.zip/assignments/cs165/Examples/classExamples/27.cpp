/***********************************************************************
* Program:
*    Test 2, Flip a coin
*    Brother Helfrich, CS124
* Author:
*    Br. Helfrich
* Summary: 
*    Count the coin flipping stuff
*
************************************************************************/

#include <iostream>   // for CIN, COUT
#include <ctime>      // for time(), part of the random process
#include <stdlib.h>   // for rand() and srand()
using namespace std;

/********************************
 * HEADS
 * Did I just flip heads?
 *******************************/
bool heads()
{
   return rand() % 2 == 0;
}

int countHeads(int number)
{
   int numHeads = 0;
   for (int i = 0; i < number; i++)
      numHeads += heads();
   return numHeads;
}

int numFlips()
{
   int num;
   cout << "How many coin flips for this experiment: ";
   cin  >> num;
   return num;
}

/**********************************************************************
 * Add text here to describe what the function "main" does. Also don't forget
 * to fill this out with meaningful text or YOU WILL LOSE POINTS.
 ***********************************************************************/
int main(int argc, char **argv)
{
   // this code is necessary to set up the random number generator. If
   // your program uses a random number generator, you will need this 
   // code. Otherwise, you can safely delete it.  Note: this must go in main()
   srand(argc == 1 ? time(NULL) : (int)argv[1][1]);


   int numTotal = numFlips();
   int numHeads = countHeads(numTotal);

   cout << "There were " << numHeads << " heads.\n";
   cout << "There were " << numTotal - numHeads << " tails.\n";
   
   return 0;
}
