/***********************************************************************
 * This program is designed to demonstrate:
 *      
 ************************************************************************/

#include <iostream>
using namespace std;

/**********************************************************************
* This will be just a simple driver program 
***********************************************************************/
int main()
{
   cout << "This text is \E[22;32m green \E[0m but not the rest.\n";
   return 0;
}
