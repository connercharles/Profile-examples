/***********************************************************************
 * This program is designed to demonstrate:
 *      
 ************************************************************************/

#include <iostream>
using namespace std;


void mystery(char * a1, char * a2)
{
   while (*(a1++) = *(a2++))
      ;
}


void function(int value, int & reference, int * pointer)
{
   cout << "value    =" << value     << " &value    =" << &value << endl;
   cout << "reference=" << reference << " &reference=" << &reference << endl;
   cout << "*pointer =" << *pointer  << " pointer   =" << pointer << endl;
   
}

/**********************************************************************
* This will be just a simple driver program 
***********************************************************************/
int main()
{
   char text[256];
   cout << "Give me text or give me death!!! ";
   cin >> text;
   char text2[256];
   mystery(text2, text);
   cout << text2 << endl;

   
   int x = 42;
   cout << " x == " << x  << endl;
   cout << "&x == " << &x << endl;
   function(x, x, &x);
   
   cout << endl << endl << endl;

   
   int array[5] = { 34, 98, 12, 76, 12 };

   cout << "array[4]     = " << array[4]     << endl;
   cout << "*(array + 4) = " << *(array + 4) << endl;
   cout << "*(4 + array) = " << *(4 + array) << endl;
   cout << "4[array]     = " << 4[array]     << endl;
   return 0;
}
