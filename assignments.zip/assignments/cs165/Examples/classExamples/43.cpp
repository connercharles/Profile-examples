/***********************************************************************
 * This program is designed to demonstrate:
 *      
 ************************************************************************/

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

/**********************************************************************
* This will be just a simple driver program 
***********************************************************************/
int main(int argc, char ** argv)
{
   // filename
   string fileNameIn;
   string fileNameOut;
   switch (argc)
   {
      case 3:
         fileNameOut = argv[2];
         // fall through to case 2
      case 2:
         fileNameIn = argv[1];
         break;
      case 1:
         cout << "Filename? ";
         cin  >> fileNameIn;
         break;
      default:
         cout << "ERROR: Unexpected number of command line parameters\n";
         cout << "\tUsage: " << argv[0] << " [filenameIn] [fileNameOut]\n";
         return 1;
   }
   
   // open the file
   ifstream fin(fileNameIn.c_str());
   if (fin.fail())
   {
      cout << "ERROR: Unable to open file \""
           << fileNameIn
           << "\"\n";
      return 1;
   }

   // of there is only one file spacified, write to the screen
   if (fileNameOut.empty())
   {
      // display the contents
      string lineOText;
      while (getline(fin, lineOText))
         cout << lineOText << endl;
   }

   // otherwise, write to a file
   else
   {
      ofstream fout(fileNameOut.c_str());
      if (fout.fail())
      {
         cout << "ERROR: Unable to write to file \""
              << fileNameOut
              << "\"\n";
         fin.close();
         return 1;
      }

      string lineOText;
      while (getline(fin, lineOText))
         fout << lineOText << endl;

      fout.close();
   }
   
   // close the file
   fin.close();
   
   return 0;
}
