/***********************************************************************
 * This program is designed to demonstrate:
 *      
 ************************************************************************/

#include <iostream>
#include <cassert>
using namespace std;

/**********************************************************************
* This will be just a simple driver program 
***********************************************************************/
int main()
{
   xint value;
   cout << "> " ;
   cin  >> value;

   assert(value > 0);

   cout << "I am done now\n";
   
   return 0;
}
