/***********************************************************************
 * This program is designed to demonstrate:
 *      more cin.ignore() stuff
 ************************************************************************/

#include <iostream>
#include <string>
using namespace std;

/**********************************************************************
* This will be just a simple driver program 
***********************************************************************/
int main()
{
   string text;

   cout << "Give me text or give me death! " ;
   cin >> text;
   cout << "\"" << text << "\"\n";

   cin.ignore();
   
   cout << "Give me text or give me death! " ;
   cin >> text;
   cout << "\"" << text << "\"\n";
   
   return 0;
}
