/***********************************************************************
 * This program is designed to demonstrate:
 *      read and write to a file by storing my account
 *      balance
 ************************************************************************/

#include <iostream>
#include <fstream>
#include <cassert>
using namespace std;

/*********************************
 * GET BALANCE
 * Open the file, read the number,
 * and close the file
 ********************************/
float getBalance()
{
   // open the file
   ifstream fin("money.txt");
   if (fin.fail())
      return 0.0;
   
   // read the balance
   float balance;
   fin >> balance;
   assert(!fin.fail());
   
   // close the file
   fin.close();
   return balance;
}

/********************************
 * UPDATE BALANCE
 * Show the user the balance, ask for
 * any transaction, and update the balance
 ********************************/
void updateBalance(float &balance)
{
   // show current balance
   cout.setf(ios::fixed);
   cout.setf(ios::showpoint);
   cout.precision(2);
   cout << "Balance: $"
        << balance
        << endl;

   // prompt for any change
   float difference;
   cout << "How much did you spend/make? ";
   cin  >> difference;
   
   // update the balance
   balance += difference;
}

/**********************************
 * WRITE BALANCE
 * open the file, write the number, and
 * close the file
 **********************************/
void writeBalance(float balance)
{
   // open the file
   ofstream fout("money.txt");

   // handle errors
   if (fout.fail())
   {
      cout << "Dude, I totally am going to loose your money. Bummer!\n";
      return;
   }

   // write the file
   fout << balance << endl;
   
   // close up shop
   fout.close();
}

/**********************************************************************
* This will be just a simple driver program 
***********************************************************************/
int main()
{
   float balance = getBalance();

   updateBalance(balance);

   writeBalance(balance);
   
   return 0;
}
