/***********************************************************************
 * This program is designed to demonstrate:
 *      read data from a file
 ************************************************************************/

#include <iostream>   // for CIN and COUT
#include <fstream>    // for IFSTREAM
using namespace std;

/**********************************************************************
* This will be just a simple driver program 
***********************************************************************/
int main()
{
   // open the file
   ifstream fin("file.txt");
   if (fin.fail())
   {
      cout << "You are a loooooooser!\n";
      return 1;
   }

   // read two numbers
   int number1 = -1;
   int number2 = -2;
   if (fin >> number1 >> number2)
      cout << "success!\n";
   else
      cout << "failure :(\n";

   // close the file and display it
   fin.close();
   cout << "Your two numbers are: "
        << number1
        << " and "
        << number2
        << endl; 
   
   return 0;
}
