/***********************************************************************
* Program:
*    Test 4, convert text
*    Brother Helfrich, CS124
* Author:
*    Mr . T
* Summary: 
*    Convert text
*
*    Estimated:  0.4 hrs   
*    Actual:     0.0 hrs
*      Please describe briefly what was the most difficult part.
************************************************************************/

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

/*********************************
 * GET FILENAME
 ********************************/
string getFileName()
{
   cout << "Please enter the filename: ";
   string fileName;
   cin >> fileName;
   return fileName;
}

/***********************************
 * READ
 * Open the file, read the line, and close
 ***********************************/
void read(string fileName, char data[])
{
   // open the file
   ifstream fin(fileName.c_str());

   // check for errors
   if (fin.fail())
   {
      // display a message and set the string to empty
      cout << "You are a looser baby, so why don't you kill me\n";
      data[0] ='\0';
      return;
   }
     
   // read one line
   fin.getline(data, 256);

   // close file
   fin.close();
}

/*******************************************
 * CONVERT
 * Put on the suit and learn a new language
 *******************************************/
void convert(char data[])
{
   // capitolize the next letter that comes along
   bool capitolize = true;
   
   // loop through the text one letter at a time
   for (char * p = data; *p; p++)
   {
      // if I need to capitolize it, then do so
      if (capitolize)
         *p = toupper(*p);
      // otherwise, lowercase it
      else
         *p = tolower(*p);

      // if I am a space or a -, then capitolize the next letter
      if (isspace(*p) || *p == '-')
         capitolize = true;
      else
         capitolize = false;
   }
}

/**********************************
 * YEP
 *********************************/
void display(char data[])
{
   cout << data << endl;
}

/**********************************************************************
 * Convert text from random casing to TitleCase
 ***********************************************************************/
int main(int argc,     // number of parameters in the argv array
         char ** argv) // the list of parameters argv[0] is the program name
{
   // get a filename
   string fileName;
   switch (argc)
   {
      case 1:
         fileName = getFileName();
         break;
      case 2:
         fileName = argv[1];
         break;
      default:
         cout << "You are totally wacked!\n";
         return 1;
   }

   // read the data from the file
   char data[256];
   read(fileName, data);
   
   // convert the data to TitleCase
   convert(data);

   // display the data
   display(data);
   
   return 0;
}
