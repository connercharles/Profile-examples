/***********************************************************************
 * This program is designed to demonstrate:
 *      measure how long it take to append text
 ************************************************************************/

#include <iostream>
#include <cstring>
#include <string>
#include <time.h>
#include <iomanip>
using namespace std;

/***********************************
 * STRING CLASS
 ***********************************/
float StringClass(int num)
{
   float msBegin = clock();

   // allocate the memory
   string text;

   // append the letter 'a' on to the end.
   for (int i = 0; i < num; i++)
      text += 'a';

   float msEnd = clock();
   return (msEnd - msBegin) / 1000000.0;
}


/***********************************
 * New and hotness
 ***********************************/
float NewAndHotness(int num)
{
   float msBegin = clock();

   // allocate the memory
   char * text = new(nothrow) char[num + 1];
   text[0] = '\0'; // with the null character at the beginning, I am empty
   int length = 0;

   // append the letter 'a' on to the end.
   for (int i = 0; i < num; i++)
   {
      text[length] = 'a';
      text[++length] = '\0';
   }

   delete [] text;

   float msEnd = clock();
   return (msEnd - msBegin) / 1000000.0;
}


/***********************************
 * OLD AND BUSTED
 * "Do NOT go in there!"
 ***********************************/
float OldAndBusted(int num)
{
   float msBegin = clock();
   
   // allocate the memory
   char * text = new(nothrow) char[num + 1];
   text[0] = '\0'; // with the null character at the beginning, I am empty
   
   // append the letter 'a' on to the end.
   for (int i = 0; i < num; i++)
   {
      int length = strlen(text);
      text[length] = 'a';
      text[length + 1] = '\0';
   }

   delete [] text;

   float msEnd = clock();
   return (msEnd - msBegin) / 1000000.0;
}

/**********************************************************************
* This will be just a simple driver program 
***********************************************************************/
int main()
{
   cout << setw(10) << "New" << setw(10) << "String\n";

   cout.setf(ios::fixed | ios::showpoint);
   cout.precision(2);
   for (int i = 1024; true; i *= 2)
      cout << setw(10) << NewAndHotness(i)
           << setw(10) << StringClass(i)
           << endl;

   return 0;
}
