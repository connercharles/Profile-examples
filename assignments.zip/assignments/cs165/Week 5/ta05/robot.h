#ifndef ROBOT_H
#define ROBOT_H

#include "point.h"

class Robot
{
private:
   Point position;
   int energy;

public:
   Robot();
   Robot(int energy);
   Robot(Point position, int energy);
   
   Point getPosition() const;
   int getEnergy() const;

   void setPosition(Point position);
   void setEnergy(int energy);
   
   void display() const;

   void moveUp();
   void moveDown();
   void moveRight();
   void moveLeft();

   void fireLaser();
};

#endif
