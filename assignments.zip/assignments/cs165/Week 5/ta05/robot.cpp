#include "robot.h"
#include <iostream>
using namespace std;


void Robot::moveUp()
{   
   int energy = getEnergy();

   if (energy >= 10)
   {
      cout << "Moving up..." << endl;
      
      Point p;
      int newY;

      p = getPosition();
      newY = p.getY();

      p.setY(newY + 1);

      setPosition(p);

      energy -= 10;
      setEnergy(energy);
   }
   else
   {
      cout << "Error! Robot is out of energy!" << endl;
   }
}

void Robot::moveDown()
{
   int energy = getEnergy();

   if (energy >= 10)
   {
      cout << "Moving down..." << endl;
      
      Point p;
      int newY;

      p = getPosition();
      newY = p.getY();

      p.setY(newY - 1);

      setPosition(p);

      energy -= 10;
      setEnergy(energy);
   }
   else
   {
      cout << "Error! Robot is out of energy!" << endl;
   }
}

void Robot::moveRight()
{
   int energy = getEnergy();

   if (energy >= 10)
   {
      cout << "Moving right..." << endl;
      
      Point p;
      int newX;

      p = getPosition();
      newX = p.getX();

      p.setX(newX + 1);

      setPosition(p);

      energy -= 10;
      setEnergy(energy);
   }
   else
   {
      cout << "Error! Robot is out of energy!" << endl;
   }
}

void Robot::moveLeft()
{
   int energy = getEnergy();

   if (energy >= 10)
   {
      cout << "Moving left..." << endl;
      
      Point p;
      int newX;

      p = getPosition();
      newX = p.getX();

      p.setX(newX - 1);

      setPosition(p);

      energy -= 10;
      setEnergy(energy);
   }
   else
   {
      cout << "Error! Robot is out of energy!" << endl;
   }
}

void Robot::fireLaser()
{

   int energy = getEnergy();

   if (energy >= 25)
   {
      cout << "Firing the laser!" << endl;
      
      cout << "Kill it with fire!!!" << endl;
      energy -= 25;
      setEnergy(energy);
   }
   else
   {
      cout << "Error! Robot is out of energy!" << endl;
   }
}

Point Robot::getPosition() const
{
   return position;
}

int Robot::getEnergy() const
{
   return energy;
}

void Robot::setPosition(Point position)
{
   this-> position = position;
}

void Robot::setEnergy(int energy)
{
   if (energy < 0)
   {
      this -> energy = 0;
   }
   else
   {
      this-> energy = energy;
   }
}

Robot::Robot()
{
   energy = 100;
}

Robot::Robot(int energy)
{
   setEnergy(energy);
}

Robot::Robot(Point position, int energy)
{
   setEnergy(energy);
   setPosition(position);
}
/************************************
 * Function: Display
 * Purpose: Displays the robot.
 ************************************/
void Robot :: display() const
{
   position.display();
   cout << " - Energy: " << getEnergy();
}
