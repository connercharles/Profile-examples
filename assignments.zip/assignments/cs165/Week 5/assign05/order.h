/*****************************************************************
 * File: order.h
 * Purpose: Order class holds a Product, quantity, and a Customer.
 * Can display the data.
 ******************************************************************/

// File: order.h

#ifndef ORDER_H
#define ORDER_H

#include "product.h"
#include "customer.h"

#include <string>

// Put your Order class here

class Order
{
  private:
   Product product;
   int quantity;
   Customer customer;
   
  public:
   // Constructors
   Order();
   Order(Product product, int quantity, Customer customer);
   
   // Getters
   Product getProduct() const { return product; }
   int getQuantity() const { return quantity; }
   Customer getCustomer() const { return customer; }
   float getTotalPrice() const;
   std::string getShippingZip() const;
   
   // Setters
   void setProduct(Product product);
   void setQuantity(int quantity);
   void setCustomer(Customer customer);

   void displayShippingLabel() const;
   void displayReceipt() const;
};


#endif
