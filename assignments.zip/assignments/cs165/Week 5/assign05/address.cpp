// File: address.cpp

#include "address.h"
#include <iostream>

using namespace std;

// Put your method bodies for the address class here

/**********************************************************
 *Method: Address()
 *Purpose: This is the default constructor for Addresses.
 * It sets the address to a predetermined amounts.
 ***********************************************************/
Address::Address()
{
   street = "unknown";
   city = "";
   state = "";
   zip = "00000";
}

/**********************************************************
 *Method: setStreet
 *Purpose: Passes in a new street, sets the new to the
 * address.
 ***********************************************************/
void Address::setStreet(string street)
{
   this->street = street;
}

/**********************************************************
 *Method: setCity
 *Purpose: Passes in a new city, sets the new to the
 * address.
 ***********************************************************/
void Address::setCity(string city)
{
   this->city = city;
}

/**********************************************************
 *Method: setState
 *Purpose: Passes in a new state, sets the new to the
 * address.
 ***********************************************************/
void Address::setState(string state)
{
   this->state = state;
}

/**********************************************************
 *Method: setZip
 *Purpose: Passes in a new zip, sets the new to the
 * address.
 ***********************************************************/
void Address::setZip(string zip)
{
   this->zip = zip;
}

/**********************************************************
 *Method: prompt
 *Purpose: Asks the user to enter in the information for
 * an address, then sets the user input to that address.
 ***********************************************************/
void Address::prompt()
{
   string userStreet;
   cout << "Street: ";
   getline(cin, userStreet);

   string userCity;
   cout << "City: ";
   getline(cin, userCity);

   string userState;
   cout << "State: ";
   getline(cin, userState);

   string userZip;
   cout << "Zip: ";
   cin >> userZip;

   setStreet(userStreet);
   setCity(userCity);
   setState(userState);
   setZip(userZip);
}

/**********************************************************
 *Method: display
 *Purpose: Displays the address in a specific format.
 ***********************************************************/
void Address::display() const
{
   cout << getStreet() << endl;
   cout << getCity() << ", " << getState() << " ";
   cout << getZip() << endl;
}

/**********************************************************
 *Method: Address(...)
 *Purpose: This is the non-default constructor for Addresses,
 * it sets all the passed in strings as the the address.
 ***********************************************************/
Address::Address(string street, string city, string state,
                 string zip)
{
   setStreet(street);
   setCity(city);
   setState(state);
   setZip(zip);
}
