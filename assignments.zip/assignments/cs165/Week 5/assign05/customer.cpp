// File: customer.cpp

#include "customer.h"
#include <string>
#include <iostream>

using namespace std;

// Put the method bodies for your customer class here

/*********************************************************
 *Method: Customer()
 *Purpose: Sets the default values for the customer class.
 **********************************************************/
Customer::Customer()
{
   name = "unspecified";
}

/*********************************************************
 *Method: setName
 *Purpose: Sets passed in name as new name for customer.
 **********************************************************/
void Customer::setName(string name)
{
   this->name = name;
}

/*********************************************************
 *Method: setAddress
 *Purpose: Sets passed in address as new address for
 * customer.
 **********************************************************/
void Customer::setAddress(Address address)
{
   this->address = address;
}

/*********************************************************
 *Method: prompt
 *Purpose: Asks user for customer's name and address.
 **********************************************************/
void Customer::prompt()
{
   string userName;
   cout << "Name: ";
   cin >> userName;

   Address userAddress;
   userAddress.prompt();

   setName(userName);
   setAddress(userAddress);
}

/*********************************************************
 *Method: display
 *Purpose: Displays customer information in a specific
 * format.
 **********************************************************/
void Customer::display() const
{
   cout << getName() << endl;

   Address address = getAddress();
   address.display();
}

/*********************************************************
 *Method: Customer(...)
 *Purpose: Sets the customer values with passed in
 * parameters.
 **********************************************************/
Customer::Customer(string name, Address address)
{
   setName(name);
   setAddress(address);
}
