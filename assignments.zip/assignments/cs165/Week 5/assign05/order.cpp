// File: order.cpp

#include "order.h"
#include <string>
#include <iostream>

using namespace std;

// Put your the method bodies for your order class here

/**************************************************************
 *Method: Order()
 *Purpose: Sets the default as values of the order.
 ***************************************************************/
Order::Order()
{
   quantity = 0;
}

/**************************************************************
 *Method: setProduct
 *Purpose: Sets passed in product as new product value.
 ***************************************************************/
void Order::setProduct(Product product)
{
   this->product = product;
}

/**************************************************************
 *Method: setQuantity
 *Purpose: Sets passed in quantity as new quantity value.
 ***************************************************************/
void Order::setQuantity(int quantity)
{
   this->quantity = quantity;
}

/**************************************************************
 *Method: setCustomer
 *Purpose: Sets passed in customer as new customer value.
 ***************************************************************/
void Order::setCustomer(Customer customer)
{
   this->customer = customer;
}

/**************************************************************
 *Method: getShippingZip
 *Purpose: Returns the customer's address zip code.
 ***************************************************************/
string Order::getShippingZip() const
{
   return getCustomer().getAddress().getZip();
}

/**************************************************************
 *Method: getTotalPrice
 *Purpose: Returns the total price multiplied by the quantity.
 ***************************************************************/
float Order::getTotalPrice() const
{
   return getProduct().getTotalPrice() * getQuantity();
}

/**************************************************************
 *Method: displayShippingLabel
 *Purpose: Displays all data from customer, address, and product
 * in a certain format specifically showing the address.
 ***************************************************************/
void Order::displayShippingLabel() const
{
   getCustomer().display();
}

/**************************************************************
 *Method: displayReceipt
 *Purpose: Displays all data from customer, address, and product
 * in a certain format specifically showing prices.
 ***************************************************************/
void Order::displayReceipt() const
{
   cout << getCustomer().getName() << endl;

   getProduct().displayReceipt();
}

/**************************************************************
 *Method: Order(...)
 *Purpose: Sets the passed values as the new Order.
 ***************************************************************/
Order::Order(Product product, int quantity, Customer customer)
{
   setProduct(product);
   setQuantity(quantity);
   setCustomer(customer);
}
