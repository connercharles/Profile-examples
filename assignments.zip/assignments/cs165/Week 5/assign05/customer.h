/******************************************************
 * File: customer.h
 * Purpose: This class holds a name and an address, can
 * display the data.
 *******************************************************/

// File: customer.h

#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "address.h"

// put your Customer class here

class Customer
{
  private:
   std::string name;
   Address address;
   
   public:

   // Constructors
   Customer();
   Customer(std::string name, Address address);
   
   // Getters
   std::string getName() const { return name; }
   Address getAddress() const { return address; }

   // Setters
   void setName(std::string name);
   void setAddress(Address address);

   void prompt();
   void display() const;
};

#endif
