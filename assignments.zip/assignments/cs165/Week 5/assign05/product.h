/***************************************************************
 * File: product.h
 * Author: Conner Charles
 * Purpose: Keeps track of the product that the user inputs.
 * Class can display product information in a variety of ways.
 ***************************************************************/
#ifndef PRODUCT_H
#define PRODUCT_H

#include <string>

// put your class definition here

class Product
{
  private:
   std::string name;
   float basePrice;
   float weight;
   std::string description;

  public:
   // Book Keeping
   static const float TAX = .06;
   static const int MIN_WEIGHT = 5;
   static const float SHIPPING_BASE = 2.00;
   static const float SHIPPING_ADD_ON = .10;

   // Constructors
   Product();
   Product(std::string name, std::string description,
           float basePrice, float weight);
   
   // Setters
   void setName(std::string name);
   void setBasePrice(float basePrice);
   void setWeight(float weight);
   void setDescription(std::string description);

   void prompt();

   // Getters
   std::string getName() const { return name; }
   float getBasePrice() const { return basePrice; }
   float getWeight() const { return weight; }
   std::string getDescription() const { return description; }
   
   float getSalesTax();
   float getShippingCost();
   float getTotalPrice();

   // Displays
   void displayAdvertising() const;
   void displayInventory() const;
   // Not const b/c it sets a decimal precision.        
   void displayReceipt();

   bool errorHandling(float numberInput);
};


#endif
