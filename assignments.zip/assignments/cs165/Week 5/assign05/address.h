/*****************************************************************
 * File: address.h
 * Purpose: This address holds a street, city, state and zip, can
 * display the data.
 ******************************************************************/

// File: address.h

#ifndef ADDRESS_H
#define ADDRESS_H

#include <string>

// Put your Address class here

class Address
{
  private:
   std::string street;
   std::string city;
   std::string state;
   std::string zip;

  public:
   // Constructors
   Address();
   Address(std::string street, std::string city, std::string state,
           std::string zip);

   // Getters
   std::string getStreet() const { return street; }
   std::string getCity() const { return city; }
   std::string getState() const { return state; }
   std::string getZip() const { return zip; }

   // Setters
   void setStreet(std::string street);
   void setCity(std::string city);
   void setState(std::string state);
   void setZip(std::string zip);

   void prompt();
   void display() const;
};

#endif
