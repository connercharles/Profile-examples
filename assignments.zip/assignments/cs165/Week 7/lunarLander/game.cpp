/****************************************
 * The game of moonlander
 ****************************************/

#include "uiDraw.h"
#include "uiInteract.h"
#include "point.h"
#include "ground.h"
#include "lander.h"

#define FUEL        500    // initial fuel for the game
#define MIN_SPEED   3.0    // minimal landing speed
#define FALL_HEIGHT 4.0    // greatest height we can fall from

const int FINALLEVEL = 3;

/*****************************************
 * GAME
 * The main game class containing all the state
 *****************************************/
class Game
{
public:
   // create the game
   Game(Point tl, Point br) : topLeft(tl), bottomRight(br), ground(Ground(topLeft, bottomRight)) { }
   
   // handle user input
   void handleInput(const Interface & ui);

   // advance the game
   void advance();
         
   // draw stuff
   void draw(const Interface & ui);

private:
   bool justLanded() const;

   Point topLeft;
   Point bottomRight;
   Ground ground;

   // TODO: add any objects or variables that are required
   Lander lander;

   static int gameLevel;

   // Astroid positions
    const static Point mediumAstroid1;
    const static Point mediumAstroid2;
    const static Point smallAstroid1;
    const static Point smallAstroid2;

};

/******************************************
 * Because linux doesn't want me to declare
 * these variable in the game declaration...
 ******************************************/
int Game :: gameLevel = 1;

const Point Game :: mediumAstroid1 = (-100, 100);
const Point Game :: mediumAstroid2 = (0, 150);
const Point Game :: smallAstroid1 = (75, 75);
const Point Game :: smallAstroid2 = (150, 100);

/******************************************
 * GAME :: LANDED
 * Did we land successfully?
 ******************************************/
bool Game :: justLanded() const
{
	int platWidth = ground.getPlatformWidth() / 2; 
	// So it is from the center to either end ^^

	Point landerCenter = lander.getPoint();
	Point platCenter = ground.getPlatformPosition();
	Velocity landerVelocity = lander.getVelocity();

	if (landerCenter.getY() - platCenter.getY() <= 4 // Not too high
		&& landerCenter.getY() - platCenter.getY() >= 0 // Not too low
		&& landerCenter.getX() < (platCenter.getX() + platWidth) // Not too far right
		&& landerCenter.getX() > (platCenter.getX() - platWidth) // Not too far left
		&& landerVelocity.getDx() <= 3 // Not coming in too fast
		&& landerVelocity.getDy() <= 3)
	{
		return true;
	}
   return false;
}

/***************************************
 * GAME :: ADVANCE
 * advance the game one unit of time
 ***************************************/
void Game :: advance()
{
	Point text(20, 175);
	Point otherText(-20, 100);

	// If you crashed
	if (ground.crashed(lander.getPoint()))
	{
		lander.setAlive(false);
		drawText(text, "You died in a fiery explosion.");
		drawText(otherText, "Press Space to start over.");
		drawLanderFlames(lander.getPoint(), true, true, true);
	}
	// If you are alive and haven't landed
	else if (lander.isAlive() && !justLanded())
	{
		lander.advance(gameLevel);
	}
	// If you win
	else if (justLanded())
	{
		if (gameLevel == FINALLEVEL)
		{
			drawText(text, "You beat the game!");
		}
		else
		{
			drawText(text, "You landed!");
			drawText(otherText, "Press Space to continue.");
			lander.setLanded(true);
		}
	}
}

/***************************************
 * GAME :: input
 * accept input from the user
 ***************************************/
void Game :: handleInput(const Interface & ui)
{
   // TODO: handle user input
	if (ui.isLeft())
	{
		lander.applyThrustLeft();
	}
	else if (ui.isRight())
	{
		lander.applyThrustRight();
	}
	else if (ui.isDown())
	{
		lander.applyThrustBottom();
	}
	else if (ui.isSpace() && 
		(lander.hasLanded() || !lander.isAlive()))
	{		
		if (lander.hasLanded())
		{
			gameLevel++;
		}
		else
		{
			lander.setAlive(true);
			gameLevel = 1; // Reset the game
		}
		ground.generateGround();
		lander.resetLander();
	}
}

/*********************************************
 * GAME :: DRAW
 * Draw everything on the screen
 *********************************************/
void Game :: draw(const Interface & ui)
{
   // TODO: draw the lander or a status message
	lander.draw();

   // TODO: draw the fuel
	Point tlFuel(-190, 190);
	drawNumber(tlFuel, lander.getFuel());
   
	// draw ground
	ground.draw();

	// If the final level, draw astroids
	if (gameLevel == FINALLEVEL)
	{
		Point mediumAstroid1(-100, 100);
		Point mediumAstroid2(0, 150);
		Point smallAstroid1(75, 75);
		Point smallAstroid2(150, 100);

		drawMediumAsteroid(mediumAstroid1, 300);
		drawMediumAsteroid(mediumAstroid2, 200);
		drawSmallAsteroid(smallAstroid1, 0);
		drawSmallAsteroid(smallAstroid2, 100);
	}
}


/*************************************
 * All the interesting work happens here, when
 * I get called back from OpenGL to draw a frame.
 * When I am finished drawing, then the graphics
 * engine will wait until the proper amount of
 * time has passed and put the drawing on the screen.
 **************************************/
void callBack(const Interface *pUI, void *p)
{
   Game *pGame = (Game *)p;
   
   pGame->advance();
   pGame->handleInput(*pUI);
   pGame->draw(*pUI);
}


/*********************************
 * Main is pretty sparse.  Just initialize
 * the game and call the display engine.
 * That is all!
 *********************************/
int main(int argc, char ** argv)
{
   Point topLeft(-200, 200);
   Point bottomRight(200, -200);

   Interface ui(argc, argv, "Moon Lander", topLeft, bottomRight);
   Game game(topLeft, bottomRight);
   ui.run(callBack, &game);
   
   return 0;
}
