/***********************************************************************
* Source File:
*   VELOCITY : The representation of the lander's movement on the screen
* Author:
*   Conner Charles
* Summary:
*	This is the velocity.cpp that is where all the velocity methods are
*	stated. You are able to add a change in x and a change in y to the 
*	current velocity and that's about it. 
************************************************************************/

#include "velocity.h"

/******************************************
* VELOCITY : CONSTRUCTOR
* Sets the velocity with default values
*****************************************/
Velocity::Velocity()
{
	dx = 0;
	dy = 0;
}

/******************************************
* VELOCITY : CONSTRUCTOR WITH DX,DY
* Sets the velocity with passed in values
*****************************************/
Velocity::Velocity(float dx, float dy)
{
	this->dx = dx;
	this->dy = dy;
}

/******************************************
* VELOCITY : Set Dx
* Sets passed in value as new dx
*****************************************/
void Velocity::setDx(float dx)
{
	this->dx = dx;
}

/******************************************
* VELOCITY : Set Dy
* Sets passed in value as new dy
*****************************************/
void Velocity::setDy(float dy)
{
	this->dy = dy;
}

/******************************************
* VELOCITY : Add Onto Dx
* Adds the passed in value to current dx
*****************************************/
void Velocity::addOntoDx(float dx)
{
	this->dx += dx;
}

/******************************************
* VELOCITY : Add Onto Dy
* Adds the passed in value to current dy
*****************************************/
void Velocity::addOntoDy(float dy)
{
	this->dy += dy;
}
