#include <iostream>
using namespace std;

// Core requirements
float getValueFromPointer(float* thePointer)
{
   return *thePointer;
}

float* getMinValue(float* a, float* b)
{
   if (*a > *b)
   {
      return b;
   }
   else
   {
      return a;
   }
}

// Stretch goals
void swapElements(float* theArray[], float a, float b)
{
   float* temp;
   temp = *theArray[a];
   theArray[a] = *theArray[b];
   theArray[b] = *temp;
}

void sortArray(float* theArray[]);

int main()
{  


   //  Core Requirement 1
   int arraySize;
   cout << "Enter the array size: ";
   cin >> arraySize;
   float* floatArray;
   float** pointCeption;

   // Allocate your array(s) here
   try
   {
      floatArray = new float[arraySize];
      pointCeption = new float*[arraySize];
   }
   catch(bad_alloc)
   {
      cout << "ERROR!!!!!!!!!!!!!!!" << endl;
   }

   for(int i = 0; i < arraySize; i++)
   {
      pointCeption[i] = &floatArray[i];

      //Debugging
      //cout << "first: " << floatArray[i] << endl;
      // cout << "second: " << *pointCeption[i] << endl;
   }
   
   // Fill your array with float values
   for(int i = 0; i < arraySize; i++) 
   {
      cout << "Enter a float value: ";
      cin >> floatArray[i];
   }

    // Core Requirement 2
   for (int i = 0; i < arraySize; i++)
   {
      float value = getValueFromPointer(&floatArray[i]);
      cout << "The value of the element " << i << " is: ";
      cout << value << endl;
   }
   

   // Core Requirement 3
   // Print the smaller of the first and last elements of the array
   float *pointerToMin = getMinValue(&floatArray[0],
                                     &floatArray[arraySize - 1]);
   cout << "Smallest number: " << *pointerToMin << endl;
   
   swapElements(pointCeption, 0, arraySize - 1);
   
   // Clean up your array(s) here

   delete[] floatArray;
   delete[] pointCeption;
   
   return 0;
}

