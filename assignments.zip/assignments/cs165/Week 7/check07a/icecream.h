/****************************
 * File: icecream.h
 ****************************/
#ifndef ICECREAM_H
#define ICECREAM_H

#include <string>

class IceCream
{
private:
   std::string flavor;
   float price;

   static float salesTax;

public:
   IceCream();
   IceCream(std::string flavor, float price);

   void setSalesTax(float salesTax);

   float getSalesTax() const { return salesTax; }
   float getTotalPrice() const;
   void prompt();
   void display() const;
};


#endif
