#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Employee
{
protected:
   string name;

public:
   string getName() const { return name; }
   void setName(string name) { this->name = name; }
   
   virtual void display() = 0;
   virtual int getPayCheck() = 0;
};

class HourlyEmployee : public Employee
{
private:
   int hourlyWage;
   int hours;
   
public:
   int getHourlyWage() const { return hourlyWage; }
   void setHourlyWage(int hourlyWage) { this->hourlyWage = hourlyWage; }
   int getHours() const { return hours; }
   void setHours(int hours) { this->hours = hours; }

   
   void display()
   {
      cout << name << " - " << hourlyWage << "/hour\n";
   }

   int getPayCheck()
   {
      int pay;
      pay = hourlyWage * hours;
      return pay;
   }

};

class SalaryEmployee : public Employee
{
private:
   int salary;

public:
   int getSalary() const { return salary; }
   void setSalary(int salary) { this->salary = salary; }
   
   void display()
   {
      cout << name << " - " << salary << "/year\n";
   }

   int getPayCheck()
   {
      int pay;
      pay = salary / 24;
      return pay;
   }
};

int main()
{
   vector<Employee*> v;

   for (int i = 0; i < 3; i++)
   {
      char input;
      cout << "h or s: ";
      cin >> input;

      string name;
      int rate;

      switch (input)
      {
         case 'h':
         {
            int hours;
            
            HourlyEmployee* temp = new HourlyEmployee;
            cout << "name: ";
            cin >> name;

            cout << "rate: ";
            cin >> rate;

            cout << "hour: ";
            cin >> hours;

            temp->setName(name);
            temp->setHourlyWage(rate);
            temp->setHours(hours);
            
            v.push_back(temp);
            
            break;
         }  
         case 's':
         {
            SalaryEmployee* temp = new SalaryEmployee;
            cout << "name: ";
            cin >> name;

            cout << "rate: ";
            cin >> rate;

            temp->setName(name);
            temp->setSalary(rate);

            v.push_back(temp);
            
            break;
         }  
         default:
            break;
      }
   }

   for (int i = 0; i < v.size(); i++)
   {
      v[i]->display();
      cout << "Paycheck: ";
      cout << v[i]->getPayCheck();
      cout << endl;
   }

   for (int i = 0; i < v.size(); i++)
   {
      delete v[i];
   }
   
   return 0;
}
