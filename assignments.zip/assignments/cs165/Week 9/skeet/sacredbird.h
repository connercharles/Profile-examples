/***********************************************************************
* Header File:
*    SACREDBIRD : This is the clay pigeon you do NOT want to hit
* Author:
*    Conner Charles
* Summary:
*	 This class draws the bird.
************************************************************************/
#ifndef SACREDBIRD_H
#define SACREDBIRD_H

/*********************************************
* SACREDBIRD
* This is the sacred (star) bird class
*********************************************/
#include "bird.h"
class SacredBird : public Bird
{
public:
	SacredBird();
	~SacredBird();

	void draw() const;
};

#endif