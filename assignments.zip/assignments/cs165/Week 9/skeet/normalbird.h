/***********************************************************************
* Header File:
*    NORMALBIRD : This is just a normal clay pigeon
* Author:
*    Conner Charles
* Summary:
*	 This class draws the bird.
************************************************************************/
#ifndef NORMALBIRD_H
#define NORMALBIRD_H

/*********************************************
* NORMALBIRD
* This is the average bird class
*********************************************/
#include "bird.h"
class NormalBird : public Bird
{
public:
	NormalBird();
	~NormalBird();

	void draw() const;
};

#endif