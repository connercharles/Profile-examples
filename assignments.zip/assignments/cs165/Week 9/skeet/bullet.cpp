/***********************************************************************
* Source File:
*    BULLET : This is a class that represents the objects that the user
* shoots to hit the birds
* Author:
*   Conner Charles
* Summary:
* 	 This class cannot do anything other than have a bullet shot at a
*	 specific velocity and the direction of the gun shooting.
************************************************************************/

#include <math.h> // used for sin, cos, and M_PI
#define _USE_MATH_DEFINES
const float BULLET_SPEED = 10.0;
//float angle = 60.0;

#include "bullet.h"

Bullet::Bullet(float direction)
{
	setPosition(Point(200, -200));
	setAlive(true);

	// Gets the velocity according to rifle's current direction
	shoot(direction);
}

Bullet::~Bullet()
{
}

void Bullet::shoot(float angle)
{
	// Sets bullet's velocity
	velocity.setDx( BULLET_SPEED * (-sin(M_PI / 180.0 * angle)));
	velocity.setDy( BULLET_SPEED * (cos(M_PI / 180.0 * angle)));

}

void Bullet::draw() const
{
	drawDot(position);
}