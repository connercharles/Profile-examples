/***********************************************************************
* Header File:
*    RIFLE : A class of the user's way to interact with the game
* Author:
*    Conner Charles
* Summary:
*    This class can move the rectangle (rifle) left or right on the 
*	 screen. It has a direction showing the angle between the rifle and 
*	 the axes.
************************************************************************/

#ifndef RIFLE_H
#define RIFLE_H

#include "bullet.h"
#include "point.h"

/*********************************************
* RIFLE
* The user's way to play the game
*********************************************/
class Rifle
{
private:
	Point position;
	float direction;

	// Shape of the rectangle
	static const int WIDTH;
	static const int HEIGHT;

	// Limits of the screen
	static const int BOTLIMIT;
	static const int TOPLIMIT;

public:
	// Constructor
	Rifle();
	~Rifle();

	// Getters
	Point getPosition() const { return position; }
	float getDirection() const { return direction; }

	// Setters
	void setPosition(Point position);
	void setDirection(float direction);

	void draw() const;
	void moveRifle(int changeMove);

};

#endif