/***********************************************************************
* Header File:
*    FLYING OBJECT : A class that all flying objects will be inheriting from
* Author:
*    Conner Charles
* Summary:
*    This is the base class for bullet and birds. It keeps track of whether
*	 the object has left the bounds of the screen. It also keeps track of
*	 the movement and velocity of the object in advancing it.
************************************************************************/

#ifndef FLYINGOBJECT_H
#define FLYINGOBJECT_H

#include "velocity.h"
#include "point.h"
#include "uiDraw.h"

/**************************************
* Flying Object Class
* The initial class of all moving objects in the game.
* This class cannot be instantiated.
***************************************/
class FlyingObject
{
protected:
	Velocity velocity;
	Point position;
	float direction;
	bool alive;
	int radius;

	// Checks to see if the object is in the right bounds
	void collide();

public:
	// Constructors
	FlyingObject();
	~FlyingObject();

	// Getters
	Velocity getVelocity() const { return velocity; }
	Point getPosition() const { return position; }
	float getDirection() const { return direction; }
	bool isAlive() const { return alive; }
	int getRadius() const { return radius; }

	// Setters
	void setVelocity(Velocity velocity);
	void setPosition(Point position);
	void setDirection(float direction);
	void setAlive(bool alive);
	void setRadius(int radius);

	virtual void draw() const = 0;	
	void advance();
};

#endif