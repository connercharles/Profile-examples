/***********************************************************************
* Header File:
*    VELOCITY : A class representing the object's velocity/inertia
* Author:
*    Conner Charles
* Summary:
*    The velocity uses the change in x and the change in y to measure 
*	 the object's current movement. It can also add onto the current 
*	 dx and dy.
************************************************************************/

#ifndef VELOCITY_H
#define VELOCITY_H

/**************************************
* Velocity Class
* The object's inertia
***************************************/
class Velocity
{
private:
	float dx;
	float dy;

public:
	// Constructors
	Velocity();
	Velocity(float dx, float dy);

	// Getters
	float getDx()	const { return dx; }
	float getDy()	const { return dy; }

	// Setters
	void setDx(float dx);
	void setDy(float dy);

	void addOntoDx(float dx);
	void addOntoDy(float dy);
};

#endif // Velocity File