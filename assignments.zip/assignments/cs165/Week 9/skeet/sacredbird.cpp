/***********************************************************************
* Source File:
*    SACREDBIRD : This is a clay pigeon you do NOT want to hit
* Author:
*   Conner Charles
* Summary:
* 	 This is a simple class of one of the birds in the game. It can only
*	 draw where it is and set the variables to its default settings.
************************************************************************/
#include "sacredbird.h"

/***************************************
* SACREDBIRD :: SACREDBIRD
* Sets the variables to default settings
***************************************/
SacredBird::SacredBird()
{
	health = 1;
	reward = -10;

	setTough(false);
	setAlive(true);
	fly();
}

/***************************************
* SACREDBIRD :: SACREDBIRD
* Does nothing
***************************************/
SacredBird::~SacredBird()
{
}

/***************************************
* SACREDBIRD :: DRAW
* Draws the sacred bird (looks like a star)
***************************************/
void SacredBird::draw() const
{
	drawSacredBird(getPosition(), getRadius());
}