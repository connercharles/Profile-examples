/***********************************************************************
* Source File:
*    NORMALBIRD : This is your average clay pigeon
* Author:
*   Conner Charles
* Summary:
* 	 This is a simple class of one of the birds in the game. It can only
*	 draw where it is and set the variables to its default settings.
************************************************************************/
#include "normalbird.h"

/***************************************
* NORMALBIRD :: NORMALBIRD
* Sets the variables to default settings
***************************************/
NormalBird::NormalBird()
{
	health = 1;
	reward = 1;

	setTough(false);
	setAlive(true);
	fly();
}

/***************************************
* NORMALBIRD :: ~NORMALBIRD
* Does nothing
***************************************/
NormalBird::~NormalBird()
{
}

/***************************************
* NORMALBIRD :: DRAW
* Draws the normal bird
***************************************/
void NormalBird::draw() const
{
	drawCircle(getPosition(), getRadius());
}