/****************************************
 * The game of Skeet
 ****************************************/

#include "uiDraw.h"
#include "uiInteract.h"
#include "point.h"
#include "flyingobject.h"
#include "rifle.h"
#include "bird.h"
#include "normalbird.h"
#include "sacredbird.h"
#include "toughbird.h"

#include <vector>

using std::vector;

/*****************************************
 * GAME
 * The main game class containing all the state
 *****************************************/
class Game
{
public:
   // create the game
	Game(Point tl, Point br) : topLeft(tl), bottomRight(br),
		TIMERSET(40), score(0)
	{ 
		timer = TIMERSET;
		bird = new Bird; 
		rifle.setPosition(bottomRight);
	}

	~Game();

   // handle user input for specific levels
   void handleInput(const Interface & ui);

   // advance the game for specific gameplay
   void advance();
   void advanceSkeet();
   void advanceLander();

   // checks to see if things collided
   bool collision(Point ufo1, Point ufo2, int radius);
         
   // draw stuff for specific levels
   void draw(const Interface & ui);

   void cleanBulletVector();

private:
   Point topLeft;
   Point bottomRight;

   // For skeet
   Rifle rifle;
   Bird* bird;
   
   vector<Bullet> bullets;

   int timer;
   int score;

   const int TIMERSET;
   static const int TOUGHBONUS;
};

const int MOVERIFLELEFT = 3;
const int MOVERIFLERIGHT = -3;
const int BOTLIMIT = 0;
const int TOPLIMIT = 90;

const int Game::TOUGHBONUS = 2;

/***************************************
* GAME :: ~Game
* Destructor of the game class, deletes bird
***************************************/
Game::~Game()
{
	delete bird;
}

/***************************************
 * GAME :: COLLISION
 * Takes two points and checks to see if the first point has
 * hit the second, if so the it returns true.
 ***************************************/
bool Game::collision(Point ufo1, Point ufo2, int radius)
{
   // Distance formula
   float distance = sqrt(pow((ufo1.getX() - ufo2.getX()), 2)
                         + pow((ufo1.getY() - ufo2.getY()), 2));

   if (distance <= radius)
   {
      return true;
   }

   return false;
}

/***************************************
 * GAME :: ADVANCE 
 * advance the game one unit of time
 ***************************************/
void Game::advance()
{
	if (!bird->isAlive())
	{
		if (timer <= 0)
		{
			delete bird;
			timer = TIMERSET;

			switch (random(1, 100) % 3)
			{
			case 0:
				bird = new NormalBird;
				break;
			case 1:
				bird = new SacredBird;
				break;
			case 2:
				bird = new ToughBird;
				break;
			default:
				break;
			}
		}
		else
		{
			timer--;
		}
	}
	// if the bird is alive
	else
	{
		bird->advance();
		bird->checkAlive();

		// Checks for collision between bullets and bird
		for (unsigned i = 0; i < bullets.size(); i++)
		{
			if (collision(bullets[i].getPosition(),
				bird->getPosition(), bird->getRadius()))
			{
				bullets[i].setAlive(false);
				bird->hit();
				score += bird->getReward();

				if (bird->isTought())
				{
					score += TOUGHBONUS;
				}
			}
		}
	}

	for (unsigned int i = 0; i < bullets.size(); i++)
	{
		bullets[i].advance();
	}

	cleanBulletVector();
}

/***************************************
* GAME :: CLEAN BULLET VECTOR
* Goes through the bullet vector and erases dead bullets
***************************************/
void Game::cleanBulletVector()
{
	std::vector<Bullet>::iterator itBullet = bullets.begin();
	
	// checks to see if the bullet is alive, 
	// if not it deletes from the vector
	while (itBullet != bullets.end())
	{
		if (!itBullet->isAlive())
		{
			itBullet = bullets.erase(itBullet);
		}
		else
		{
			itBullet++;
		}
	}
}

/***************************************
 * GAME :: input
 * accept input from the user
 ***************************************/
void Game :: handleInput(const Interface & ui)
{
	if (ui.isLeft())
	{
		rifle.moveRifle(MOVERIFLELEFT);
	}
	else if (ui.isRight())
	{
		rifle.moveRifle(MOVERIFLERIGHT);
	}

	if (ui.isSpace())
	{
		Bullet newBullet(rifle.getDirection());
		bullets.push_back(newBullet);
	}
}

/*********************************************
 * GAME :: DRAW
 * Draw everything on the screen
 *********************************************/
void Game :: draw(const Interface & ui)
{
	rifle.draw();

	// draws bullets
	for (unsigned int i = 0; i < bullets.size(); i++)
	{
		if (bullets[i].isAlive())
		{
			bullets[i].draw();
		}
	}

	if (bird->isAlive())
	{
		bird->draw();
	}

	drawNumber(Point(-190, 190), score);
}

/*************************************
 * All the interesting work happens here, when
 * I get called back from OpenGL to draw a frame.
 * When I am finished drawing, then the graphics
 * engine will wait until the proper amount of
 * time has passed and put the drawing on the screen.
 **************************************/
void callBack(const Interface *pUI, void *p)
{
   Game *pGame = (Game *)p;

   pGame->advance();
   pGame->handleInput(*pUI);
   pGame->draw(*pUI);
}

/*********************************
 * Main is pretty sparse.  Just initialize
 * the game and call the display engine.
 * That is all!
 *********************************/
int main(int argc, char ** argv)
{
   Point topLeft(-200, 200);
   Point bottomRight(200, -200);

   Interface ui(argc, argv, "Skeet - Conner Charles", topLeft, bottomRight);
   Game game(topLeft, bottomRight);
   ui.run(callBack, &game);
   
   return 0;
}
