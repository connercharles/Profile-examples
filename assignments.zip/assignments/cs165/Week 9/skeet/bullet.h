/***********************************************************************
* Header File:
*    BULLET : This class is the object that goes from the rifle and 
*	 interacts with the birds
* Author:
*    Conner Charles
* Summary:
*	 The bullet is able to take the current position of its firing object
*	 and have a set velocity added to it.
************************************************************************/
#ifndef BULLET_H
#define BULLET_H

#include "flyingobject.h"

/*********************************************
* BULLET
* The projectile class that hits the birds
*********************************************/
class Bullet : public FlyingObject
{
private:
	void shoot(float angle);

public:
	Bullet(float direction);
	~Bullet();

	void draw() const;
};

#endif