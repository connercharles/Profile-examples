/***********************************************************************
* Source File:
*   FLYINGOBJECT : The representation of the moving objects in the game
* Author:
*   Conner Charles
* Summary:
*	This class cannot be instantiated. It keeps track of the the position
*	of the object and checks to see if it is within the screen, and it
*	moves the object according to its velocity.
************************************************************************/

#include "flyingobject.h"

const int UPPER_X_LIMIT = 200;
const int LOWER_X_LIMIT = -200;
const int UPPER_Y_LIMIT = 200;
const int LOWER_Y_LIMIT = -200;

/***************************************
* FLYINGOBJECT :: FLYINGOBJECT
* Does nothing b/c you cannot instantiate this class
***************************************/
FlyingObject::FlyingObject()
{
}

/***************************************
* FLYINGOBJECT :: ~FLYINGOBJECT
* Does nothing
***************************************/
FlyingObject::~FlyingObject()
{
}

/***************************************
* FLYINGOBJECT :: SET VELOCITY
* Sets passed in parameter as the new value
***************************************/
void FlyingObject::setVelocity(Velocity velocity)
{
	this->velocity = velocity;
}

/***************************************
* FLYINGOBJECT :: SET POSITION
* Sets passed in parameter as the new value
***************************************/
void FlyingObject::setPosition(Point position)
{
	this->position = position;
}

/***************************************
* FLYINGOBJECT :: SET DIRECTION
* Sets passed in parameter as the new value
***************************************/
void FlyingObject::setDirection(float direction)
{
	this->direction = direction;
}

/***************************************
* FLYINGOBJECT :: SET ALIVE
* Sets passed in parameter as the new value
***************************************/
void FlyingObject::setAlive(bool alive)
{
	this->alive = alive;
}

/***************************************
* FLYINGOBJECT :: SET RADIUS
* Takes the parameter and sets it as the new value.
***************************************/
void FlyingObject::setRadius(int radius)
{
	this->radius = radius;
}

/***************************************
* FLYINGOBJECT :: ADVANCE
* Moves the object according to its velocity
***************************************/
void FlyingObject::advance()
{
	if (alive)
	{
		position.addX(velocity.getDx());
		position.addY(velocity.getDy());

		collide();
	}
}

/***************************************
* FLYINGOBJECT :: COLLIDE
* Checks the position of the object to make sure
* it is in the bounds of the screen, if not then
* it sets alive to false. (Kills it)
***************************************/
void FlyingObject::collide()
{
	// Basically if the point goes off the screen
	if (position.getX() >= UPPER_X_LIMIT // X too far right
		|| position.getX() <= LOWER_X_LIMIT // X too far left
		|| position.getY() >= UPPER_Y_LIMIT // Y too high
		|| position.getY() <= LOWER_Y_LIMIT) // Y too low
	{
		alive = false; // Kill b/c hit something
	}
}