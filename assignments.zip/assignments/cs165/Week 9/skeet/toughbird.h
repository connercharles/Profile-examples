/***********************************************************************
* Header File:
*    TOUGHBIRD : This is one strongest the clay pigeons in the world
* Author:
*    Conner Charles
* Summary:
*	 This class draws the bird and has a special start velocity different
*	 from the other birds.
************************************************************************/
#ifndef TOUGHBIRD_H
#define TOUGHBIRD_H

/*********************************************
* TOUGHBIRD
* This is the strong bird class
*********************************************/
#include "bird.h"

class ToughBird : public Bird
{
private:
	virtual void fly();

public:
	ToughBird();
	~ToughBird();

	virtual void draw() const;
};

#endif