/***********************************************************************
* Source File:
*    BIRD : The father class of each bird
* Author:
*   Conner Charles
* Summary:
* 	 This class cannot be instantiated. It describes the details of the
*	 Bird methods, it sets the bird's starting position and velocity of
*	 checks to see if the bird is alive.
************************************************************************/
#include "bird.h"
#include "uiDraw.h"

const int UPPER_SCREEN_BOUND = 200;
const int LOWER_SCREEN_BOUND = -200;
const int BIRD_RADIUS = 20;

/***************************************
* BIRD :: BIRD
* Sets the member variables as default values
***************************************/
Bird::Bird()
{
	setAlive(false);
	fly();
	radius = BIRD_RADIUS;
}

/***************************************
* BIRD :: SET HEALTH
* Takes the parameter and sets it as the new value.
***************************************/
void Bird::setHealth(int health)
{
	this->health = health;
}

/***************************************
* BIRD :: SET REWARD
* Takes the parameter and sets it as the new value.
***************************************/
void Bird::setReward(int reward)
{
	this->reward = reward;
}

/***************************************
* BIRD :: SET TOUGH
* Takes the parameter and sets it as the new value.
***************************************/
void Bird::setTough(bool tough)
{
	this->tough = tough;
}

/***************************************
* BIRD :: DRAW
* Does nothing, just is there as a virtual method
***************************************/
void Bird::draw() const
{

}

/***************************************
* BIRD :: FLY
* Sets the random start position of the bird to the left side of the
* screen. Then it sets a random velocity to the bird.
***************************************/
void Bird::fly()
{
	int startPositionY = random(LOWER_SCREEN_BOUND, UPPER_SCREEN_BOUND);

	Point startPosition(LOWER_SCREEN_BOUND, startPositionY);

	Velocity tempVel = getVelocity();

	if (startPositionY < 0)
	{
		tempVel.setDx(random(3, 7)); // random max is actually the number - 1
		tempVel.setDy(random(1, 4));
	}
	else
	{
		tempVel.setDx(random(3, 7));
		tempVel.setDy(random(-4, 0));
	}

	setVelocity(tempVel);
	setPosition(startPosition);
}

/***************************************
* BIRD :: CHECK ALIVE
* Checks if the bird is alive according to the health
***************************************/
void Bird::checkAlive()
{
	if (health <= 0)
	{
		setAlive(false);
	}
}

/***************************************
* BIRD :: HIT
* Simulates a hit to the bird and decrements the bird's health
***************************************/
void Bird::hit()
{
	setHealth(getHealth() - 1);
}