/***********************************************************************
* Source File:
*    TOUGHBIRD : This is one strongest the clay pigeons in the world
* Author:
*   Conner Charles
* Summary:
* 	 This is a simple class of one of the birds in the game. It can only
*	 draw where it is and set the variables to its default settings.
************************************************************************/
#include "toughbird.h"

const int UPPER_SCREEN_BOUND = 200;
const int LOWER_SCREEN_BOUND = -200;

/***************************************
* TOUGHBIRD :: TOUGHBIRD
* Sets the variables to default settings
***************************************/
ToughBird::ToughBird()
{
	health = 3;
	reward = 1;

	setTough(true);
	setAlive(true);
	fly();
}

/***************************************
* TOUGHBIRD :: ~TOUGHBIRD
* Does nothing
***************************************/
ToughBird::~ToughBird()
{
}

/***************************************
* TOUGHBIRD :: FLY
* Sets the random start position of the bird to the left side of the
* screen. Then it sets a random velocity to the bird. Tough birds are 
* slower than other birds.
***************************************/
void ToughBird::fly()
{
	int startPositionY = random(LOWER_SCREEN_BOUND, UPPER_SCREEN_BOUND);

	Point startPosition(LOWER_SCREEN_BOUND, startPositionY);

	Velocity tempVel = getVelocity();

	if (startPositionY < 0)
	{
		tempVel.setDx(random(2, 5)); // random max is (value - 1)
		tempVel.setDy(random(1, 4));
	}
	else
	{
		tempVel.setDx(random(2, 5));
		tempVel.setDy(random(-3, 0));
	}

	setVelocity(tempVel);
	setPosition(startPosition);
}

/***************************************
* TOUGHBIRD :: DRAW
* Draws the tough bird
***************************************/
void ToughBird::draw() const
{
	drawToughBird(getPosition(), getRadius(), health);
}