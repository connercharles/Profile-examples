/***********************************************************************
* Header File:
*    BIRD : The father class of each bird
* Author:
*    Conner Charles
* Summary:
*	 Each bird class inherits from this class as a part of a bird.
*	 This class sets the start position and velocity of the bird and
*	 checks to make sure it is alive.
************************************************************************/
#ifndef BIRD_H
#define BIRD_H

#include "flyingobject.h"

/*********************************************
* BIRD
* The father class of each bird
*********************************************/
class Bird : public FlyingObject
{
protected:
	int health;
	int reward;
	bool tough;

	// Sets its random start position and velocity
	virtual void fly();

public:
	// Constructor
	Bird();

	// Getters
	int getHealth() const { return health; }
	int getReward() const { return reward; }
	int isTought() const { return tough; }

	// Setters
	void setHealth(int health);
	void setReward(int reward);
	void setTough(bool tough);

	virtual void draw() const;
	void hit();
	void checkAlive();
};

#endif