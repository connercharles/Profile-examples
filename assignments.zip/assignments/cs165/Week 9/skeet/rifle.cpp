/***********************************************************************
* Source File:
*    RIFLE : A class of the user's way to interact with the game
* Author:
*   Conner Charles
* Summary:
*	 Declares the details of the rifle's methods. Can move the rifle's
*	 direction, and it can draw the rectangle.
************************************************************************/

#include "rifle.h"
#include "uiDraw.h"

const int Rifle::WIDTH = 10;
const int Rifle::HEIGHT = 80;

/***************************************
* RIFLE :: RIFLE
* Sets the Rifle's variables to a default value
***************************************/
Rifle::Rifle() : position(200, -200)
{
	direction = 45;
}

/***************************************
* RIFLE :: ~RIFLE
* Does nothing
***************************************/
Rifle::~Rifle()
{
}

/***************************************
* RIFLE :: SET POSITION
* Takes the parameter and sets it as the new value.
***************************************/
void Rifle::setPosition(Point position)
{
	this->position = position;
}

/***************************************
* RIFLE :: SET DIRECTION
* Takes the parameter and sets it as the new value.
***************************************/
void Rifle::setDirection(float direction)
{
	this->direction = direction;
}

/***************************************
* RIFLE :: DRAW
* Uses the variables of rifle to draw a rantangle
***************************************/
void Rifle::draw() const
{
	drawRect(position, WIDTH, HEIGHT, direction);
}

/***************************************
* RIFLE :: MOVE RIFLE
* Moves the rifles direction according to the arrow key pressed
***************************************/
void Rifle::moveRifle(int changeMove)
{
	direction += changeMove;

	if (direction <= 0)
	{
		direction = 0;
	}

	if (direction >= 90)
	{
		direction = 90;
	}
}