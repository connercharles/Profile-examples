#include <iostream>

using namespace std;

class Point
{
private:
   int x;
   int y;

public:
   int getX() const { return x; }
   int getY() const { return y; }

   void setX(int x) { this->x = x; }
   void setY(int y) { this->y = y; }

   void display() const
   {
      cout << "(" << x << ", " << y << ")\n";
   }

   friend ostream & operator<<(ostream &out, Point &p);
   friend bool operator==(const Point &p1, const Point &p2);
};

ostream & operator<<(ostream &out, Point &p)
{
   out << p.x << ", " << p.y;
   return out;
}

bool operator==(const Point &p1, const Point &p2)
{
   return (p1.x == p2.x
           && p1.y == p2.y);
}

int main()
{
   Point p;
   p.setX(3);
   p.setY(5);

   cout << p << endl;

   Point p2;
   p.setX(3);
   p.setY(5);

   if (p == p2)
   {
      cout << "Equal!\n";
   }
   
   return 0;
}
