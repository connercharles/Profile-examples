a.out : date.o check04b.cpp
        g++ date.o check04b.cpp

date.o : date.cpp date.h
         g++ -c date.cpp

tar : *.h *.cpp makefile
      tar -cf check04b.tar makefile *.h *.cpp

clean : rm -f *.cpp~ *.h~ makefile~ .tar a.out *.o
