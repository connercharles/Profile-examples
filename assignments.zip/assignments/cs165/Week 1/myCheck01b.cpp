/***********************************************************************
* Program:
*    Checkpoint 01b, Arrays      
*    Brother Burton, CS165
* Author:
*    Conner Charles
* Summary: 
*    Summaries are not necessary for checkpoint assignments.
* ***********************************************************************/

#include <iostream>
using namespace std;

/**********************************************************************
 * Function: getSize
 * Purpose: Prompts user for size of list.
 ***********************************************************************/
int getSize()
{
   cout << "Enter the size of the list: ";
   int size;
   cin >> size;
   return size;
}

/**********************************************************************
 * Function: getList
 * Purpose: Prompts user to input numbers into the array/list.
 ***********************************************************************/
void getList(int userList[], int size)
{
   int userListInput;
   for(int i = 0; i < size; i++)
   {
      cout << "Enter number for index " << i << ": ";
      cin >> userListInput;
      userList[i] = userListInput;
   }
}

/**********************************************************************
 * Function: displayMultiples
 * Purpose: Prompts user to input numbers into the array/list.
 ***********************************************************************/
void displayMultiples(int userList[], int size)
{
   cout << endl << "The following are divisible by 3:" << endl;
   
   for(int i = 0; i < size; i++)
   {
      if(userList[i] % 3 == 0)
      {
         cout << userList[i] << endl;
      }
   }
}

/**********************************************************************
 * Function: main
 * Purpose: This is the entry point and driver for the program.
 ***********************************************************************/
int main()
{
   int size;
   size = getSize();
   int userList[size];
   
   getList(userList, size);
   displayMultiples(userList, size);
   return 0;
}
