/***********************************************************************
* Program:
*    Assignment 01, Genetic Genealogy  
*    Brother Burton, CS165
* Author:
*    Conner Charles
* Summary: 
*    This program will ask the user for their DNA sequence, then the number
*    of potential relative they wish to test. After that, the program
*    prompts the user for their names and DNA sequences. Then the program
*    compares the user's DNA sequence to each of the relative's DNA sequences.
*    It computes the probability of that person being a relative in a
*    percentage.
*
*    Estimated:  1.5 hrs   
*    Actual:     4.5 hrs
*      My most difficult part was reading in the DNA of the relatives
*      then being able to compare them to the user DNA.
************************************************************************/

#include <iostream>
#include <string>
using namespace std;

const int SEQUENCE_LENGTH = 10;

/**********************************************************************
 * Name: getUserDna
 * Purpose: Prompts user to enter their DNA sequence, then returns it.
 ***********************************************************************/
string getUserDna()
{
   cout << "Enter your DNA sequence: ";
   string userDna;
   cin >> userDna;
   return userDna;
}

/**********************************************************************
 * Name: getRelAmount
 * Purpose: Prompts user to input how many potential relatives they
 * have. Returns that number.
 ***********************************************************************/
int getRelAmount()
{
   cout << "Enter the number of potential relatives: ";
   int amountOfRels;
   cin >> amountOfRels;
   cout << endl;
   return amountOfRels;
}

/**********************************************************************
 * Name: getRelNames
 * Purpose: Prompts user to input potential relative names, then stores
 * the names into an array.
 ***********************************************************************/
void getRelNames(string relativeNames[], int relAmount)
{
   for (int i = 0; i < relAmount; i++)
   {
      cout << "Please enter the name of relative #" << i + 1 << ": ";
      // +1 b/c arrays are zero indexed.
      string relNameEntry;
      cin >> relNameEntry;
      relativeNames[i] = relNameEntry;
   }
   cout << endl;
}

/**********************************************************************
 * Name: getRelDna
 * Purpose: Prompts user to input potential relative names, then stores
 * the names into an array.
 ***********************************************************************/
void getRelDna(string relDna[], string relativeNames[], int relAmount)
{
   for (int i = 0; i < relAmount; i++)
   {
      cout << "Please enter the DNA sequence for " << relativeNames[i] << ": ";
      cin >> relDna[i];
   }
   cout << endl;
}

/**********************************************************************
 * Name: computePercentages
 * Purpose: This function reads in a float and then calculates the
 * probability of that DNA sequence being a relative. Returns the percentage.
************************************************************************/
int computePercentages(float counter)
{
   int percentMatch;
   percentMatch = (counter / SEQUENCE_LENGTH) * 100;
   // * 100 To put the decimal into a percentage
   return percentMatch;   
}

/**********************************************************************
 * Name: checkSequences
 * Purpose: Takes in the user's DNA sequence and compares each of the
 * relative's DNA sequences to see how much of the the sequences are
 * similar. Then calls on a function and receives the percentage match
 * and displays the percentages of each potential relative.
 ***********************************************************************/
void checkSequences(string userDna, string relDna[], int relAmount,
                    string relativeNames[])
{
   // Goes through all potential relatives
   for (int i = 0; i < relAmount; i++)
   {
      float counter = 0;
      // Goes through all the user's DNA letters
      for (int j = 0; j < userDna.length(); j++)
      {
         char checker1 = userDna[j];
         string checker2 = relDna[i];
         // Goes through all the DNA letters of the potential relative
            if (checker1 == checker2[j])
            {
               counter++;
            }
      }
      int match;
      match = computePercentages(counter);
      cout << "Percent match for " << relativeNames[i] << ": ";
      cout << match << "%" << endl;  
   }
}

/**********************************************************************
 * Name: main
 * Purpose: This function will receive user's DNA and the amount of relatives.
 * Then receives the names of the potential relatives and the corresponding
 * DNA sequences. Then it checks relative's sequences with the user's and
 * computes the probability of them being relatives. 
 ***********************************************************************/
int main()
{
   string userDna;
   string relDna[SEQUENCE_LENGTH];
   int relAmount;

   userDna = getUserDna();
   relAmount = getRelAmount();
   string* relativeNames = new string[relAmount];
   
   getRelNames(relativeNames, relAmount);
   getRelDna(relDna, relativeNames, relAmount);
   checkSequences(userDna, relDna, relAmount, relativeNames);

   delete[] relativeNames;
   return 0;
}
