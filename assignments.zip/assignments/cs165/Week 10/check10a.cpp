/***********************************************************************
* Program:
*    Checkpoint 10a, Vectors
*    Brother Burton, CS165
* Author:
*    Conner Charles
* Summary: 
*    Summaries are not necessary for checkpoint assignments.
************************************************************************/

#include <iostream>
#include <vector>
#include <string>

using namespace std;

/**********************************************************************
 * Function: main
 * Purpose: This is the entry point and driver for the program.
 ***********************************************************************/
int main()
{
   vector<int> intV;

   int inputI;

   do
   {
      cout << "Enter int: ";
      cin >> inputI;

      if (inputI != 0)
      {
         intV.push_back(inputI);
      }
   } while (inputI != 0);

   cout << "Your list is:" << endl;
   
   for (int i = 0; i < intV.size(); i++)
   {
      cout << intV[i] << endl;
   }

   vector<string> stringV;

   string inputS;

   cout << endl;
   
   do
   {
      cout << "Enter string: ";
      cin >> inputS;

      if (inputS != "quit")
      {
         stringV.push_back(inputS);
      }
   } while (inputS != "quit");

   cout << "Your list is:" << endl;
   
   vector<string>::iterator it;

   for (it = stringV.begin(); it != stringV.end(); it++)
   {
      cout << *it << endl;
   }
   
   return 0;
}


