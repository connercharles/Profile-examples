/***********************************************************************
 * Implementation:
 *    NOW SERVING
 * Summary:
 *    This will contain the implementation for nowServing() as well as any
 *    other function or class implementations you may need
 * Author
 *    Conner Charles
 **********************************************************************/

#include "nowServing.h" // for nowServing() prototype
#include "deque.h"      // for DEQUE
#include <string> // for string
using namespace std;

/************************************************
 * Struct: REQUEST
 * Holds a request's information
 ***********************************************/
struct Request
{
   string course;
   string name;
   int minutes;
   bool emergency;
};

/************************************************
 * DISPLAY
 * displays current serving person
 ***********************************************/
void display(const Request & current)
{
   if (current.emergency)
   {
      cout << "\tEmergency for " << current.name;
      cout << " for class " << current.course << ". ";
      cout << "Time left: " << current.minutes << endl;
   }
   else
   {
      cout << "\tCurrently serving " << current.name;
      cout << " for class " << current.course << ". ";
      cout << "Time left: " << current.minutes << endl;
   }
}

/************************************************
 * ADD NORMAL REQUEST
 * adds user's data into request line for normal request
 ***********************************************/
void addNormalRequest(Deque <Request> & line,
                      const string & instruction)
{
   // Retreive data from user
   Request input;
   input.course = instruction;
   cin >> input.name;
   cin >> input.minutes;
   input.emergency = false;

   // add to back of the deque
   line.push_back(input);
}

/************************************************
 * Struct: REQUEST
 * adds user's data into request line for emergency request
 ***********************************************/
void addEmergencyRequest(Deque <Request> & line)
{
   // Retreive data from user
   Request input;
   cin >> input.course;
   cin >> input.name;
   cin >> input.minutes;
   input.emergency = true;

   // add to front of deque
   line.push_front(input);
}

/************************************************
 * NOW SERVING
 * The interactive function allowing the user to
 * handle help requests in the Linux lab
 ***********************************************/
void nowServing()
{
   // instructions
   cout << "Every prompt is one minute.  The following input is accepted:\n";
   cout << "\t<class> <name> <#minutes>    : a normal help request\n";
   cout << "\t!! <class> <name> <#minutes> : an emergency help request\n";
   cout << "\tnone                         : no new request this minute\n";
   cout << "\tfinished                     : end simulation\n";

   // book keeping
   string instruction;
   int minute = 0;
   Deque <Request> line;
   Request currentPerson;

   // preset some values
   currentPerson.minutes = 0;
      
   while (instruction != "finished")
   {
      // prompt user
      cout << "<" << minute << "> ";
      cin >> instruction;
      
      // emergency help
      if (instruction == "!!")
      {
         addEmergencyRequest(line);
      }
      // no new request
      else if (instruction == "none")
      {
         // do nothing        
      }
      // if finished break out of loop
      else if (instruction == "finished")
      {
         break;
      }
      // just normal help
      else
      {
         addNormalRequest(line, instruction);
      }

      // check if there is someone is being helped
      if (currentPerson.minutes > 1)
      {
         // decrament time left
         currentPerson.minutes--;
      }
      // not helping anyone right now/ time ran out
      else if (!line.empty())
      {
         // help the next person in line
         // takes data from front
         currentPerson.course = line.front().course;
         currentPerson.name = line.front().name;
         currentPerson.minutes = line.front().minutes;
         currentPerson.emergency = line.front().emergency;
         
         // take next person off deque
         line.pop_front();
      }
      // if deque is empty and nobody being helped
      else
      {
         // just so we don't display
         currentPerson.minutes = 0; 
      }

      // only display if there is a current person being helped
      if (currentPerson.minutes > 0)
      {
         display(currentPerson);
      }
      
      // go on to the next minute
      minute++;
   }
   
   // finished!
   cout << "End of simulation\n";
}


