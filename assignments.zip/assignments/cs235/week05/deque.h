/***********************************************************************
* Header:
*    Deque
* Summary:
*    This class contains the notion of a Deque: a bucket to hold
*    data for the user. This is just a starting-point for more advanced
*    constainers such as the vector, set, Deque, Deque, deque, and map
*    which we will build later this semester.
*
*    This will contain the class definition of:
*        Deque         : A class that holds stuff
* Author
*    Br. Helfrich
************************************************************************/

#ifndef Deque_H
#define Deque_H

#include <cassert>
#include <cstddef> // for NULL
#include <new> // for bad_alloc

/************************************************
 * Deque
 * A class that holds stuff
 ***********************************************/
template <class T>
class Deque
{
public:
   // default constructor : empty and kinda useless
  Deque() : numItems(0), pcapacity(0), data(NULL), pfront(0), pback(0) {}

   // copy constructor : copy it
   Deque(const Deque & rhs) throw (const char *);
   
   // non-default constructor : pre-allocate
   Deque(int pcapacity) throw (const char *);
   
   // destructor : free everything
   ~Deque()        { if (pcapacity) delete [] data; }
   
   // is the Deque currently empty
   bool empty() const  { return numItems == 0;         }

   // remove all the items from the Deque
   void clear()        { numItems = 0; pfront = 0; pback = 0; }

   // how many items are currently in the Deque?
   int size() const    { return numItems;              }

   // how much can the array hold in the Deque?
   int capacity() const { return pcapacity; }
   
   // adds the item to the back of the Deque
   void push_back(const T & newItem) throw (const char *);

   // adds the item to the front of the Deque
   void push_front(const T & newItem) throw (const char *);
   
   // take the front item off of the Deque
   void pop_front() throw (const char *);

   // take the back item off of the Deque
   void pop_back() throw (const char *);

   // returns the front value of the Deque
   T & front() throw (const char *);

   // returns the back value of the Deque
   T & back() throw (const char *);
   
   // assignment operator overload
   Deque <T> & operator = (const Deque <T> & rhs) throw (const char *);
   
private:
   T * data;          // dynamically allocated array of T
   int numItems;      // how many items are currently in the Deque?
   int pcapacity;      // how many items can I put on the Deque before full?
   int pfront;         // index in the array
   int pback;

   // checks to see if the array needs to expand
   void checkCapacity() throw (const char *);

   // resets pfront and pback when array is empty
   void resetEmpty();
   
};

/*******************************************
 * Deque :: COPY CONSTRUCTOR
 *******************************************/
template <class T>
Deque <T> :: Deque(const Deque <T> & rhs) throw (const char *)
{
   assert(rhs.pcapacity >= 0);
      
   // do nothing if there is nothing to do
   if (rhs.pcapacity == 0)
   {
      pcapacity = numItems = 0;
      data = NULL;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[rhs.pcapacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate buffer";
   }
   
   // copy over the capacity and size
   assert(rhs.numItems >= 0 && rhs.numItems <= rhs.pcapacity);
   pcapacity = rhs.pcapacity;
   numItems = rhs.numItems;
   pfront = rhs.pfront;
   pback = rhs.pback;

   // copy the items over one at a time using the assignment operator
   for (int i = 0; i < pcapacity; i++)
      data[i] = rhs.data[i];
}

/**********************************************
 * Deque : NON-DEFAULT CONSTRUCTOR
 * Preallocate the Deque to "capacity"
 **********************************************/
template <class T>
Deque <T> :: Deque(int pcapacity) throw (const char *)
{
   assert(pcapacity >= 0);
   
   // do nothing if there is nothing to do
   if (pcapacity == 0)
   {
      this->pcapacity = this->numItems = 0;
      this->data = NULL;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[pcapacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate buffer";
   }
      
   // copy over the stuff
   this->pcapacity = pcapacity;
   this->numItems = 0;
   this->pfront = 0;
   this->pback = 0;

   // initialize the Deque by calling the default constructor
   for (int i = 0; i < pcapacity; i++)
      data[i] = T();
}

/**********************************************
 * Deque :: operator =
 * Allows user to assign two Deques together
 **********************************************/
template <class T>
Deque <T> & Deque <T> :: operator = (const Deque <T> & rhs)
   throw (const char *)
{
   // attempt to allocate
   try
   {
      delete [] data;
      data = new T[rhs.pcapacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a new buffer for Deque";
   }

   // copy over the capacity and size
   assert(rhs.numItems >= 0 && rhs.numItems <= rhs.pcapacity);
   pcapacity = rhs.pcapacity;
   numItems = rhs.numItems;
   pfront = rhs.pfront;
   pback = rhs.pback;
      
   // copy the items over one at a time using the assignment operator
   for (int i = 0; i < pcapacity; i++)
      data[i] = rhs.data[i];
   
   return (*this);
}

/***************************************************
 * Deque :: CHECK CAPACITY
 * Checks the capacity of the array and if it needs room
 * it will double the size allocated.
 **************************************************/
template <class T>
void Deque <T> :: checkCapacity() throw (const char *)
{
   if (pcapacity == 0)
   {
      pcapacity = 1;
      
      // attempt to allocate
      try
      {
         data = new T[pcapacity];
      }
      catch (std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for deque";
      }
   }
   else if (numItems == pcapacity)
   {           
      try
      {
         // allocate the new buffer
         T * bufferNew = new T[pcapacity * 2];

         // copy the items over one at a time using the assignment operator
         // one int to loop through new array, the other to work as a front
         for (int i = 0, j = pfront; i < numItems; i++, j = (j + 1) % pcapacity)
         {
            bufferNew[i] = data[j];
         }

         pcapacity *= 2;
         
         // the rest needs to be filled with the default value for T
         for (int i = numItems; i < pcapacity; i++)
            bufferNew[i] = T();

         // assigns the new array to the old pointer and deletes the old array
         delete [] data;
         data = bufferNew;
      }
      catch(std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for deque";
      }

      // set the front and back to appropriate spots in new array
      pfront = 0;

      if (numItems)
      {
         pback = numItems - 1; // b/c zero indexed
      }
      else
      {
         pback = 0;
      }
   }
}

/**********************************************
 * Deque :: reset empty
 * resets the index's if the array is empty
 **********************************************/
template <class T>
void Deque <T> :: resetEmpty()
{
   if (empty())
   {
      pfront = 0;
      pback = 0;
   }
}

/**********************************************
 * Deque :: push back
 * Takes an item and adds it to the end of the Deque
 **********************************************/
template <class T>
void Deque <T> :: push_back(const T & newItem) throw (const char *)
{
   checkCapacity();

   if (empty())
   {
      data[pback] = newItem;
   }
   else
   {
      // so we don't write over the back
      pback = (pback + 1) % pcapacity;
      
      data[pback] = newItem;
   }
   
   numItems++;
}

/**********************************************
 * Deque :: push front
 * Takes an item and adds it to the front of the Deque
 **********************************************/
template <class T>
void Deque <T> :: push_front(const T & newItem) throw (const char *)
{
   checkCapacity();

   if (empty())
   {
      data[pfront] = newItem;
   }
   else
   {
      // so we don't write over the front
      if (pfront)
      {
         pfront--;
      }
      else // if pfront == 0 wrap to the back
      {
         pfront = pcapacity - 1;
      }
   
      data[pfront] = newItem;
   }
   
   numItems++;
}

/**********************************************
 * Deque :: pop front
 * Takes the first item off of the Deque
 **********************************************/
template <class T>
void Deque <T> :: pop_front() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: unable to pop from the front of empty deque";
   }
   else
   {      
      numItems--;
      
      // for looping through the array
      pfront = (pfront + 1) % pcapacity;
   }

   resetEmpty();
}

/**********************************************
 * Deque :: pop back
 * Takes the last item off of the Deque
 **********************************************/
template <class T>
void Deque <T> :: pop_back() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: unable to pop from the back of empty deque";
   }
   else
   {      
      numItems--;
      
      // for looping through the array
      if (pback)
      {
         pback--;
      }
      else
      {
         pback = pcapacity - 1;
      }
   }

   resetEmpty();
}

/**********************************************
 * Deque :: front
 * Returns the front amount of the Deque
 **********************************************/
template <class T>
T & Deque <T> :: front() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: unable to access data from an empty deque";
   }
   else
   {
      return data[pfront];
   }
}

/**********************************************
 * Deque :: back
 * Returns the back amount of the Deque
 **********************************************/
template <class T>
T & Deque <T> :: back() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: unable to access data from an empty deque";
   }
   else
   {
      return data[pback];
   }
}

#endif // Deque_H

