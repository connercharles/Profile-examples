/***********************************************************************
* Header:
*    Hash
* Summary:
*    This class contains the notion of a Hash: a bucket to hold
*    data for the user. This is just a starting-point for more advanced
*    constainers such as the Hash, Hash, Hash, Hash, Hash, and Hash
*    which we will build later this semester.
*
*    This will contain the class definition of:
*        Hash         : A class that holds stuff
* Author
*    Br. Helfrich
************************************************************************/

#ifndef Hash_H
#define Hash_H

#include <list>              // for list
#include <string>            // for string
#define DEFAULT_BUCKETS 100  // default array size
using namespace std;         // for lists and strings

/************************************************
 * Hash
 * A class that holds stuff
 ***********************************************/
template <class T>
class Hash
{
public:
   // default constructor : dynamically allocates the array
   Hash() : numItems(0), numBuckets(DEFAULT_BUCKETS)
   {
      // make the array of lists
      data = new list<T> [numBuckets];
   }
   
   // non-default constructor : takes the number of buckets
   Hash(int buckets) : numItems(0)
   {
      numBuckets = buckets;
      // make the array of lists
      data = new list<T> [numBuckets];
   }

   // copy constructor : copy it
   Hash(const Hash & rhs) throw (const char *);
   
   // destructor : free everything
   ~Hash()        { delete[] data; }
   
   // is the Hash currently empty
   bool empty() const     { return numItems == 0;         }

   // how many items are currently in the Hash?
   int size() const      { return numItems;               }

   // how many items can the Hash hold
   int capacity() const  { return numBuckets;             }
   
   // assignment operator overload
   Hash <T> & operator = (const Hash <T> & rhs) throw (const char *);

   // search for item within tree
   bool find(T key);

   // insert item into the Hash
   void insert(T item);

   // hash function is a pure virtual
   virtual int hash(const T & value) const = 0;
   
protected:
   int numItems;          // how many items are currently in the Hash?
   int numBuckets;        // how many items can I put on the Hash before full?
   list<T> * data;        // make an array of lists that hold the data
};

/****************************************
 * S HASH
 * A simple hash of strings
 ****************************************/
class SHash : public Hash <string>
{
  public:
   SHash(int numBuckets)    throw (const char *) : Hash <string> (numBuckets) {}
   SHash(const SHash & rhs) throw (const char *) : Hash <string> (rhs)        {}

   int hash(const string & value) const
   {
      int total = 0;
      // add up ascii values of every letter in the word
      for (int i = 0; i < value.length(); i++)
      {
         // add the ascii value to the total
         total += int(value[i]);
      }
      // mod the total to fit in the array
      total = total % capacity();
      return total;
   }
};

/*******************************************
 * Hash :: COPY CONSTRUCTOR
 *******************************************/
template <class T>
Hash <T> :: Hash(const Hash <T> & rhs) throw (const char *)
{
   // initialize things to null
   data = NULL;
   try
   {
      // call assignment operator
      *this = rhs;
   }
   catch(bad_alloc)
   {
      throw "Unable to allocate memory for Hash.";
   }
}

/**********************************************
 * Hash :: operator =
 * Allows user to assign two Hashs together
 **********************************************/
template <class T>
Hash <T> & Hash <T> :: operator = (const Hash <T> & rhs) throw (const char *)
{
   // copy over the member variables
   numItems = rhs.numItems;
   numBuckets = rhs.numBuckets;
   // delete old array
   delete[] data;
   try
   {
      // allocate new one
      data = new list<T> [numBuckets];
      // copy lists over from other array
      for (int i = 0; i < numBuckets; i++)
      {
         data[i] = rhs.data[i];
      }
   }
   catch(bad_alloc)
   {
      throw "Unable to allocate memory for Hash.";
   }
}

/**********************************************
 * Hash :: find
 * Finds the index then loops through the list
 * to see if the key is in that list.
 **********************************************/
template <class T>
bool Hash <T> :: find(T key)
{
   // find the index
   int index;
   index = hash(key);

   typename list<T>::iterator it;
   // loop through the list to see if it's there
   for (it = data[index].begin(); it != data[index].end(); it++)
   {
      // if it's in there
      if (*it == key)
      {
         return true;
      }
   }
   
   // if it's not in the list
   return false;
}

/**********************************************
 * Hash :: insert
 * Find the location of the item to be added
 * and adds it to the Hash
 **********************************************/
template <class T>
void Hash<T>::insert(T item)
{
   // find the index
   int index;
   index = hash(item);

   // insert item into list of the location
   data[index].push_back(item);
   // added an item
   numItems++;
}

#endif // Hash_H
