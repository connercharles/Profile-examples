/***********************************************************************
 * Module:
 *    Week 12, Spell Check
 *    Brother Helfrich, CS 235
 * Author:
 *    Conner Charles
 * Summary:
 *    This program will implement the spellCheck() function
 ************************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "spellCheck.h"
#include "hash.h"
using namespace std;

/*****************************************************
 * READ FILE
 * Takes fileName and adds each word in the file to
 * the hash.
 *****************************************************/
void readFile(SHash & dictionary, const string & fileName)
{
   // open file
   ifstream fin(fileName.c_str());
   string word;
   // loop through a retreive data from file
   while(fin >> word)
   {
      // add to Hash
      dictionary.insert(word);
   }
   // close file
   fin.close();
}

/*****************************************
 * SPELL CHECK
 * Prompt the user for a file to spell-check
 ****************************************/
void spellCheck()
{
   // to look up correctly spelled words
   SHash dictionary(500);
   string fileName;

   // read file for dictionary
   fileName = "/home/cs235/week12/dictionary.txt";
   readFile(dictionary, fileName);
   
   // prompt user for file name
   cout << "What file do you want to check? ";
   fileName = "";
   cin >> fileName;

   //*****read other file
   vector <string> misspelled;

   // open file
   ifstream fin(fileName.c_str());
   string word;

   // loop through a retreive data from file
   while(fin >> word)
   {
      // uncap the word if needed, unless it's a name
      if (isupper(word[0]) && word != "Nephi")
      {
         word[0] = tolower(word[0]);
      }
      // see if it's not in the dictionary
      if (!dictionary.find(word))
      {
         // add to the misspelled word list
         misspelled.push_back(word);
      }
   }

   // close file
   fin.close();

   // display data
   if (misspelled.empty())
   {
      cout << "File contains no spelling errors\n";
   }
   else
   {
      cout << "Misspelled: ";
      for (int i = 0; i < (misspelled.size() - 1); i++)
      {
         cout << misspelled[i] << ", ";
      }
      // display the last item
      cout << misspelled[misspelled.size() - 1] << endl;
   }
}
