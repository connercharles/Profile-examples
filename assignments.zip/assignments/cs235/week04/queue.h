/***********************************************************************
* Header:
*    Queue
* Summary:
*    This class contains the notion of a Queue: a bucket to hold
*    data for the user. This is just a starting-point for more advanced
*    constainers such as the vector, set, Queue, queue, deque, and map
*    which we will build later this semester.
*
*    This will contain the class definition of:
*        Queue         : A class that holds stuff
* Author
*    Br. Helfrich
************************************************************************/

#ifndef Queue_H
#define Queue_H

#include <cassert>

/************************************************
 * Queue
 * A class that holds stuff
 ***********************************************/
template <class T>
class Queue
{
public:
   // default constructor : empty and kinda useless
  Queue() : numItems(0), capacity(0), data(NULL), front(0), back(0) {}

   // copy constructor : copy it
   Queue(const Queue & rhs) throw (const char *);
   
   // non-default constructor : pre-allocate
   Queue(int capacity) throw (const char *);
   
   // destructor : free everything
   ~Queue()        { if (capacity) delete [] data; }
   
   // is the Queue currently empty
   bool empty() const  { return numItems == 0;         }

   // remove all the items from the Queue
   void clear()        { numItems = 0; front = 0; back = 0; }

   // how many items are currently in the Queue?
   int size() const    { return numItems;              }

   // how much can the array hold in the Queue?
   int getCapacity() const { return capacity; }
   
   // adds the item to the back of the Queue
   void push(const T & newItem) throw (const char *);

   // take the front item off of the Queue
   T pop() throw (const char *);
   
   // returns the front value of the Queue
   T & getFront() throw (const char *);

   // returns the back value of the Queue
   T & getBack() throw (const char *);
   
   // assignment operator overload
   Queue <T> & operator = (const Queue <T> & rhs) throw (const char *);
   
private:
   T * data;          // dynamically allocated array of T
   int numItems;      // how many items are currently in the Queue?
   int capacity;      // how many items can I put on the Queue before full?
   int front;         // index in the array
   int back;

   // checks to see if the array needs to expand
   void checkCapacity() throw (const char *);

};

/*******************************************
 * Queue :: COPY CONSTRUCTOR
 *******************************************/
template <class T>
Queue <T> :: Queue(const Queue <T> & rhs) throw (const char *)
{
   assert(rhs.capacity >= 0);
      
   // do nothing if there is nothing to do
   if (rhs.capacity == 0)
   {
      capacity = numItems = 0;
      data = NULL;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[rhs.capacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate buffer";
   }
   
   // copy over the capacity and size
   assert(rhs.numItems >= 0 && rhs.numItems <= rhs.capacity);
   capacity = rhs.capacity;
   numItems = rhs.numItems;
   front = rhs.front;
   back = rhs.back;

   // copy the items over one at a time using the assignment operator
   for (int i = 0; i < capacity; i++)
      data[i] = rhs.data[i];
}

/**********************************************
 * Queue : NON-DEFAULT CONSTRUCTOR
 * Preallocate the Queue to "capacity"
 **********************************************/
template <class T>
Queue <T> :: Queue(int capacity) throw (const char *)
{
   assert(capacity >= 0);
   
   // do nothing if there is nothing to do
   if (capacity == 0)
   {
      this->capacity = this->numItems = 0;
      this->data = NULL;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[capacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate buffer";
   }
      
   // copy over the stuff
   this->capacity = capacity;
   this->numItems = 0;
   this->front = 0;
   this->back = 0;

   // initialize the Queue by calling the default constructor
   for (int i = 0; i < capacity; i++)
      data[i] = T();
}

/**********************************************
 * Queue :: operator =
 * Allows user to assign two Queues together
 **********************************************/
template <class T>
Queue <T> & Queue <T> :: operator = (const Queue <T> & rhs)
   throw (const char *)
{
   // attempt to allocate
   try
   {
      delete [] data;
      data = new T[rhs.capacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a new buffer for Queue";
   }

   // copy over the capacity and size
   assert(rhs.numItems >= 0 && rhs.numItems <= rhs.capacity);
   capacity = rhs.capacity;
   numItems = rhs.numItems;
   front = rhs.front;
   back = rhs.back;
      
   // copy the items over one at a time using the assignment operator
   for (int i = 0; i < numItems; i++)
      data[i] = rhs.data[i];

   // the rest needs to be filled with the default value for T
   for (int i = numItems; i < capacity; i++)
      data[i] = T();
   
   return (*this);
}

/***************************************************
 * Queue :: CHECK CAPACITY
 * Checks the capacity of the array and if it needs room
 * it will double the size allocated.
 **************************************************/
template <class T>
void Queue <T> :: checkCapacity() throw (const char *)
{
   if (capacity == 0)
   {
      capacity = 1;
      
      // attempt to allocate
      try
      {
         data = new T[capacity];
      }
      catch (std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for Queue";
      }
   }
   else if (numItems == capacity)
   {           
      try
      {
         // allocate the new buffer
         T * bufferNew = new T[capacity * 2];

         // copy the items over one at a time using the assignment operator
         // one int to loop through new array, the other to work as a front
         for (int i = 0, j = front; i < numItems; i++, j = (j + 1) % capacity)
         {
            bufferNew[i] = data[j];
         }

         capacity *= 2;
         
         // the rest needs to be filled with the default value for T
         for (int i = numItems; i < capacity; i++)
            bufferNew[i] = T();

         // assigns the new array to the old pointer and deletes the old array
         delete [] data;
         data = bufferNew;
      }
      catch(std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for Queue";
      }

      // set the front and back to appropriate spots in new array
      front = 0;

      if (numItems)
      {
         back = numItems; // b/c zero indexed
      }
      else
      {
         back = 0;
      }
   }
}

/**********************************************
 * Queue :: push
 * Takes an item and adds it to the end of the queue
 **********************************************/
template <class T>
void Queue <T> :: push(const T & newItem) throw (const char *)
{
   checkCapacity();

   data[back] = newItem;

   // so we don't write over the back
   back = (back + 1) % capacity;

   numItems++;
}

/**********************************************
 * Queue :: pop
 * Takes the first item off of the Queue and returns it
 **********************************************/
template <class T>
T Queue <T> :: pop() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: attempting to pop from an empty queue";
   }
   else
   {      
      numItems--;

      T poppedItem = data[front];
      
      // for looping through the array
      front = (front + 1) % capacity;
      
      return poppedItem;
   }
}

/**********************************************
 * Queue :: get front
 * Returns the front amount of the Queue
 **********************************************/
template <class T>
T & Queue <T> :: getFront() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: attempting to access an item in an empty queue";
   }
   else
   {
      return data[front];
   }
}

/**********************************************
 * Queue :: get back
 * Returns the back amount of the Queue
 **********************************************/
template <class T>
T & Queue <T> :: getBack() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: attempting to access an item in an empty queue";
   }
   else if (back == 0)
   {
      return data[numItems - 1];
   }
   else
   {
      return data[back - 1];
   }
}

#endif // Queue_H

