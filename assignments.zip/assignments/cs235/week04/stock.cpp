/***********************************************************************
 * Implementation:
 *    STOCK
 * Summary:
 *    This will contain the implementation for stocksBuySell() as well
 *    as any other function or class implementation you need
 * Author
 *    Conner Charles
 **********************************************************************/

#include <iostream>    // for ISTREAM, OSTREAM, CIN, and COUT
#include <string>      // for STRING
#include <cassert>     // for ASSERT
#include "stock.h"     // for STOCK_TRANSACTION
#include "queue.h"     // for QUEUE
using namespace std;

/************************************************
 * Stock
 * A class that holds the number of shares and
 * their corresponding dollar amounts
 ***********************************************/
class Stock
{
protected:
   int shares;
   Dollars amount;
   
public:

   // Default constructor
   Stock() : shares(0), amount() {}
   Stock(int shares, Dollars amount) { this->shares = shares;
      this->amount = amount; }
   
   // getters
   int getShares() const { return shares; }
   Dollars getAmount() const { return amount; }
   
   // setters
   void setShares(const int & shares) { this->shares = shares; }
   void setAmount(const Dollars & amount) { this->amount = amount; }   
};

/************************************************
 * Sold Stock
 * A class that inherits from a Stock and has the
 * dollar amount for the profits made from the
 * sold stock.
 ***********************************************/
class SoldStock : public Stock
{
private:
   Dollars profit;

public:

   // Default constructor
   SoldStock() : profit() {}

   // getter
   Dollars getProfit() const { return profit; }
   
   // setter
   void setProfit(const Dollars & profit) { this->profit = profit; }
   
   SoldStock & operator = (const Stock & rhs);
};

/************************************************
 * OPERATOR = 
 * Allows one to use the assignment operator with this class
 ***********************************************/
SoldStock & SoldStock::operator = (const Stock & rhs)
{
   this->shares = rhs.getShares();
   this->amount = rhs.getAmount();
   profit = 0;
}

/************************************************
 * DISPLAY CURRENT STOCK
 * Displays the current stocks in the passed in queue by copy
 ***********************************************/
void displayCurrentStock(Queue <Stock> current)
{
   cout << "Currently held:\n";

   // keeps going until it is empty
   while (!current.empty())
   {
      cout << "\tBought " << current.getFront().getShares() << " shares at ";
      cout << current.getFront().getAmount() << endl;

      current.pop();
   }
}

/************************************************
 * DISPLAY SOLD STOCK
 * Displays the stocks sold in the passed in queue by copy
 * also counting the proceeds for each stock sold
 ***********************************************/
void displaySoldStock(Queue <SoldStock> sold)
{   
   cout << "Sell History:\n";
   
   // keeps going until it is empty
   while (!sold.empty())
   {
      cout << "\tSold " << sold.getFront().getShares() << " shares at ";
      cout << sold.getFront().getAmount() << " for a profit of ";
      cout << sold.getFront().getProfit() * sold.getFront().getShares() << endl;

      sold.pop();
   }
}

/************************************************
 * SELL STOCK
 * Sells the certain amount of stock and counts up
 * your revenue so far.
 ***********************************************/
void sellStock(Queue <Stock> & current, Queue <SoldStock> & sold,
               Dollars & proceeds)
{
   SoldStock input; // sellingStock
            
   // retrieve other data
   int sharesToSell;
   cin >> sharesToSell;
   input.setShares(sharesToSell);
            
   Dollars amount;
   cin >> amount;
   input.setAmount(amount);
      
   while (sharesToSell && !current.empty())
   {
      Stock oldest = current.getFront();
      int oldestShares = oldest.getShares();
      
      if (oldestShares >= sharesToSell)
      {
         // *********logic for shares
         // lower the front shares
         oldestShares -= sharesToSell;
         
         // sold all the shares we needed to
         sharesToSell = 0;
         
         // update front new values
         oldest.setShares(oldestShares);
         current.getFront().setShares(oldestShares);
         
         // *********logic for $ amount for each share
         // get the dollar difference b/t buy and sell amount
         Dollars sellProfit = input.getAmount() - oldest.getAmount();

         // update input with that profit value
         input.setProfit(sellProfit);
         
         // update proceeds
         proceeds += (sellProfit * input.getShares());
         
         // add the stocks sold to the sold Queue
         sold.push(input);

         if (oldestShares == 0)
         {
            // take out the front
            current.pop();
         }
      }
      else // sharesToSell > oldest         
      {
         // add front of current to sold Queue
         SoldStock partSelling;
         
         // fill in values
         partSelling = oldest;
         partSelling.setAmount(input.getAmount());
         
         // get the dollar difference b/t buy and sell amount
         Dollars sellProfit = input.getAmount() - oldest.getAmount();
         
         // set the profit
         partSelling.setProfit(sellProfit);
       
         // get rid of old stock b/c ran out of it, go on to next stock
         current.pop();
         
         // sold some of the shares
         sharesToSell -= oldestShares;

         // update proceeds
         proceeds += (sellProfit * oldestShares);
         
         // update sold values
         input.setShares(sharesToSell);

         // add the stocks sold to the sold Queue
         sold.push(partSelling);
      }
   }
}

/************************************************
 * BUY STOCK
 * Retrieves buying data from user and buys
 * adds it to the portfolio
 ***********************************************/
void buyStock(Queue <Stock> & currentStock)
{
   Stock input;
   
   // retrieve other data 
   int shares;
   cin >> shares;
   input.setShares(shares);
            
   Dollars amount;
   cin >> amount;
   input.setAmount(amount);
            
   // add to the queue
   currentStock.push(input);   
}

/************************************************
 * STOCKS BUY SELL
 * The interactive function allowing the user to
 * buy and sell stocks
 ***********************************************/
void stocksBuySell()
{
   // instructions
   cout << "This program will allow you to buy and sell stocks. "
        << "The actions are:\n";
   cout << "  buy 200 $1.57   - Buy 200 shares at $1.57\n";
   cout << "  sell 150 $2.15  - Sell 150 shares at $2.15\n";
   cout << "  display         - Display your current stock portfolio\n";
   cout << "  quit            - Display a final report and quit the program\n";

   // User's portfolio
   Queue <Stock> currentStock;
   // User's Sell History
   Queue <SoldStock> soldStock;
   // User's earnings
   Dollars proceeds;
   
   string instruction;
   try
   {
      do
      {
         cout << "> ";
         cin  >> instruction;
         
         // instead of the switch statement
         if (instruction == "buy")
         {
            buyStock(currentStock);           
         }
         else if (instruction == "sell")
         {
            sellStock(currentStock, soldStock, proceeds);
         }
         else if (instruction == "display")
         {
            // call display functions
            if (!currentStock.empty())
            {
               displayCurrentStock(currentStock);
            }
            if (!soldStock.empty())
            {
               displaySoldStock(soldStock);
            }

            cout << "Proceeds: " << proceeds << endl;
         }
         else if (instruction == "quit")
         {
            break; // jump out of the loop
         }
         else // default
         {

         }
      }   
      while (instruction != "quit");
   }
   catch (const char * error)
   {
      cout << error << endl;
   }      
   
}
