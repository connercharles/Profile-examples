/***********************************************************************
 * Header:
 *    INSERTION SORT
 * Summary:
 *    This will contain just the prototype for insertionSortTest(). You may
 *    want to put other class definitions here as well.
 * Author
 *    Conner Charles
 ************************************************************************/

#ifndef INSERTION_SORT_H
#define INSERTION_SORT_H

#include "node.h"

/***********************************************
 * INSERTION SORT
 * Sort the items in the array
 **********************************************/
template <class T>
void sortInsertion(T array[], int num) // pass array by reference?
{
   //********Part 1 sort the array in a linked list
   // Create the sorted list
   Node <T> * sortedList = NULL;

   // Iterate through array
   for (int i = 0; i < num; i++)
   {
      // List iterator starting at the head
      Node <T> * listIt = sortedList;

      //check the first in the list
      if (listIt == NULL || listIt->data > array[i])
      {
         // add to the front
         insert(array[i], sortedList, true);
      }
      else
      {
         while (listIt->pNext != NULL)
         {
            if (listIt->pNext->data > array[i])
            {
               // adds item after current item
               insert(array[i], listIt);
               // get out of current while loop
               break;
            }
            
            // increment
            listIt = listIt->pNext;
         }
         // if we need to add item to the end
         if (listIt->pNext == NULL)
         {
            insert(array[i], listIt);
         }
      }
   }

   //*********Part 2: copy back into the array
   Node <T> * listIt = sortedList;

   // either (listIt != NULL) or i < num would work
   for (int i = 0; i < num; i++)
   {
      // adds to the array
      array[i] = listIt->data;

      // increment to next item
      listIt = listIt->pNext;      
   }

   // free data when all done sorting
   freeData(sortedList);
}

#endif // INSERTION_SORT_H

