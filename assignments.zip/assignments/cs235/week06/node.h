/***********************************************************************
 * Header:
 *    Node
 * Summary:
 *      This class allows you to make a linked list using small dynamically
 *      allocated Nodes linked to others.
 * Author
 *    Conner Charles
 ************************************************************************/

#ifndef NODE_H
#define NODE_H

/************************************************
 * Node
 * A class that holds stuff
 ***********************************************/
template <class T>
class Node
{
  public:
   T data; // data for the node
   Node <T> * pNext; // pointer pointing to the next in the list

   // default constructor : empty values
   Node() : data(), pNext(NULL) {}
   
   // non-default constructor : set data
   Node(T data) : pNext(NULL) { this->data = data; }
};

/************************************************
 * Copy
 * Copies the linked list from the Node passed in
 ***********************************************/
template <class T>
Node <T> * copy(Node <T> * start)
{
   // new copy with start data
   Node <T> * newList = new Node <T> (start->data);
        
   if (start->pNext == NULL)
   {
      newList->pNext = NULL;
      return newList;
   }
   else
   {
      Node <T> * ptr = start->pNext; // next one
      newList->pNext = copy(ptr); // pointing to copy of this new one
      
      return newList;
   }   
}

/************************************************
 * Insert
 * Adds a new Node into the list after the passed
 * in Node with passed in value
 ***********************************************/
template <class T>
void insert(T data, Node <T> * & preceding)
{
   // has new data ready to be inserted
   Node <T> * addNode = new Node <T> (data);
   
   if (preceding != NULL)
   {
      // has pointer pointing to next thing after preceding
      addNode->pNext = preceding->pNext;
      // preceding now points to inserted item 
      preceding->pNext = addNode;
   }
   else
   {
      // add new Node with data behind preceding
      preceding = addNode;
   }
}

/************************************************
 * Insert
 * Same as other, checks to see if new data is now
 * the head of the list
 ***********************************************/
template <class T>
void insert(T data, Node <T> * & preceding, bool isHead)
{
   // has new data ready to be inserted
   Node <T> * addNode = new Node <T> (data);

   // add to the front of the list
   if (isHead)
   {
      // points to the rest of the list
      addNode->pNext = preceding;
      // add new Node with data behind preceding
      preceding = addNode;
   }
   else
   {
      // has pointer pointing to next thing after preceding
      addNode->pNext = preceding->pNext;
      // preceding now points to inserted item 
      preceding->pNext = addNode;
   }
}

/************************************************
 * Find
 * Searches from the passed in front for the
 * passed in value
 ***********************************************/
template <class T>
Node <T> * find(Node <T> * front, T findValue)
{
   while (front != NULL)
   {
      if (front->data == findValue)
      {
         return front;
      }

      // increment
      front = front->pNext;
   }

   // if it's not there
   return front; // by then front should be NULL
}

/************************************************
 * Operator << 
 * Allows user to display current list
 ***********************************************/
template <class T>
std::ostream & operator<<(std::ostream & out, Node <T> * list)
{
   if (list == NULL)
   {
      return out;
   }
   else
   {
      // adds current item to ostream
      out << list->data;      
      // increment
      list = list->pNext;
      // so that the comma won't come at the end
      if (list != NULL)
      {
         out << ", ";
      }
      // go down to the next level
      out << list;

      return out;
   }
}

/************************************************
 * Free Data
 * Frees space used with the list
 ***********************************************/
template <class T>
void freeData(Node <T> * & head)
{
   // anchor
   if (head == NULL)
   {
      // you've reached the end of the line
      return;
   }
   else
   {
      // holds on to current item
      Node <T> * temp = head;
      // goes to the next item
      head = head->pNext;
      // deletes item
      delete temp;
      // goes to the next item
      freeData(head);
   }
}

#endif // node_h
