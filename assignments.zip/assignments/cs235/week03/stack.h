/***********************************************************************
* Header:
*    Stack
* Summary:
*    This class contains the notion of a Stack: a bucket to hold
*    data for the user. This is just a starting-point for more advanced
*    constainers such as the vector, set, stack, queue, deque, and map
*    which we will build later this semester.
*
*    This will contain the class definition of:
*        Stack         : A class that holds stuff
* Author
*    Br. Helfrich
************************************************************************/

#ifndef Stack_H
#define Stack_H

#include <cassert>

/************************************************
 * Stack
 * A class that holds stuff
 ***********************************************/
template <class T>
class Stack
{
public:
   // default constructor : empty and kinda useless
   Stack() : numItems(0), capacity(0), data(NULL) {}

   // copy constructor : copy it
   Stack(const Stack & rhs) throw (const char *);
   
   // non-default constructor : pre-allocate
   Stack(int capacity) throw (const char *);
   
   // destructor : free everything
   ~Stack()        { if (capacity) delete [] data; }
   
   // is the Stack currently empty
   bool empty() const  { return numItems == 0;         }

   // remove all the items from the Stack
   void clear()        { numItems = 0;                 }

   // how many items are currently in the Stack?
   int size() const    { return numItems;              }

   // adds the item to the top of the Stack
   void push(const T & newItem);

   // take the top item off of the Stack
   void pop() throw (const char *);
   
   // returns the top value of the Stack
   T & top() throw (const char *);

   // assignment operator overload
   Stack <T> & operator = (const Stack <T> & rhs) throw (const char *);
   
private:
   T * data;          // dynamically allocated array of T
   int numItems;      // how many items are currently in the Stack?
   int capacity;      // how many items can I put on the Stack before full?

   // checks to see if the array needs to expand
   void checkCapacity() throw (const char *);

};

/*******************************************
 * Stack :: COPY CONSTRUCTOR
 *******************************************/
template <class T>
Stack <T> :: Stack(const Stack <T> & rhs) throw (const char *)
{
   assert(rhs.capacity >= 0);
      
   // do nothing if there is nothing to do
   if (rhs.capacity == 0)
   {
      capacity = numItems = 0;
      data = NULL;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[rhs.capacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate buffer";
   }
   
   // copy over the capacity and size
   assert(rhs.numItems >= 0 && rhs.numItems <= rhs.capacity);
   capacity = rhs.capacity;
   numItems = rhs.numItems;

   // copy the items over one at a time using the assignment operator
   for (int i = 0; i < numItems; i++)
      data[i] = rhs.data[i];

   // the rest needs to be filled with the default value for T
   for (int i = numItems; i < capacity; i++)
      data[i] = T();
}

/**********************************************
 * Stack : NON-DEFAULT CONSTRUCTOR
 * Preallocate the Stack to "capacity"
 **********************************************/
template <class T>
Stack <T> :: Stack(int capacity) throw (const char *)
{
   assert(capacity >= 0);
   
   // do nothing if there is nothing to do
   if (capacity == 0)
   {
      this->capacity = this->numItems = 0;
      this->data = NULL;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[capacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate buffer";
   }

      
   // copy over the stuff
   this->capacity = capacity;
   this->numItems = 0;

   // initialize the Stack by calling the default constructor
   for (int i = 0; i < capacity; i++)
      data[i] = T();
}

/**********************************************
 * Stack :: operator =
 * Allows user to assign two Stacks together
 **********************************************/
template <class T>
Stack <T> & Stack <T> :: operator = (const Stack <T> & rhs)
   throw (const char *)
{
   // attempt to allocate
      try
      {
         delete [] data;
         data = new T[rhs.capacity];
      }
      catch (std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for Stack";
      }

      // copy over the capacity and size
      assert(rhs.numItems >= 0 && rhs.numItems <= rhs.capacity);
      capacity = rhs.capacity;
      numItems = rhs.numItems;

      // copy the items over one at a time using the assignment operator
      for (int i = 0; i < numItems; i++)
         data[i] = rhs.data[i];

      // the rest needs to be filled with the default value for T
      for (int i = numItems; i < capacity; i++)
         data[i] = T();

      return (*this);
}

/***************************************************
 * Stack :: CHECK CAPACITY
 * Checks the capacity of the array and if it needs room
 * it will double the size allocated.
 **************************************************/
template <class T>
void Stack <T> :: checkCapacity() throw (const char *)
{
   if (capacity == 0)
   {
      capacity = 1;
      
      // attempt to allocate
      try
      {
         data = new T[capacity];
      }
      catch (std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for Set";
      }
   }
   else if (numItems == capacity)
   {
      capacity *= 2;
      
      // code from the book
      
      try
      {
         // allocate the new buffer
         T * bufferNew = new T[capacity];
         
         // copy the data into the new buffer
         // copy the items over one at a time using the assignment operator
         for (int i = 0; i < numItems; i++)
            bufferNew[i] = data[i];
         
         // the rest needs to be filled with the default value for T
         for (int i = numItems; i < capacity; i++)
            bufferNew[i] = T();
         
         // assigns the new array to the old pointer and deletes the old array
         delete [] data;
         data = bufferNew;
      }
      catch(std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for Stack";
      }
   }
   
}                  

/**********************************************
 * Stack :: push
 * Takes an item and adds it to the end of the array
 **********************************************/
template <class T>
void Stack <T> :: push(const T & newItem)
{
   checkCapacity();
   
   // using numItems b/c arrays are zero indexed so it would be the
   // next empty spot in the array
   data[numItems] = newItem;

   numItems++;
}

/**********************************************
 * Stack :: pop
 * Takes the last item off of the stack
 **********************************************/
template <class T>
void Stack <T> :: pop() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: Unable to pop from an empty Stack";
   }
   else
   {
      // makes the top go down by one
      numItems--;
   }
}

/**********************************************
 * Stack :: top
 * Returns the top amount of the stack
 **********************************************/
template <class T>
T & Stack <T> :: top() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: Unable to reference the element from an empty Stack";
   }
   else
   {
      return data[numItems - 1];
   }
}

#endif // Stack_H

