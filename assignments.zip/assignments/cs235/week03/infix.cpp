/***********************************************************************
 * Module:
 *    Week 03, Stack
 *    Brother Ercanbrack, CS 235
 * Author:
 *    Conner Charles
 * Summary:
 *    This program will implement the testInfixToPostfix()
 *    and testInfixToAssembly() functions
 ************************************************************************/

#include <iostream>    // for ISTREAM and COUT
#include <string>      // for STRING
#include <cassert>     // for ASSERT
#include "stack.h"     // for STACK
using namespace std;

/*****************************************************
 * ADD TO POSTFIX
 * Takes the top of the stack and adds it to the postfix
 * then takes that top off.
 *****************************************************/
void addToPostfix(Stack <char> & pile, string & postfix,
                  const char & infixOperator)
{
   if (pile.empty())
   {
      pile.push(infixOperator);
   }
   else
   {
      char top = pile.top();
      pile.pop();
      if (top != '(')
      {
         postfix.push_back(top);
      }
   }
}

/*****************************************************
 * ADD SPACES
 * Adds spaces to the postfix string in appropriate places
 * This was my last attempt to get the spacing correct for this assignment
 *****************************************************/
void addSpaces(string & postfix)
{
   int spaceCounter = 0;
   
   for (int i = 0; postfix[i] != '\0'; i++)
   {      
      if (postfix[i] == ' ')
      {
         spaceCounter++;

         if (spaceCounter > 1)
         {
            postfix.erase(i, 1);
            spaceCounter = 0;
         }
      }
      else if (postfix[i] == '^' || postfix[i] == '*'
          || postfix[i] == '/' || postfix[i] == '%'
          || postfix[i] == '+' || postfix[i] == '-')
      {
         // puts a space before operators
         postfix.insert(i, " ");
         i++;
         spaceCounter = 0;
      }
   }
}

/*****************************************************
 * CONVERT INFIX TO POSTFIX
 * Convert infix equation "5 + 2" into postifx "5 2 +"
 *****************************************************/
string convertInfixToPostfix(const string & infix)
{
   string postfix = " ";

   Stack <char> pile;

   for (int i = 0; i <= infix.length(); i++)
   {
      // Goes through the order of operations  
      switch(infix[i])
      {
         case '(':
         {
            pile.push(infix[i]);
            break;
         }
         case ')':
         {
            while (pile.top() != '(')
            {
               addToPostfix(pile, postfix, infix[i]);
            }
            break;
         }
         // need to check to see what has precedence
         case '^':
         {
            pile.push(infix[i]);
            break;
         }
         // because they are all created equal
         case '*':
         case '/':
         case '%':
            {
               // make sure the pile isn't empty before using it
               if (!pile.empty())
               {               
                  // if top has higher precedence
                  while (pile.top() == '^')
                  {
                     addToPostfix(pile, postfix, infix[i]);
                     // get's you out of the loop if empty
                     if (pile.empty())
                     {
                        break;
                     }
                  }
               }
               pile.push(infix[i]);            
               break;
            }
         case '+':
         case '-':
            {
               if (!pile.empty())
               {               
                  while (pile.top() == '^' || pile.top () == '*'
                         || pile.top() == '/' || pile.top() == '%')
                  {             
                     addToPostfix(pile, postfix, infix[i]);
                     if (pile.empty())
                     {
                        break;
                     }
                  }
               }
               pile.push(infix[i]);
               break;   
            }
         case ' ':
         {
            postfix.push_back(infix[i]);
            break;
         }
         // when it gets to the end of the string
         case '\0':
         {
            while (!pile.empty())
            {
               addToPostfix(pile, postfix, infix[i]);
            }
            break;
         }    
         // if it is any letter
         default:
         {
            //postfix.push_back(' ');
            postfix.push_back(infix[i]);
            break;
         }
      }
   }

   // add space function!!
   addSpaces(postfix);
   
   return postfix;
}

/*****************************************************
 * TEST INFIX TO POSTFIX
 * Prompt the user for infix text and display the
 * equivalent postfix expression
 *****************************************************/
void testInfixToPostfix()
{
   string input;
   cout << "Enter an infix equation.  Type \"quit\" when done.\n";
   
   do
   {
      // handle errors
      if (cin.fail())
      {
         cin.clear();
         cin.ignore(256, '\n');
      }
      
      // prompt for infix
      cout << "infix > ";
      getline(cin, input);

      // generate postfix
      if (input != "quit")
      {
         string postfix = convertInfixToPostfix(input);
         cout << "\tpostfix: " << postfix << endl << endl;
      }
   }
   while (input != "quit");
}

/**********************************************
 * CONVERT POSTFIX TO ASSEMBLY
 * Convert postfix "5 2 +" to assembly:
 *     LOAD 5
 *     ADD 2
 *     STORE VALUE1
 **********************************************/
string convertPostfixToAssembly(const string & postfix)
{
   string assembly;

   return assembly;
}

/*****************************************************
 * TEST INFIX TO ASSEMBLY
 * Prompt the user for infix text and display the
 * resulting assembly instructions
 *****************************************************/
void testInfixToAssembly()
{
   string input;
   cout << "Enter an infix equation.  Type \"quit\" when done.\n";

   do
   {
      // handle errors
      if (cin.fail())
      {
         cin.clear();
         cin.ignore(256, '\n');
      }
      
      // prompt for infix
      cout << "infix > ";
      getline(cin, input);
      
      // generate postfix
      if (input != "quit")
      {
         string postfix = convertInfixToPostfix(input);
         cout << convertPostfixToAssembly(postfix);
      }
   }
   while (input != "quit");
      
}
