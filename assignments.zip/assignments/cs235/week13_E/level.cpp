#include "person.h"
#include <iostream>
#include <string>
using namespace std;

void Person::level()
{
   const int MAX = 200;
   Person *queue[MAX];
   Person *temp;
   int front = 0;
   int back = 0;
   int genCount = 1;
   bool first = true;
   
   queue[back++] = this;
   int saveBack = 2; // saves index
   
   while (front != back)
   {
      temp = queue[front];
      front = (front + 1) % MAX;
      if (temp != NULL)
      {
         // visit
         // check if hit save back
         if (front == saveBack)
         {
            // display generation
            switch (genCount)
            {
               case 1:
                  cout << "Parents:\n";
                  break;
               case 2:
                  cout << "Grandparents:\n";
                  break;
               case 3:
                  cout << "Great Grandparents:\n";
                  break;
               case 4:
                  cout << "2nd Great Grandparents:\n";
                  break;
               case 5:
                  cout << "3rd Great Grandparents:\n";
                  break;
               case 6:
                  cout << "4th Great Grandparents:\n";
                  break;
               case 7:
                  cout << "5th Great Grandparents:\n";
                  break;
               default:
                  break;
            }
         
            // next generation
            genCount++;
            // save new saveBack
            saveBack = back + 1;
         }

         if (!first)
         {
            cout.width(4);
            cout << "\t" << (*temp);
         }
         
         // end Visit
         queue[back] = temp->left;
         back = (back + 1) % MAX;
         queue[back] = temp->right;
         back = (back + 1) % MAX;
         
      }
      first = false;
   }
}
