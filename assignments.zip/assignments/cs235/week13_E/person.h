/***********************************************************************
 * Header:
 *    person.h
 * Summary:
 *    This class contains the data that a Person would need for genealogy
 * Author:
 *    Conner Charles
 ************************************************************************/

#ifndef PERSON_H
#define PERSON_H

#include <string>    // for string
#include <iostream>  // for ostream

/***************************************
 * Person class
 * Holds data that a person would have
 **************************************/
class Person
{
  public:
   // common Person things
   std::string birthdate;
   std::string firstName;
   std::string lastName;
   std::string id;
   // for the tree
   Person * left;
   Person * right;

   // default constructor : empty
  Person() : birthdate(),firstName(),lastName(),id(),left(NULL),right(NULL) {}

   // for resetting the Person's data
   void clear()
   {
      birthdate = "";
      firstName = "";
      lastName = "";
      id = "";
   }

   // check see if Person is empty
   bool empty()
   {
      return birthdate == "" && firstName == "" && lastName == "" && id == "";
   }

   // for traversing through the tree
   void level();

   // compare Persons
   friend bool operator < (Person lhs, Person rhs);
   friend bool operator == (const Person & lhs, const Person & rhs);
   
   // display Person
   friend std::ostream & operator << (std::ostream & out, const Person & rhs);
};

/***************************************
 * Family struct
 * Holds data that a family would need
 **************************************/
struct Family
{
   std::string child;
   std::string husband;
   std::string wife;

   // resetting data
   void clear() { child = ""; husband = ""; wife = ""; }

   // check see if Person is empty
   bool empty()
   {
      return child == "" && husband == "" && wife == "";
   }
};

#endif // PERSON_H
