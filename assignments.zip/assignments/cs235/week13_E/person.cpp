/***********************************************************************
 * Header:
 *    person.cpp
 * Summary:
 *    This class contains the data that a Person would need for genealogy
 * Author:
 *    Conner Charles
 ************************************************************************/

#include "person.h"

/*****************************************************
 * Operator ==
 * Compares only the id numbers between people
 ****************************************************/
bool operator == (const Person & lhs,const Person & rhs)
{
   if (lhs.id == rhs.id)
      return true;
   else
      return false;
}

/*****************************************************
 * Operator <<
 * Displays the Person's information
 ****************************************************/
std::ostream & operator << (std::ostream & out, const Person & rhs)
{
   out << rhs.firstName;
   // if first and last name are there, put space in b/t
   if (rhs.firstName != "" && rhs.lastName != "")
      out << " ";
   // check if there's a last name
   if (rhs.lastName != "")
      out << rhs.lastName;
   // check if there's a birthdate
   if (rhs.birthdate != "")
      out << ", b." << rhs.birthdate;
   out << std::endl;
   return out;
}

/*****************************************************
 * Operator <
 * Compares two Persons by last name, then first, then
 * birthdate.
 ****************************************************/
bool operator < (Person lhs, Person rhs)
{
   // make sure they are not NULL
   if (!lhs.lastName.empty() && !rhs.lastName.empty())
   {
      // check if there is a lower case
      if (islower(lhs.lastName[0]))
      {
         // switch to upper case for lhs
         lhs.lastName[0] = toupper(lhs.lastName[0]);
      }
      else if (islower(rhs.lastName[0]))
      {
         // switch to upper case for rhs
         rhs.lastName[0] = toupper(rhs.lastName[0]);
      }
   }

   // compare last name
   if (lhs.lastName < rhs.lastName)
   {
      return true;
   }
   else if (lhs.lastName == rhs.lastName)
   {
      // check if NULL
      if (lhs.firstName.empty())
      {
         return true;
      }
      else if (rhs.firstName.empty())
      {
         return false;
      }
      
      // then compare first name
      if (lhs.firstName < rhs.firstName)
      {
         return true;
      }
      else if (lhs.firstName == rhs.firstName)
      {
         // check if NULL
         if (lhs.birthdate.empty())
         {
            return true;
         }
         else if (rhs.birthdate.empty())
         {
            return false;
         }
         
         std::string lhsYear;
         // get last 4 char's of the lhs string to compare
         lhsYear = lhs.birthdate.substr(lhs.birthdate.length() - 4, 4);
         std::string rhsYear;
         // get last 4 char's of the rhs string to compare
         rhsYear = rhs.birthdate.substr(rhs.birthdate.length() - 4, 4);
         // then compare birthdate
         if (lhsYear < rhsYear)
         {
            return true;
         }
      }
   }
   return false;
}
