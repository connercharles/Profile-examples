/***********************************************************************
 * Header:
 *    BinaryNode
 * Summary:
 *      This class allows you to make a linked list using small dynamically
 *      allocated BinaryNodes linked to others.
 * Author
 *    Conner Charles
 ************************************************************************/

#ifndef BinaryNode_H
#define BinaryNode_H

#include <string> // for string
#include <iostream>
using namespace std;

/************************************************
 * BinaryNode
 * A class that holds stuff
 ***********************************************/
template <class T>
class BinaryNode
{
  public:
   T data; // data for the BinaryNode
   BinaryNode <T> * pLeft; // pointer pointing to left side
   BinaryNode <T> * pRight; // pointer pointing to right side
   BinaryNode <T> * pChild; // pointer pointing to the parent of that node
   
   // default constructor : empty values
   BinaryNode() : data(), pLeft(NULL), pRight(NULL), pChild(NULL) {}
   
   // non-default constructor : set data
   BinaryNode(T data) : pLeft(NULL), pRight(NULL), pChild(NULL)
   { this->data = data; }

   // add Left with a BNode *
   BinaryNode <T> * addLeft(BinaryNode <T> * leftNode);
   // add Left with a T
   BinaryNode <T> * addLeft(T newData) throw (const char *);

   // add Right with a BNode *
   BinaryNode <T> * addRight(BinaryNode <T> * rightNode);
   // add Right with a T
   BinaryNode <T> * addRight(T newData) throw (const char *);
   
   //BinaryNode <Person*> * find(BinaryNode <Person*> root, std::string & findId);
   BinaryNode <Person> * find(BinaryNode <Person> * root, std::string & findId);
   
};

/************************************************
 * Add Left
 * Adds a node to the left of the current node
 * by using passed in node
 ***********************************************/
template <class T>
BinaryNode <T> * BinaryNode <T> :: addLeft(BinaryNode <T> * leftNode)
{
   if (leftNode == NULL)
   {
      // point left pointer to NULL
      pLeft = leftNode;
   }
   else // leftNode != NULL
   {
      // point left pointer to new node
      pLeft = leftNode;
      // point pChild to this node
      leftNode->pChild = this;
   }
      
   return this;
}

/************************************************
 * Add Left
 * Adds a node to the left of the current node
 * allocating a new node
 ***********************************************/
template <class T>
BinaryNode <T> * BinaryNode <T> :: addLeft(T newData) throw (const char *)
{   
   try
   {
      // allocate new node with newData in it
      BinaryNode <T> * leftNode = new BinaryNode(newData);
      // point left pointer to new node
      pLeft = leftNode;
      cout << "adding " << newData << "to left\n";
      // point pChild to this node
      //leftNode->pChild = this;
      
      return this;
   }
   catch(std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a node";
   }
}

/************************************************
 * Add Right
 * Adds a node to the right of the current node
 * by using passed in node
 ***********************************************/
template <class T>
BinaryNode <T> * BinaryNode <T> :: addRight(BinaryNode <T> * rightNode)
{
   if (rightNode == NULL)
   {
      // point right pointer to NULL
      pRight = rightNode;
   }
   else // rightNode != NULL
   {
      // point right pointer to new node
      pRight = rightNode;
      // point pChild to this node
      rightNode->pChild = this;
   }
   
   return this;   
}

/************************************************
 * Add Right
 * Adds a node to the right of the current node
 * allocating a new node
 ***********************************************/
template <class T>
BinaryNode <T> * BinaryNode <T> :: addRight(T newData) throw (const char *)
{
   try
   {
      cout << "adding " << newData << "to right\n";

      // allocate new node with newData in it
      BinaryNode <T> * rightNode = new BinaryNode(newData);
      // point right pointer to new node
      pRight = rightNode;
      // point pChild to this node
      rightNode->pChild = this;

      return this;
   }
   catch(std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a node";
   }
}

/************************************************
 * Delete Binary Tree
 * Deletes the binary tree from the passed in node down
 * does this recursively in a postfix fashion.
 ***********************************************/
template <class T>
void deleteBinaryTree(BinaryNode <T> * & root)
{
   if (root->pLeft != NULL) deleteBinaryTree(root->pLeft); // left
   if (root->pRight != NULL) deleteBinaryTree(root->pRight); // right
   delete root; // visit
}

/************************************************
 * Operator <<
 * Overloading the insertion operator to display the
 * tree recursively in an infix fashion.
 ***********************************************/
template <class T>
std::ostream & operator <<(std::ostream & out, BinaryNode <T> * tree)
{
   if (tree->pLeft != NULL) out << (tree->pLeft); // left
   out << tree->data << " "; // visit
   if (tree->pRight != NULL) out << (tree->pRight); // right

   return out;
}

/****************************************************
 * FIND
 * Return the node corresponding to a given value,
 * called recursively
 ****************************************************/
template <>
BinaryNode <Person> * BinaryNode <Person> :: find(BinaryNode <Person> * root,
                            std::string & findId)
//BinaryNode <Person*> * BinaryNode <Person*> :: find(BinaryNode <Person*> root,
//                            std::string & findId)
{
   if (root->pLeft != NULL)
   {
      // search left subtree
      return find(root->pLeft, findId);
   }
   if (root->pRight != NULL)
   {
      // search right subtree
      return find(root->pRight, findId);
   }
   // item is found
   if (root != NULL && root->data.id == findId)
   {
      // make a Node pointer pointing to the item found
      //BinaryNode <Person*> * found;
      //found = &root;
      BinaryNode <Person> * found;
      found = root;
      return found;
   }
}

#endif // BinaryNode_h
