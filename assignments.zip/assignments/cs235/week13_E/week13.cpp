/***********************************************************************
 * Program:
 *    Week 13, Genealogy
 *    Brother Ercanbrack, CS 235
 * Author:
 *    Conner Charles
 * Summary:
 *    This is the main function where most of the work for the geneology
 *    is taking place.
 ************************************************************************/

#include <iostream>     // for cout/cin
#include <fstream>      // for ifstream/ofstream
#include <string>       // for string
#include <sstream>      // for stringstream
#include <stdlib.h>     // for exit, EXIT_FAILURE
#include "list.h"       // for my linked list
#include "person.h"     // for my Person class
#include "bnode.h"      // for my BinaryNode class
#include "level.cpp"    // for level traversal

using namespace std;

/***************************************************
 * Insert List
 * Uses an insertion sort to insert Person to the
 * list in a sorted order.
 **************************************************/
void insertList(Person & input, List <Person> & family)
{
   ListIterator <Person> it;
   ListIterator <Person> next;
   
   // if it's empty
   if (family.empty())
   {
      // add new person to the back of the list
      family.push_back(input);
   }
   else
   {
      for (it = family.begin(), next = (++family.begin());
           it != family.end(); it++, next++)
      {
         if (input < (*it))
         {
            // add new Person to before the iterator
            family.insert(input, it);
            // leave loop
            break;
         }
         // if it's at the end of the list
         else if (next == family.end())
         {
            // add to the end of the list
            family.push_back(input);
            // leave loop
            break;
         }
      }
   }
}

/***************************************************
 * Insert Family
 * Inserts family units into a list
 **************************************************/
void insertFamily(Family & input, List <Family> & tree)
{
   // if the family is not empty
   if (!input.empty())
   {
      // add to the end of the list
      tree.push_back(input);
   }
}

/***************************************************
 * Parse Indiv
 * Parses data for the individual
 **************************************************/
void parseIndiv(string & id, stringstream & ss,
                Person & ancestor, int & bDateCounter)
{
   // get their names
   if (id == "GIVN")
   {
      string name;
      // the rest of ss should be the first name
      while (ss >> name)
      {
         ancestor.firstName += (name + " ");
      }
      // delete the last space
      ancestor.firstName.erase(ancestor.firstName.end() - 1);
   }
   else if (id == "SURN")
   {
      string name;
      // the rest of ss should be the last name
      while (ss >> name)
      {
         ancestor.lastName += (name + " ");
      }
      // delete the last space
      ancestor.lastName.erase(ancestor.lastName.end() - 1);
   }
   
   // check if their birthdate is next
   if (id == "BIRT")
   {
      // set to 1 so the next line is should be 0
      bDateCounter = 1;
   }
   // their birthdate is here
   else if (id == "DATE" && bDateCounter == 0)
   {
      string birthday;
      // the rest of ss should be the birthdate
      while (ss >> birthday)
      {
         ancestor.birthdate += (" " + birthday);
      }
   }
}

/***************************************************
 * Parse Fam
 * Parses data for the family
 **************************************************/
void parseFam(string & id, stringstream & ss, Family & famUnit)
{
   // check father
   if (id == "HUSB")
   {
      // get the father's id
      string fatherID;
      ss >> fatherID;
      // update husband
      famUnit.husband = fatherID;
   }
   // check mother
   else if (id == "WIFE")
   {
      // get the mother's id
      string motherID;
      ss >> motherID;
      // update wife
      famUnit.wife = motherID;
   }
   // check child
   else if (id == "CHIL")
   {
      // get the child's id
      string childID;
      ss >> childID;
      // update child
      famUnit.child = childID;
   }
}

/***************************************************
 * Parse Data
 * Parses data in the file and adds to the list
 **************************************************/
void parseData(ifstream & fin, List <Person> & family, List <Family> & tree)
{
   // for retrieving data
   string line;
   int bDateCounter = 1;

   // make a new person for data
   Person ancestor;
   // make a new Family for data
   Family famUnit;
   
   // loop through a retreive data from file
   while(getline(fin, line))
   {
      // decrement birthdate counters
      bDateCounter--;
      // put line into a stream
      stringstream ss;
      ss << line;
      // ***** parse line
      string number;
      // take the first number part of line
      ss >> number;
      // get the id (second "word" in line)
      string id;
      ss >> id;
      
      // new person or new subject
      if (number == "0")
      {
         // check if it's an individual
         if (id[1] == 'I')
         {
            // adds Person to the list
            insertList(ancestor, family);
            // clear variable to use later
            ancestor.clear();
            // add to the Person
            ancestor.id = id;
         }
         // check if it's a family
         if (id[1] == 'F')
         {
            // add Family to the list
            insertFamily(famUnit, tree);
            // clear variable to use later
            famUnit.clear();
         }
      }
      // still on same person/family
      else
      {
         // parse the data
         parseIndiv(id, ss, ancestor, bDateCounter);
         parseFam(id, ss, famUnit);         
      }
      // clear line for the next getline
      line.clear();
   }

   // add the last person
   if (!ancestor.empty())
   {
      // adds Person to the list
      insertList(ancestor, family);
   }
   // add the last family
   if (!famUnit.empty())
   {
      // adds Family to the list
      insertFamily(famUnit, tree);
   }   
}

/***************************************************
 * Read File
 * Reads the file and parses it appropriately to
 * retrieve data for genealogy.
 **************************************************/
void readFile(string fileName, List <Person> & family, List <Family> & tree)
{
   //******** read the file into a list
   // open file
   ifstream fin(fileName.c_str());
   // check if file opened
   if (fin.fail())
   {
      cout << "ERROR: could not open file." << endl;
      // exit program
      exit(EXIT_FAILURE);
   }
   
   parseData(fin, family, tree);

   // close file
   fin.close();

   // take out first person because they are empty
   family.remove(family.begin());
}

/***************************************************
 * Make Tree
 * Creates the family tree putting everyone where
 * they need to be
 **************************************************/
void makeTree(List <Person> & people, List <Family> & families)
{
   ListIterator <Family> it;

   // go through and look at the children
   for (it = families.begin(); it != families.end(); ++it)
   {
      // current child found
      Person * current;
      // search list of Families for child id
      current = people.find((*it).child);
      // set current child's left
      current->left = people.find((*it).husband);
      // set current child's right
      current->right = people.find((*it).wife);
   }
}

/***************************************************
 * Display Family
 * Displays the family in generation order
 **************************************************/
void displayFamily(const List <Person> & family)
{
   // open file
   ofstream fout("sorted.dat");
   // check if file opened
   if (fout.fail())
   {
      cout << "ERROR: could not open file." << endl;
      // exit program
      exit(EXIT_FAILURE);
   }

   // display information
   ListIterator <Person> it;

   for (it = family.begin(); it != family.end(); it++)
   {
      // call Person display
      fout << *it;
   }

   // close file
   fout.close();
}

/***************************************************
 * Display Tree
 * Displays the data retrieved in the file by printing
 * the data into a new file
 **************************************************/
void displayTree(List <Person> & family)
{
   cout << "The Ancestors of Gregory Lawrence Cameron:" << endl;
   // root of the tree
   Person * cameron = family.find("@I1@");
   // traverse through it
   cameron->level();
}

/**********************************************************************
 * MAIN
 * Get the filename from the command line.
 * Reads the file given and retrieves the data, displays information.
 ***********************************************************************/
int main(int argc, const char* argv[])
{
   // make sure there are all the arguments there
   if (argc < 2)
   {
      cout << "Usage: programName fileName" << endl;
   }
   else
   {
      // reads in the file and outputs information into new file
      List <Person> family;
      List <Family> tree;

      readFile(argv[1], family, tree);

      makeTree(family, tree);

      // displays the family tree
      displayTree(family);
   }

   return 0;
}
