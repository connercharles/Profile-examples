/***********************************************************************
* Program:
*    Assignment 01, Go Fish
*    Brother Helfrich, CS 235
* Author:
*    Conner Charles
* Summary: 
*    This is all the functions necessary to play Go Fish!
*
*    Estimated:  1.5 hrs   
*    Actual:     2.0 hrs
*      Remembering how to read in a file and making sure I added it to
*       the set correctly.
************************************************************************/

#include <iostream>
#include <fstream>
#include "set.h"
#include "card.h"
#include "goFish.h"
using namespace std;

const int MAX_TURNS = 5;
const int START_TURNS = 1;

/**********************************************************************
 * READ HAND
 * This reads a file and gives the user their hand to play the game.
 ***********************************************************************/
void readHand(Set <Card> & hand)
{
   ifstream infile("/home/cs235/week02/hand.txt");
   Card input;

   if (infile.is_open())
   {
      while (infile)
      {
         infile >> input;
         hand.insert(input);
      }
      infile.close();
   }
   else
   {
      cout << "ERROR: Unable to open file." << endl;
   }

   // Gets rid of bad cards
   hand.erase(hand.find("-INVALID-"));

}

/**********************************************************************
 * GO FISH
 * The function which starts it all
 ***********************************************************************/
void goFish()
{
   Set <Card> hand;
   readHand(hand);

   int turns = START_TURNS;
   int matches = 0;

   // This is the game
   cout << "We will play 5 rounds of Go Fish.  ";
   cout << "Guess the card in the hand" << endl;

   
   while (turns <= MAX_TURNS)
   {
      cout << "round " << turns << ": ";
      Card doYouHaveAny;
      cin >> doYouHaveAny;

      if (hand.find(doYouHaveAny) != hand.end())
      {
         cout << "\tYou got a match!" << endl;
         matches++;
         hand.erase(hand.find(doYouHaveAny));      
      }
      else
      {
         cout << "\tGo Fish!" << endl;
      }
      turns++;
   }

   // After the game
   cout << "You have " << matches << " matches!" << endl;
   
   SetIterator <Card> it = hand.begin();
   cout << "The remaining cards: " << *it;
   ++it;
   
   // print hand by iterating through the set
   for (; it != hand.end(); ++it)
      cout << ", " << *it;
   
   cout << endl;
}
