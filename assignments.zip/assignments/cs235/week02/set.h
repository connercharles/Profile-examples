/***********************************************************************
* Header:
*    Set
* Summary:
*    This class contains the notion of a Set: a bucket to hold
*    data for the user. This is just a starting-point for more advanced
*    constainers such as the vector, set, stack, queue, deque, and map
*    which we will build later this semester.
*
*    This will contain the class definition of:
*        Set         : A class that holds stuff
*        SetIterator : An interator through Set
* Author
*    Br. Helfrich
************************************************************************/

#ifndef SET_H
#define SET_H

#include <cassert>

// forward declaration for SetIterator
template <class T>
class SetIterator;

/************************************************
 * Set
 * A class that holds stuff
 ***********************************************/
template <class T>
class Set
{
public:
   // default constructor : empty and kinda useless
   Set() : numItems(0), capacity(0), data(NULL) {}

   // copy constructor : copy it
   Set(const Set & rhs) throw (const char *);
   
   // non-default constructor : pre-allocate
   Set(int capacity) throw (const char *);
   
   // destructor : free everything
   ~Set()        { if (capacity) delete [] data; }
   
   // is the Set currently empty
   bool empty() const  { return numItems == 0;         }

   // remove all the items from the Set
   void clear()        { numItems = 0;                 }

   // how many items are currently in the Set?
   int size() const    { return numItems;              }

   // add an item to the Set
   void insert(const T & t) throw (const char *);
   
   // erases an item from the Set
   void erase(SetIterator <T> it);

   // returns iterator of the parameter in the list
   SetIterator <T> find(const T & item);
   
   // return an iterator to the beginning of the list
   SetIterator <T> begin() { return SetIterator<T>(data); }

   // return an iterator to the end of the list
   SetIterator <T> end() { return SetIterator<T>(data + numItems);}

   // assignment operator overload
   Set <T> & operator = (const Set <T> & rhs) throw (const char *);
   
   // intersection operator
   Set <T> operator && (const Set <T> & rhs);

   // union operator
   Set <T> operator || (const Set <T> & rhs);


   
private:
   T * data;          // dynamically allocated array of T
   int numItems;      // how many items are currently in the Set?
   int capacity;      // how many items can I put on the Set before full?

    // checks to see if the array needs to expand
   void checkCapacity() throw (const char *);
};

/**************************************************
 * Set ITERATOR
 * An iterator through Set
 *************************************************/
template <class T>
class SetIterator
{
  public:
   // default constructor
  SetIterator() : p(NULL) {}

   // initialize to direct p to some item
  SetIterator(T * p) : p(p) {}

   // copy constructor
   SetIterator(const SetIterator & rhs) { *this = rhs; }

   // assignment operator
   SetIterator & operator = (const SetIterator & rhs)
   {
      this->p = rhs.p;
      return *this;
   }

   // not equals operator
   bool operator != (const SetIterator & rhs) const
   {
      return rhs.p != this->p;
   }

   // dereference operator
   T & operator * ()
   {
      return *p;
   }

   // prefix increment
   SetIterator <T> & operator ++ ()
   {
      p++;
      return *this;
   }

   // postfix increment
   SetIterator <T> operator++(int postfix)
   {
      SetIterator tmp(*this);
      p++;
      return tmp;
   }
   
  private:
   T * p;
};

/*******************************************
 * Set :: COPY CONSTRUCTOR
 *******************************************/
template <class T>
Set <T> :: Set(const Set <T> & rhs) throw (const char *)
{
   assert(rhs.capacity >= 0);
      
   // do nothing if there is nothing to do
   if (rhs.capacity == 0)
   {
      capacity = numItems = 0;
      data = NULL;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[rhs.capacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate buffer";
   }
   
   // copy over the capacity and size
   assert(rhs.numItems >= 0 && rhs.numItems <= rhs.capacity);
   capacity = rhs.capacity;
   numItems = rhs.numItems;

   // copy the items over one at a time using the assignment operator
   for (int i = 0; i < numItems; i++)
      data[i] = rhs.data[i];

   // the rest needs to be filled with the default value for T
   for (int i = numItems; i < capacity; i++)
      data[i] = T();
}

/**********************************************
 * Set : NON-DEFAULT CONSTRUCTOR
 * Preallocate the Set to "capacity"
 **********************************************/
template <class T>
Set <T> :: Set(int capacity) throw (const char *)
{
   assert(capacity >= 0);
   
   // do nothing if there is nothing to do
   if (capacity == 0)
   {
      this->capacity = this->numItems = 0;
      this->data = NULL;
      return;
   }

   // attempt to allocate
   try
   {
      data = new T[capacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate buffer";
   }

      
   // copy over the stuff
   this->capacity = capacity;
   this->numItems = 0;

   // initialize the Set by calling the default constructor
   for (int i = 0; i < capacity; i++)
      data[i] = T();
}

/***************************************************
 * Set :: CHECK CAPACITY
 * Checks the capacity of the array and if it needs room
 * it will double the size allocated.
 **************************************************/
template <class T>
void Set <T> :: checkCapacity() throw (const char *)
{
   if (capacity == 0)
   {
      capacity = 1;

      // attempt to allocate
      try
      {        
         data = new T[capacity];
      }
      catch (std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for Set";
      }
   }
   else if (numItems == capacity)
   {
      capacity *= 2;

      // code from the book

      try
      {
      // allocate the new buffer 
      T * bufferNew = new T[capacity];

      // copy the data into the new buffer
      // copy the items over one at a time using the assignment operator
      for (int i = 0; i < numItems; i++)
         bufferNew[i] = data[i];

      // the rest needs to be filled with the default value for T
      for (int i = numItems; i < capacity; i++)
         bufferNew[i] = T();

      // assigns the new array to the old pointer and deletes the old array
      delete [] data;
      data = bufferNew;
      }
      catch(std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a new buffer for Set";
      }
   }

}

/***************************************************
 * Set :: INSERT
 * Insert an item on the end of the Set
 **************************************************/
template <class T>
void Set <T> :: insert(const T & t) throw (const char *)
{
   // do we have space?
   if (capacity == 0 || capacity == numItems)
   {
      checkCapacity();
   }

   // if it is the first one
   if (numItems == 0)
   {
      data[numItems] = t;
      numItems++;
   }
   else
   {
      for (int i = 0; i < numItems; i++)
      {
   
         // if the object isn't already there
         if (data[i] != t)
         {
            // puts the object in its place
            if (data[i] > t)
            {
               T temp = data[i];
               // adds the item to the set
               data[i] = t;
               numItems++;

               // Pushes everything back one from the back
               for (int j = numItems - 1; j > i; j--)
               {
                  data[j] = data[j - 1];
               }
               data[i + 1] = temp;
               break;
            }
            // if data[i] < t
            else if (i == (numItems - 1))
            {
               data[numItems] = t;
               numItems++;
               break;
            }
         
         }      
         // if it's already in there then get out of the loop
         else
         {
            break;
         }
      }
   }
   
}

/***************************************************                             
 * Set :: ERASE
 * Erases the item on from the set
 **************************************************/
template <class T>
void Set <T> :: erase(SetIterator <T> it)
{
   //I have to use this loop in order to find the position of the
   //object without using an iterator.
   int item = 0;
   for (int i = 0; i < numItems; i++)
   {
      if (data[i] == (*it))
      {
         item = i;
      }
   }

   // Shifts everything down in the list
   for (int i = item; i < numItems - 1; i++)
   {
      data[i] = data[i + 1];
   }
   
   numItems--;

   // This is my more efficient way of erasing...but it uses iterators
/*   SetIterator <T> itDelete = find(*it);
   if ((*itDelete) == (*it))
   {
      // shifts everything down in the list
      for (; itDelete != end() - 1; it++)
      {
         (*it) = *(++itDelete);
      }
      numItems--;
   }
*/
}

/***************************************************                             
 * Set :: FIND
 * Searches list for item, returns the iterator of that item
 **************************************************/
template <class T>
SetIterator <T> Set <T> :: find(const T & item)
{
   
   for (int i = 0; i < numItems; i++)
   {
      if (data[i] == item)
      {
         SetIterator <T> it(data + i);
         return it;
      }
   }
  
   //if item isn't there
   return Set::end();
}

 /**********************************************
 * Set :: operator =
 * Allows user to assign two Sets together
 **********************************************/
template <class T>
Set <T> & Set <T> :: operator = (const Set <T> & rhs)
   throw (const char *)
{
   // attempt to allocate       
   try
   {
      delete [] data;
      data = new T[rhs.capacity];
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a new buffer for Set";
   }

   // copy over the capacity and size
   assert(rhs.numItems >= 0 && rhs.numItems <= rhs.capacity);
   capacity = rhs.capacity;
   numItems = rhs.numItems;

   // copy the items over one at a time using the assignment operator
   for (int i = 0; i < numItems; i++)
      data[i] = rhs.data[i];

   // the rest needs to be filled with the default value for T
   for (int i = numItems; i < capacity; i++)
      data[i] = T();

   return (*this);
}
   
/**********************************************
 * Set :: operator &&
 * Allows user to compare two Sets together and
 * it returns the similarities between the two.
 **********************************************/
template <class T>
Set <T> Set <T> :: operator && (const Set <T> & rhs)
{
   Set <T> combinedSet;
   
   // goes through this-> set
   for (int i = 0; i < numItems; i++)
   {
      // goes through rhs set
      for (int j = 0; j < rhs.numItems; j++)
      {
         if (data[i] == rhs.data[j])
         {
            combinedSet.insert(data[i]);
         }
      }
   }

   return combinedSet;

}

/**********************************************
 * Set :: operator ||
 * Allows user to combinees two Sets together and
 * it returns the new set.
 **********************************************/
template <class T>
Set <T> Set <T> :: operator || (const Set <T> & rhs)
{
   Set <T> unionSet;

   // goes through this-> set
   for (int i = 0; i < numItems; i++)
   {
      unionSet.insert(data[i]);
   }

   // goes through rhs set
   for (int j = 0; j < rhs.numItems; j++)
   {      
      unionSet.insert(rhs.data[j]);   
   }
   
   return unionSet;
}


#endif // Set_H

