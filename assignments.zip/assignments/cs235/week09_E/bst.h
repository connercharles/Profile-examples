/***********************************************************************
 * Component:
 *    Week 09, Binary Search Tree (BST)
 *    Brother Ercanbrack, CS 235
 * Author:
 *    Br. Helfrich
 *    Modified by Scott Ercanbrack - removed most of the the BST class functions,
 *                                   but left BST Iterator class.
 * Summary:
 *    Create a binary search tree
 ************************************************************************/

#ifndef BST_H
#define BST_H

#include "bnode.h"    // for BinaryNode
#include "stack.h"    // for Stack

// forward declaration for the BST iterator
template <class T>
class BSTIterator; 

/*****************************************************************
 * BINARY SEARCH TREE
 * Create a Binary Search Tree
 *****************************************************************/
template <class T>
class BST
{
public:
   // constructor
   BST(): root(NULL) {};
   
   // copy constructor
   BST(const BST & rhs);
   
   ~BST();

   // determine if the tree is empty
   bool empty() const
   {
      return root == NULL;
   }

   // clear all the contents of the tree
   void clear()
   {
      deleteBinaryTree(root);
      // reset root
      root = NULL;
   }

   // overloaded assignment operator
   BST & operator = (const BST & rhs) throw (const char *)
   {
      // delete this tree if not already empty
      if (!empty())
      {
         clear();
      }

      // iterate through tree and make a copy
      root = copy(root, rhs.root);

      return *this;
   }
      
   // insert an item
   void insert(const T & item) throw (const char * );

   // remove an item
   void remove(BSTIterator <T> & it);

   // find a given item
   BSTIterator <T> find(const T & t);

   // the usual iterator stuff
   BSTIterator <T> begin();
   BSTIterator <T> end()             { return BSTIterator <T> (NULL); }
   BSTIterator <T> rbegin();
   BSTIterator <T> rend()            { return BSTIterator <T> (NULL); }
   
private:
   // tree pointer
   BinaryNode <T> * root;
   
   // recursively called to find item in tree
   BSTIterator <T> searchFind(BinaryNode <T> * root, const T & t);
   // copies one tree to another
   BinaryNode <T> * copy(BinaryNode <T> * lhs, BinaryNode <T> * rhs);
};

/*********************************************************
* copy constructor
**********************************************************/
template <class T>
BST<T>::BST(const BST &rhs) : root(NULL)
{
   root = copy(root, rhs.root);
}

/*****************************************************
 * BST :: COPY
 * Goes through rhs tree and copies values and relationships
 * into lhs tree
 ****************************************************/
template <class T>
BinaryNode <T> * BST<T>::copy(BinaryNode <T> * lhs, BinaryNode <T> * rhs)
{
   // if the root is empty
   if (lhs == NULL)
   {
      // make new node to begin tree
      lhs = new BinaryNode <T> (rhs->data);
      // begin copying the tree again
      copy(lhs, rhs);
   }
   else
   {
      // visit
      if (lhs->data != rhs->data)
      {
         // if it didn't copy over, now the values will
         lhs->data = rhs->data;
      }
      // left
      if (rhs->pLeft != NULL)
      {
         // add left child to lhs
         lhs->addLeft(rhs->data);
         // go to rhs left child
         copy(lhs->pLeft, rhs->pLeft);
      }
      // right
      if (rhs->pRight != NULL)
      {
         // add right child to lhs
         lhs->addRight(rhs->data);
         // go to rhs right child
         copy(lhs->pRight, rhs->pRight);
      }
   }

   // return the root of the copy tree
   return lhs;
}

/*****************************************************
* Destructor
*******************************************************/
template <class T>
BST<T>::~BST()
{
   if (root)
   {
      clear();
   }
}

/*****************************************************
 * BST :: BEGIN
 * Return the first node (left-most) in a binary search tree
 ****************************************************/
template <class T>
BSTIterator <T> BST <T> :: begin()
{
   Stack < BinaryNode <T> * > nodes;

   nodes.push(NULL);
   nodes.push(root);
   while (nodes.top() != NULL && nodes.top()->pLeft)
      nodes.push(nodes.top()->pLeft);

   return nodes;   
}

/*****************************************************
 * BST :: RBEGIN
 * Return the last node (right-most) in a binary search tree
 ****************************************************/
template <class T>
BSTIterator <T> BST <T> :: rbegin()
{
   Stack < BinaryNode <T> * > nodes;

   nodes.push(NULL);
   nodes.push(root);
   while (nodes.top() != NULL && nodes.top()->pRight)
      nodes.push(nodes.top()->pRight);

   return nodes;
}  

/*****************************************************
 * BST :: INSERT
 * Insert a node at a given location in the tree
 ****************************************************/
template <class T>
void BST <T> :: insert(const T & item) throw (const char *)
{
   // traveral pointer
   BinaryNode <T> * it = root;

   // check if empty
   if (empty())
   {
      // attempt to allode node
      try
      {
         // create new item for the tree
         BinaryNode <T> * newItem = new BinaryNode<T> (item);
         // set root to the new item
         root = newItem;
      }
      catch(std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a node";
      }
   }
   else
   {
      // loop until get to a leaf
      while (it->pLeft != NULL || it->pRight != NULL)
      {
         // goes left if less than
         if (item <= it->data)
         {
            // if you've reached the end of that side
            if (it->pLeft == NULL)
            {
               // get out of loop
               break;
            }
            // go left
            it = it->pLeft;
         }
         // goes right if greater than
         else
         {
            // if you've reached the end of that side
            if (it->pRight == NULL)
            {
               // get out of loop
               break;
            }
            // go right
            it = it->pRight;
         }
      }
   
      // attempt to allode node
      try
      {
         // create new item for the tree
         BinaryNode <T> * newItem = new BinaryNode<T> (item);

         // add left
         if (item <= it->data) // isleft
         {
            it->addLeft(newItem);
         }
         // add right
         else
         {
            it->addRight(newItem);
         }
      }
      catch(std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a node";
      }
   }
}

/*************************************************
 * BST :: REMOVE
 * Remove a given node as specified by the iterator
 ************************************************/
template <class T>
void BST <T> :: remove(BSTIterator <T> & it)
{
   // if that node has two children
   if (it.getNode()->pLeft != NULL
       && it.getNode()->pRight != NULL)
   {
      // find next in order part
      BinaryNode <T> * nextPart = it.getNode();

      // go right
      nextPart = nextPart->pRight;

      // go as left as possible
      while (nextPart->pLeft != NULL)
      {
         nextPart = nextPart->pLeft;
      }

      // get amount from next in order
      it.getNode()->data = nextPart->data;
      // remove next in order from tree
      BSTIterator <T> nextIt(nextPart);
      remove(nextIt);
   }
   // if node has one child
   else if (it.getNode()->pLeft != NULL
       || it.getNode()->pRight != NULL)
   {
      // get current node's child
      BinaryNode <T> * child = it.getNode()->pLeft;
      // if assigned the wrong pointer to child
      if (child == NULL)
      {
         // fix child
         child = it.getNode()->pRight;
      }

      // check if removing the root (no parent)
      if (it.getNode()->pParent == NULL)
      {
         // delete root
         delete it.getNode();
         // assign new root
         root = child;
      }
      // not the root
      else
      {
         // get current node's parent
         BinaryNode <T> * parent = it.getNode()->pParent;
         
         // check if removed child is right
         if (it.getNode() == parent->pRight)
         {
            // redirect parent's right pointer
            parent->pRight = child;
            // delete current node
            delete it.getNode();
         }
         // removed child is left
         else
         {
            // redirect parent's left pointer
            parent->pLeft = child;
            // delete current node
            delete it.getNode();
         }
      }
   }
   // node has no children
   else
   {
      // check if removing the root (no parent)
      if (it.getNode()->pParent == NULL)
      {
         // delete whole tree
         BinaryNode <T> * currentNode = it.getNode();
         deleteBinaryTree(currentNode);
      }
      // not the root of the tree
      else
      {
         // get current node's parent
         BinaryNode <T> * parent = it.getNode()->pParent;

         // check if removed child is right
         if (it.getNode() == parent->pRight)
         {
            // delete right child
            delete parent->pRight;
            parent->pRight = NULL;
         }
         // removed child is left
         else
         {
            // delete left child
            delete parent->pLeft;
            parent->pLeft = NULL;
         }
      }
   }
}

/****************************************************
 * BST :: FIND
 * Return the node corresponding to a given value
 ****************************************************/
template <class T>
BSTIterator <T> BST <T> :: find(const T & t)
{
   return searchFind(root, t);
}

/****************************************************
 * BST :: SEARCH FIND
 * Return the node corresponding to a given value,
 * called recursively
 ****************************************************/
template <class T>
BSTIterator <T> BST <T> :: searchFind(BinaryNode <T> * root, const T & t)
{
   // empty subtree
   if (root == NULL)
   {
      return end();
   }
   // else there is a nonempty subtree
   if (t < root->data)
   {
      // search left subtree
      return searchFind(root->pLeft, t);
   }
   else if (root->data < t)
   {
      // search right subtree
      return searchFind(root->pRight, t);
   }
   // item is found
   else
   {
      // make iterator pointing to the item found
      BSTIterator <T> it(root);
      return it;
   }
}

/**********************************************************
 * BINARY SEARCH TREE ITERATOR
 * Forward and reverse iterator through a BST
 *********************************************************/
template <class T>
class BSTIterator
{
public:
   // constructors
   BSTIterator(BinaryNode <T> * p = NULL)    { nodes.push(p);  }
   BSTIterator(Stack <BinaryNode <T> *> & s) { nodes = s;         }
   BSTIterator(const BSTIterator <T> & rhs)  { nodes = rhs.nodes; }

   // assignment
   BSTIterator <T> & operator = (const BSTIterator <T> & rhs)
   {
      // need an assignment operator for the Stack class.
      nodes = rhs.nodes;
      return *this;
   }

   // compare
   bool operator == (const BSTIterator <T> & rhs) const
   {
      // only need to compare the leaf node 
      return rhs.nodes.const_top() == nodes.const_top();
   }
   bool operator != (const BSTIterator <T> & rhs) const
   {
      // only need to compare the leaf node 
      return rhs.nodes.const_top() != nodes.const_top();
   }

   // de-reference. Cannot change because it will invalidate the BST
   T & operator * ()  
   {
      return nodes.top()->data;
   }

   // iterators
   BSTIterator <T> & operator ++ ();
   BSTIterator <T>   operator ++ (int postfix)
   {
      BSTIterator <T> itReturn = *this;
      ++(*this);
      return itReturn;
   }
   BSTIterator <T> & operator -- ();
   BSTIterator <T>   operator -- (int postfix)
   {
      BSTIterator <T> itReturn = *this;
      --(*this);
      return itReturn;
   }

   // must give friend status to remove so it can call getNode() from it
   friend void BST <T> :: remove(BSTIterator <T> & it);

private:
   
   // get the node pointer
   BinaryNode <T> * getNode() { return nodes.top(); }
   
   // the stack of nodes
   Stack < BinaryNode <T> * > nodes;
};


/**************************************************
 * BST ITERATOR :: INCREMENT PREFIX
 * advance by one
 *************************************************/
template <class T>
BSTIterator <T> & BSTIterator <T> :: operator ++ ()
{
   // do nothing if we have nothing
   if (nodes.top() == NULL)
      return *this;
   
   // if there is a right node, take it
   if (nodes.top()->pRight != NULL)
   {
      nodes.push(nodes.top()->pRight);

      // there might be more left-most children
      while (nodes.top()->pLeft)
         nodes.push(nodes.top()->pLeft);
      return *this;
   }

   // there are no right children, the left are done
   assert(nodes.top()->pRight == NULL);
   BinaryNode <T> * pSave = nodes.top();
   nodes.pop();

   // if the parent is the NULL, we are done!
   if (NULL == nodes.top())
      return *this;

   // if we are the left-child, got to the parent.
   if (pSave == nodes.top()->pLeft)
      return *this;

   // we are the right-child, go up as long as we are the right child!
   while (nodes.top() != NULL && pSave == nodes.top()->pRight)
   {
      pSave = nodes.top();
      nodes.pop();
   }
      
   return *this;      
}

/**************************************************
 * BST ITERATOR :: DECREMENT PREFIX
 * advance by one
 *************************************************/
template <class T>
BSTIterator <T> & BSTIterator <T> :: operator -- ()
{
   // do nothing if we have nothing
   if (nodes.top() == NULL)
      return *this;

   // if there is a left node, take it
   if (nodes.top()->pLeft != NULL)
   {
      nodes.push(nodes.top()->pLeft);

      // there might be more right-most children
      while (nodes.top()->pRight)
         nodes.push(nodes.top()->pRight);
      return *this;
   }

   // there are no left children, the right are done
   assert(nodes.top()->pLeft == NULL);
   BinaryNode <T> * pSave = nodes.top();
   nodes.pop();

   // if the parent is the NULL, we are done!
   if (NULL == nodes.top())
      return *this;

   // if we are the right-child, got to the parent.
   if (pSave == nodes.top()->pRight)
      return *this;

   // we are the left-child, go up as long as we are the left child!
   while (nodes.top() != NULL && pSave == nodes.top()->pLeft)
   {
      pSave = nodes.top();
      nodes.pop();
   }

   return *this;
}


#endif // BST_H
