/***********************************************************************
* Header:
*    List
* Summary:
*    This class contains the notion of a List: a bucket to hold
*    data for the user. This is just a starting-point for more advanced
*    constainers such as the vector, set, List, List, List, and map
*    which we will build later this semester.
*
*    This will contain the class definition of:
*        List         : A class that holds stuff
*        ListIterator : An interator through list
* Author
*    Br. Helfrich
************************************************************************/

#ifndef List_H
#define List_H

#include "node.h" // for node class

// forward declaration for ListIterator
template <class T>
class ListIterator;

/************************************************
 * List
 * A class that holds stuff
 ***********************************************/
template <class T>
class List
{
public:
   // default constructor : empty and kinda useless
   List() : numItems(0), pfront(NULL), pback(NULL) {}

   // copy constructor : copy it
   List(const List & rhs) throw (const char *);
   
   // destructor : free everything
   ~List()        { if (pfront) clear(); }
   
   // is the List currently empty
   bool empty() const  { return numItems == 0;         }

   // remove all the items from the List
   void clear()        { freeData(pfront); numItems = 0; pback = pfront; }

   // how many items are currently in the List?
   int size() const    { return numItems;              }

   // adds the item to the back of the List
   void push_back(const T & newItem) throw (const char *);

   // adds the item to the front of the List
   void push_front(const T & newItem) throw (const char *);
   
   // returns the front value of the List
   T & front() throw (const char *);

   // returns the back value of the List
   T & back() throw (const char *);

   // inserts item before the passed in iterator
   ListIterator <T> insert(const T & item, ListIterator <T> before)
      throw (const char *);
   
   // removes item that iterator is pointing to from the list
   void remove(ListIterator <T> item) throw (const char *);
   
   // returns an iterator of the front of the list
   ListIterator <T> begin() const
   {
      ListIterator <T> first(pfront);
      return first;
   }
   
   // returns an iterator of the back of the list
   ListIterator <T> rbegin() const
   {
      ListIterator <T> last(pback);
      return last;
   }

   // returns an iterator of past the back of the list
   ListIterator <T> end() const
   {
      ListIterator <T> pastEnd(NULL); //pback->pNext
      return pastEnd;
   }
   
   // returns an iterator of past the front of the list
   ListIterator <T> rend() const
   {
      ListIterator <T> pastFront(NULL); //pfront->pPrev
      return pastFront;
   }
   
   // assignment operator overload
   List <T> & operator = (const List <T> & rhs) throw (const char *);
   
private:
   int numItems;       // how many items are currently in the List?
   Node <T> * pfront;  // pointer to the front of the list
   Node <T> * pback;   // pointer to the end of the list
};

/**************************************************
 * List ITERATOR
 * An iterator through List
 *************************************************/
template <class T>
class ListIterator
{
  public:
    // default constructor
    ListIterator() : p(NULL) {}

    // initialize to direct p to some item
    ListIterator(Node <T> * p) : p(p) {}

    // copy constructor
    ListIterator(const ListIterator & rhs) { *this = rhs; }

    // assignment operator
    ListIterator & operator = (const ListIterator & rhs)
    {
       this->p = rhs.p;
       return *this;
    }

    // equals operator
    bool operator == (const ListIterator & rhs) const
    {
       return rhs.p == this->p;
    }

    // not equals operator
    bool operator != (const ListIterator & rhs) const
    {
       return rhs.p != this->p;
    }

    // dereference operator
    T & operator * ()
    {
       return p->data;
    }
    
    // prefix increment
    ListIterator <T> & operator ++ ()
    {
       // increment the iterator
       p = p->pNext;
       return *this;
    }

    // postfix increment
    ListIterator <T> operator++(int postfix)
    {
       ListIterator tmp(*this);
       // increment the iterator
       p = p->pNext;
       return tmp;
    }

    // prefix decrement
    ListIterator <T> & operator -- ()
    {
       // decrement the iterator
       p = p->pPrev;
       return *this;
    }

    // postfix decrement
    ListIterator <T> operator--(int postfix)
    {
       ListIterator tmp(*this);
       // decrement the iterator
       p = p->pPrev;
       return tmp;
    }

    // So that these methods can access p
    friend ListIterator <T> List <T> :: insert
       (const T & item, ListIterator <T> before) throw (const char *);
    friend void List <T> :: remove(ListIterator <T> item) throw (const char *);
    
  private:
    Node <T> * p;
};

/*******************************************
 * List :: COPY CONSTRUCTOR
 *******************************************/
template <class T>
List <T> :: List(const List <T> & rhs) throw (const char *)
{      
   // attempt to allocate
   try
   {
      // copies rhs contents into new list
      pfront = copy(rhs.pfront);
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: unable to allocate a new node for a list";
   }
   
   // copy over the member variables
   numItems = rhs.numItems;

   // pointing the new list
   Node <T> * ending(pfront);
   // ends at the last item in the list
   while (ending->pNext != NULL)
   {
      //traverse through the list
      ending = ending->pNext;
   }

   // now pointing to the back
   pback = ending;
}

/**********************************************
 * List :: operator =
 * Allows user to assign two Lists together
 **********************************************/
template <class T>
List <T> & List <T> :: operator = (const List <T> & rhs)
   throw (const char *)
{
   // attempt to allocate
   try
   {
      // delete lhs data list
      clear();
      // copy over rhs and set this front to that new copy
      pfront = copy(rhs.pfront);
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: unable to allocate a new node for a list";
   }

   // copy over the member variables
   numItems = rhs.numItems;

   // pointing the new list
   Node <T> * ending(pfront);
   // ends at the last item in the list
   while (ending->pNext != NULL)
   {
      //traverse through the list
      ending = ending->pNext;
   }

   // now pointing to the back
   pback = ending;

   return (*this);
}

/**********************************************
 * List :: push back
 * Takes an item and adds it to the end of the List
 **********************************************/
template <class T>
void List <T> :: push_back(const T & newItem) throw (const char *)
{
   try
   {
      if (empty())
      {
         // add to the front
         nInsert(newItem, pfront);
         //set back to the back of the list
         pback = pfront;
      }
      else
      {         
         // insert the newItem to the back of the list
         nInsert(newItem, pback);

         // needs to change pback and pfront to the true values
         while (pback->pNext != NULL)
         {
            pback = pback->pNext;
         }
         while (pfront->pPrev != NULL)
         {
            pfront = pfront->pPrev;
         }
      }
   }
   catch(std::bad_alloc)
   {
      throw "ERROR: unable to allocate a new node for a list";
   }
   
   // add one to the list
   numItems++;
}

/**********************************************
 * List :: push front
 * Takes an item and adds it to the front of the List
 **********************************************/
template <class T>
void List <T> :: push_front(const T & newItem) throw (const char *)
{
   try
   {
      if (empty())
      {
         // insert the newItem to the front of the list
         nInsert(newItem, pfront, true);
         //set back to the back of the list
         pback = pfront;         
      }
      else
      {
         // insert the newItem to the front of the list
         nInsert(newItem, pfront, true);
         
         // needs to change pback and pfront to the true values
         while (pback->pNext != NULL)
         {
            pback = pback->pNext;
         }
         while (pfront->pPrev != NULL)
         {
            pfront = pfront->pPrev;
         }
      }

   }
   catch(std::bad_alloc)
   {
      throw "ERROR: unable to allocate a new node for a list";
   }
   
   // add one to the list
   numItems++;
}

/**********************************************
 * List :: front
 * Returns the front amount of the List
 **********************************************/
template <class T>
T & List <T> :: front() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: unable to access data from an empty list";
   }
   else
   {
      return pfront->data;
   }
}

/**********************************************
 * List :: back
 * Returns the back amount of the List
 **********************************************/
template <class T>
T & List <T> :: back() throw (const char *)
{
   if (empty())
   {
      throw "ERROR: unable to access data from an empty list";
   }
   else
   {
      return pback->data;
   }
}

/**********************************************
 * List :: insert
 * Inserts item before the passed in iterator
 * then returns new item in the list
 **********************************************/
template <class T>
ListIterator <T> List <T> :: insert(const T & item, ListIterator <T> before)
   throw (const char *)
{
   // attempt allocation
   try
   {
      Node<T> * tmp  =  new Node<T>(item);
   
      // insert into an empty list
      if (pfront == NULL)
      {
         pfront = tmp;
         pback = tmp;
      }
      // insert at end of list
      else if (before == end())
      {
         pback->pNext = tmp;
         tmp->pPrev = pback;
         pback = tmp;
      }
      // insert at beginning or middle
      else
      {
         // pNext gets the address of what before is pointing to
         tmp->pNext = before.p;
         tmp->pPrev = before.p->pPrev;
         before.p->pPrev = tmp;
      
         // insert at beginning
         if (before.p == pfront)
         {
            pfront = tmp;
         }
         // insert in middle
         else
         {
            tmp->pPrev->pNext = tmp;
         }
      }
   }
   catch(std::bad_alloc)
   {
      throw "ERROR: unable to allocate a new node for a list";
   }

   // added one to the list
   numItems++;

}

/**********************************************
 * List :: remove
 * Removes item that iterator is pointing to from the list
 **********************************************/
template <class T>
void List <T> :: remove(ListIterator <T> item) throw (const char *)
{
   // if trying to remove from an invalid location of the list
   if (item == end())
   {
      throw "ERROR: unable to remove from an invalid location in a list";
   }
   else
   {
      // if it's at the beginning
      if (item.p == pfront)
      {
         // set pfront to the new front
         pfront = pfront->pNext;
         // sets the next to be the new front of the list
         pfront->pPrev = NULL;
      }
      // removing from the end
      else if (item.p->pNext == NULL)
      {
         // set pback to the new back
         pback = pback->pPrev;
         // new end of the list
         pback->pNext = NULL;
      }
      // removing from middle
      else
      {
         // adjust previous' next pointer
         item.p->pPrev->pNext = item.p->pNext;
         // adjust next' previous pointer
         item.p->pNext->pPrev = item.p->pPrev;
      }      
      delete item.p;
   }

   // took one out of the list
   numItems--;
}

#endif // List_H
