/***********************************************************************
 * Implementation:
 *    FIBONACCI
 * Summary:
 *    This will contain the implementation for fibonacci() as well as any
 *    other function or class implementations you may need
 * Author
 *    Conner Charles
 **********************************************************************/

#include <iostream>
#include <iomanip>       // for setw and setfill
#include "fibonacci.h"   // for fibonacci() prototype
#include "list.h"        // for LIST
using namespace std;

// MAKE INTO A WHOLENUMBER CLASS!!!


/************************************************
 * Adding operator
 * Takes a LL on both sides and adds them together
 * returns lhs
 ***********************************************/
List <int> & operator + (List <int> & lhs, List <int> & rhs)
{
   //add them together
   ListIterator <int> lit; // left iterator
   ListIterator <int> rit; // right iterator
      
   int remainder = 0;
   int carry = 0;
      
   // starts at the beginning of both and moves through list
   for (lit = lhs.begin(), rit = rhs.begin(); lit != lhs.end();
        lit++, rit++)
   {
      // get numbers of current iteration
      int lnum = *lit;
      int rnum = *rit;

      // add them together
      remainder = (lnum + rnum + carry) % 1000; // 3 digits each node
      carry = (lnum + rnum + carry) / 1000; // 0 or 1

      // set new number
      *lit = remainder;
   }
   // add carry to the end if needed
   if (carry)
   {
      // carry 1 over
      lhs.push_back(1);
      // keep the lengths the same
      rhs.push_back(0);
   }
   
   return lhs;
}

/************************************************
 * Find Fib Num
 * Computes the fibonacci <number> and displays it
 ***********************************************/
void findFibNum(bool isDisplay, int & number)
{
   // book keeping
   List <int> * l1 = new List <int>;
   List <int> * l2 = new List <int>;
   List <int> * sum = new List <int>;

   // start off with the first fib number
   l1->push_back(0);
   l2->push_back(1);
   sum->push_back(1);

   // displays the first <number> Fibonacci numbers
   while (number > 0)
   {      
      if (isDisplay)
      {
         // display current number
         for (ListIterator <int> it = sum->rbegin(); it != sum->rend(); it--)
         {
            cout << "\t" << *it << endl;
         }
      }
      // if you just want the last number
      else if (number == 1)
      {
         // gets the first part of the number
         ListIterator <int> it = sum->rbegin();
         cout << "\t" << *it;
         it--;
         // gets the rest with commas
         for (; it != sum->rend(); it--)
         {
            cout << "," << setw(3) << setfill('0') << *it;
         }
         cout << endl;
      }
      
      // get sum of 2 numbers
      *sum = *l1 + *l2;
      // sum is new l1
      *l1 = *sum;
      // swap the pointers of l1 and l2
      List <int> * tmp;
      tmp = l1;
      l1 = l2;
      l2 = tmp;
      // decrement number
      number--;
   }

   // cleaning up
   delete l1;
   delete l2;
   delete sum;
}

/************************************************
 * FIBONACCI
 * The interactive function allowing the user to
 * display Fibonacci numbers
 ***********************************************/
void fibonacci()
{
   // show the first serveral Fibonacci numbers
   int number;
   cout << "How many Fibonacci numbers would you like to see? ";
   cin  >> number;

   findFibNum(true, number);
   
   // prompt for a single large Fibonacci
   cout << "Which Fibonacci number would you like to display? ";
   cin  >> number;

   // your code to display the <number>th Fibonacci number
   findFibNum(false, number);
}
