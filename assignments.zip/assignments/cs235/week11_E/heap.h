/***********************************************************************
* Program:
*    Week 11, Sorting
*    Brother Ercanbrack, CS 235
*
* Author:
*   Conner Charles
* Summary: 
*   Functions that allow user to sort any data using a heap sort
************************************************************************/
#include <vector>
   
using namespace std;

/*************************************************************************
* This function sorts a vector using a heap sort.
* Input:  data -  Vector to be sorted.
* Output: data -  Vector sorted
**************************************************************************/
template<class T>
void heapSort(vector<T> &data)
{
   // convert to a heap
   heapify(data);

   // because data[0] isn't being used
   int numItems = data.size() - 1;
   
   for (int i = numItems; i > 1; i--) //  down to 2
   {
      // do a root-leaf exchange
      T tmp = data[1];
      data[1] = data[i];
      data[i] = tmp;
      // prune the leaf and percolate down
      numItems--;
      percolateDown(1, numItems, data);
   }
}

/*************************************************************************
* This function organizes the vector into a heap
**************************************************************************/
template<class T>
void heapify(vector <T> & data)
{
   // because data[0] isn't being used
   int numItems = data.size() - 1;
   
   // start at last nonleaf   down to 1
   for (int r = numItems / 2; r > 0; r--)
   {
      percolateDown(r, numItems, data);
   }
}

/*************************************************************************
* This function organizes the vector from the index given down to the end
* of the "tree", making sure that the values satisfy heap conditions.
**************************************************************************/
template<class T>
void percolateDown(int index, int numItems,  vector <T> & data)
{
   int child;
   child = 2 * index; // c is location of left child

   while (child <= numItems)
   {      
      // if index has two children and right child is larger
      if (child < numItems && data[child] < data[child + 1])
      {
         // make right child
         child++;
      }
      
      // swap node and largest child if necessary,
      // and move down to the next subtree
      if (data[index] < data[child]) // Parent fails heap-order cond.
      {
         // fix it
         T tmp = data[index];
         data[index] = data[child];
         data[child] = tmp;
         // but we may have messed up binary tree at c, so check it.
         index = child;
         child *= 2;
      }
      // heap-order condition holds
      else
      {
         // so we can stop
         return;
      }
   }
}
