/***********************************************************************
* Program:
*    Week 11, Sorting
*    Brother Ercanbrack, CS 235
*
* Author:
*   Conner Charles
* Summary: 
*   These functions make up a merge sort, which sorts any data into a
*   sorted list. One can utilize this sort by simply just calling mergeSort().
************************************************************************/

#include <list>
   
using namespace std;

/*************************************************************************
* This function sorts a linked list using a Natural Merge Sort.
* Input:  data -  linked list of data to be sorted.
* Output: data -  sorted linked list
**************************************************************************/
template<class T>
void mergeSort(list<T> &data)
{
   int numSubList = 0;
 
   // repeat until the number of sublists is 1
   while (numSubList != 1)
   {
      // call split and merge list
      split(data, numSubList);
   }
}

/*************************************************************************
* This function splits a single list into two new lists, every other
* sublist going to each list.
**************************************************************************/
template<class T>
void split(list<T> &data, int & numSubList)
{
   // split lists
   list <T> L1;
   list <T> L2;

   // pointing to which list to add to
   list <T> * current = &L1;
   // iterator for the main list
   typename list<T>::iterator dataIt;

   for (dataIt = data.begin(); dataIt != data.end(); dataIt++)
   {
      //  last item added   current item
      if (current->back() > *dataIt)
      {
         // end of the sublist, switch to other list
         if (current == &L1)
            current = &L2;
         else
            current = &L1;
      }
      // add to the current list
      current->push_back(*dataIt);
   }
   
   // check number of subList
   if (L2.empty())
   {
      // done sorting to one list
      numSubList = 1;
      // quit sorting
      return;
   }
   
   // merge them back together into main list
   merge(L1, L2, data);
}

/*************************************************************************
* This function merges two lists in to a new list in a sorted order. 
**************************************************************************/
template<class T>
void merge(list<T> &L1, list<T> &L2, list<T> &data)
{
   // new list of merged lists
   data.clear();

   typename list<T>::iterator it1 = L1.begin();
   typename list<T>::iterator it2 = L2.begin();

   // while it is not the end of any list
   while (it1 != L1.end() && it2 != L2.end())
   {
      // while it is not the end of either list
      while (it1 != L1.end() && it2 != L2.end())
      {
         if (*it1 < *it2)
         {
            // copy element from L1 into mergedList
            data.push_back(*it1);
            // go to next element
            it1++;
         }
         else
         {
            // copy element from L2 into mergedList
            data.push_back(*it2);
            // go to next element
            it2++;
         }
      }
      // if the end of sublist L1 has been met
      if (it1 == L1.end())
      {
         // copy the rest of the L2 into mergedList
         while (it2 != L2.end())
         {
            data.push_back(*it2);
            // go to next element
            it2++;
         }
      }
      // if the end of sublist L2 has been met
      else if (it2 == L2.end())
      {
         // copy the rest of the L1 into mergedList
         while (it1 != L1.end())
         {
            data.push_back(*it1);
            // go to next element
            it1++;
         } 
      }
   }
}
