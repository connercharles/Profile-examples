/***********************************************************************
* Program:
*    Week 11, Sorting
*    Brother Ercanbrack, CS 235
* Author:
*    Brother Ercanbrack

* Summary: 
*
************************************************************************/

#include <iostream>        // for CIN and COUT
#include <cstring>         // for strcmp
#include <iomanip>         // for SETW
#include <fstream>         // for ifstream
#include "heap.h"
#include "merge.h"

using namespace std;


/**********************************************************************
 * MAIN
 * Get the sort name and filename from the command line.
 * call the appropriate sort to sort the data contained in the file.
 ***********************************************************************/
int main(int argc, const char* argv[])
{

   if (argc < 3)
   {
      cout << "Usage: programName sortName fileName" << endl;
   }
   else
   {
      if (strcmp(argv[1], "heap") == 0)
      {
         vector <int> data;
         
         //******** read the file into a vector
         // open file
         ifstream fin(argv[2]);
         // for retrieving data
         int input;
         // don't use vector[0]
         data.push_back(0);
         // loop through a retreive data from file
         while(fin >> input)
         {
            // adds data to the vector
            data.push_back(input);
         }
         // close file
         fin.close();
         
         // call your heapsort passing the vector as a parameter
         heapSort(data);
         
         // output the sorted vector.
         for (int i = 1; i != data.size(); i++)
         {
            cout << data[i] << " ";
         }
         // to make things pretty
         cout << endl;
      }
      else if (strcmp(argv[1], "merge") == 0)
      {
         list <int> data;
         
         //******** read the file into a list
         // open file
         ifstream fin(argv[2]);
         // for retrieving data
         int input;
         // loop through a retreive data from file
         while(fin >> input)
         {
            // adds data to the list
            data.push_back(input);
         }
         // close file
         fin.close();

         // call your merge sort
         mergeSort(data);
         
         // output the sorted linked list
         list<int>::iterator it;
         for (it = data.begin(); it != data.end(); it++)
         {
            cout << *it << " ";
         }
         // to make things pretty
         cout << endl;         
      }
      else
      {
         cout << "\nInvalid sort name - must be 'heap' or 'merge'" << endl;
      }
   }
   return 0;
}
