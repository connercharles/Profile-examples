/***********************************************************************
* Program:
*    Week 11, Sorting
*    Brother Ercanbrack, CS 235
* Author:
*    Brother Ercanbrack

* Summary: 
*
************************************************************************/

#include <iostream>        // for CIN and COUT
#include <cstring>         // for strcmp
#include <iomanip>         // for SETW
#include "heap.h"
#include "merge.h"

using namespace std;


/**********************************************************************
 * MAIN
 * Get the sort name and filename from the command line.
 * call the appropriate sort to sort the data contained in the file.
 ***********************************************************************/
int main(int argc, const char* argv[])
{

   if (argc < 3)
   {
      cout << "Usage: programName sortName fileName" << endl;
   }
   else
   {
      if (strcmp(argv[1], "heap") == 0)
      {
         // read the file into a vector
         // call your heapsort passing the vector as a parameter
         // output the sorted vector.
      }
      else if (strcmp(argv[1], "merge") == 0)
      {
         // read the file into a linked list
         // call your merge sort
         // output the sorted linked list
      }
      else
      {
         cout << "\nInvalid sort name - must be 'heap' or 'merge'" << endl;
      }
   }
   return 0;
}
