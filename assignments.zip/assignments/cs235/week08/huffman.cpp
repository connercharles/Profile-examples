/***********************************************************************
 * Module:
 *    Week 08, Huffman
 *    Brother Helfrich, CS 235
 * Author:
 *    Conner Charles
 * Summary:
 *    This program will implement the huffman() function
 ************************************************************************/

#include "huffman.h"       // for HUFFMAN() prototype
#include "pair.h"          // for Pair class
#include "bnode.h"         // for BinaryNode
#include <string>          // for string
#include <iostream>        // for cout/cin
#include <fstream>         // for ifstream
#include <vector>          // for vector
#include <algorithm>       // for sort

using namespace std;

/*******************************************
 * ENCODING HUFFMAN
 * Goes through the tree and creates codes for
 * each string in the tree
 *******************************************/
void encodingHuffman(BinaryNode < Pair <float, string> > * tree,
                     string code, vector < Pair <string, string> > & table)
{
   // tree is a leaf
   if (tree->pLeft == NULL && tree->pRight == NULL)
   {
      Pair <string, string> leaf;
      // string/letter
      leaf.first = tree->data.second;
      // code
      leaf.second = code;
      // add code of the leaf to table
      table.push_back(leaf);
      // sort table
      sort(table.begin(), table.end());
   }
   else
   {
      encodingHuffman(tree->pLeft, code + "0", table); // left
      encodingHuffman(tree->pRight, code + "1", table); // right
   }
}

/*******************************************
 * DISPLAY CODES
 * Displays the Huffman codes of each string in the tree
 *******************************************/
void displayCodes(const vector <Pair <string, string> > & table)
{
   for (int i = 0; i < table.size(); i++)
   {
      cout << table[i].first << " = " << table[i].second << endl;
   }
}

/*****************************************************
 * Less than - sort
 * Comparing Pair for the sort function
 ****************************************************/
struct lessThanSort
{
   bool operator () (const BinaryNode < Pair <float, string> > * lhs,
                     const BinaryNode < Pair <float, string> > * rhs)
   {
      // if it's less than
      if ((lhs->data.first) < (rhs->data.first))
      {
         return true;
      }
      // if they are equal
      else if ((lhs->data.first) == (rhs->data.first))
      {
         // compare the string/letter, check nulls
         if ((lhs->data.second) == ""
             || (rhs->data.second) == "")
         {
            return true;
         }
         // else
         return false;
      }
      // if it's not less than
      return false;
   }
};

/*******************************************
 * Prompt/Read File
 * Prompts user for file then reads it and
 * retreives all the data from it
 *******************************************/
void promptReadFile(vector <BinaryNode < Pair <float, string> > * > & list)
{
   //*********** Prompt user
   string fileName;
   cout << "Enter the filename containing the value frequencies: ";
   cin >> fileName;
   
   //*********** Read values
   Pair <float, string> input;

   // open file
   ifstream fin(fileName.c_str());

   // loop through a retreive data from file
   while(!fin.eof())
   {
      // get the letter/string
      fin >> input.second;
      // get the frequency
      fin >> input.first;

      // create node * with input in data
      BinaryNode < Pair <float, string> > * nodeInput;
      nodeInput = new BinaryNode < Pair <float, string> > (input);
      // add to vector
      list.push_back(nodeInput);
   }
   // get ride of blank last item in list
   list.pop_back();
   // close file
   fin.close();
}

/*******************************************
 * Generate Tree
 * Creates the binary tree for the letters given
 *******************************************/
void generateTree(vector <BinaryNode < Pair <float, string> > * > & list)
{
   // sort the list based on frequencies
   sort(list.begin(), list.end(), lessThanSort());
   
   // until there is 1 item in the list
   while (list.size() != 1)
   {
      // find sum of two nodes
      Pair <float, string> sum;
      // sum of the first two in the list
      sum.first = list[0]->data.first + list[1]->data.first;
      // create new node
      BinaryNode < Pair <float, string> > * sumNode;
      sumNode = new BinaryNode < Pair <float, string> > (sum);
      // has those two add to left and right
      sumNode->addLeft(list[0]); // smallest on left
      sumNode->addRight(list[1]); 
      // remove from the list/update new node tree
      list.erase(list.begin());
      list[0] = sumNode;
      // sort the list based on frequencies
      sort(list.begin(), list.end(), lessThanSort());
   }
}

/*******************************************
 * HUFFMAN
 * Driver program to exercise the huffman generation code
 *******************************************/
void huffman()
{
   // a vector of bnode *'s with pair data
   vector <BinaryNode < Pair <float, string> > * > list;
   
   promptReadFile(list);
   
   generateTree(list);
   
   //*********** Make encoding table
   string code;
   vector < Pair <string, string> > table;
   // get codes for each string/letter
   encodingHuffman(list[0], code, table);
   
   displayCodes(table);
   
   // clean up
   deleteBinaryTree(list[0]);
   
   return;
}
