/***********************************************************************
 * Module:
 *    Week 10, WORD COUNT
 *    Brother Helfrich, CS 235
 * Author:
 *    Conner Charles
 * Summary:
 *    This program will implement the wordCount() function
 ************************************************************************/

#include "map.h"       // for MAP
#include "wordCount.h" // for wordCount() prototype
#include <string>
#include <iostream>    // for cout/cin
#include <fstream>     // for ifstream

using namespace std;


/*****************************************************
 * READ FILE
 * Takes fileName and adds each word in the file to 
 * the map, incrementing each time the word is found.
 *****************************************************/
void readFile(Map <string, int> & counts, const string & fileName)
{
   // open file
   ifstream fin(fileName.c_str());

   string word;

   // loop through a retreive data from file
   while(fin >> word)
   {
      // add to map and increments it
      counts[word]++;
   }

   // close file
   fin.close();   
}

/*****************************************************
 * WORD COUNT
 * Prompt the user for a file to read, then prompt the
 * user for words to get the count from
 *****************************************************/
void wordCount()
{
   // create word counting map
   Map <string, int> counter;

   // prompt user for file name
   string fileName;
   cout << "What is the filename to be counted? ";
   cin >> fileName;

   // read file
   readFile(counter, fileName);

   // prompt user to display content of map
   string word;
   
   cout << "What word whose frequency is to be found. Type ! when done\n";
   cout << "> ";
   cin  >> word;

   MapIterator <string, int> it;
   it = counter.find(word);

   while (word != "!")
   {
      it = counter.find(word);

      // if word is not in the map
      if (it == counter.end())
      {
         // display
         cout << "\t" << word << " : ";
         cout << "0" << endl;
      }
      // if it is in the map
      else
      {
         // display
         cout << "\t" << word << " : ";
         cout << *it << endl;
      }

      cout << "> ";
      cin  >> word;
   }
}
