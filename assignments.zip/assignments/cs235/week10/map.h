/***********************************************************************
* Header:
*    Map
* Summary:
*    This class contains the notion of a Map: a bucket to hold
*    data for the user. This is just a starting-point for more advanced
*    constainers such as the map, map, Map, Map, Map, and map
*    which we will build later this semester.
*
*    This will contain the class definition of:
*        Map         : A class that holds stuff
*        MapIterator : An interator through Map
* Author
*    Br. Helfrich
************************************************************************/

#ifndef Map_H
#define Map_H

#include "bst.h"   // for BST class
#include "pair.h"  // for Pair class

// forward declaration for MapIterator
template <class T1, class T2>
class MapIterator;

/************************************************
 * Map
 * A class that holds stuff
 ***********************************************/
template <class T1, class T2>
class Map
{
public:
   // default constructor : empty and kinda useless
   Map() : numItems(0), tree() {}

   // copy constructor : copy it
   Map(const Map & rhs) throw (const char *);
   
   // destructor : free everything
   ~Map()        { clear(); }
   
   // is the Map currently empty
   bool empty() const  { return numItems == 0;         }

   // remove all the items from the Map
   void clear()        { tree.clear(); numItems = 0; }

   // how many items are currently in the Map?
   int size() const    { return numItems;              }
   
   // returns an iterator of the front of the Map
   MapIterator <T1, T2> begin()
   {
      MapIterator <T1, T2> first(tree.begin());
      return first;
   }

   // returns an iterator of the end of the Map
   MapIterator <T1, T2> rbegin()
   {
      MapIterator <T1, T2> first(tree.rbegin());
      return first;
   }

   // returns an iterator of past the back of the Map
   MapIterator <T1, T2> end()
   {
      MapIterator <T1, T2> pastEnd(tree.end());
      return pastEnd;
   }

   // returns an iterator of before the front of the Map
   MapIterator <T1, T2> rend()
   {
      MapIterator <T1, T2> beforeBeginning(tree.rend());
      return beforeBeginning;
   }

      
   // assignment operator overload
   Map < T1, T2 > & operator = (const Map < T1, T2 > & rhs)
      throw (const char *);

   // bracket operator overload
   T2 & operator [] (T1 key);

   // search for item within tree
   MapIterator <T1, T2> find(T1 key);
   
private:
   int numItems;                // how many items are currently in the Map?
   BST < Pair <T1, T2> > tree;  // Binary Search Tree of Pairs
};

/**************************************************
 * Map ITERATOR
 * An iterator through Map
 *************************************************/
template <class T1, class T2> // for Pairs
class MapIterator
{
  public:
   // constructors
   MapIterator() : it() {}
   MapIterator(const MapIterator <T1, T2> & rhs)  { it = rhs.it; }
   MapIterator(const BSTIterator < Pair <T1, T2> > & rhs)  { it = rhs; }

   // assignment
   MapIterator <T1, T2> & operator = (const MapIterator <T1, T2> & rhs)
   {
      // call BSTIterator operator = 
      it = rhs.it;
      return *this;
   }

   // compare
   bool operator == (const MapIterator <T1, T2> & rhs) const
   {
      // call BSTIterator compare
      return it == rhs.it;
   }
   bool operator != (const MapIterator <T1, T2> & rhs) const
   {
      // call BSTIterator compare
      return it != rhs.it;
   }

   // de-reference. Cannot change because it will invalidate the BST
   T2 & operator * ()
   {
      // return the value
      return it.getNode()->data.second;
   }

   // iterators
   MapIterator <T1, T2> & operator ++ ()
   {
      // calls BSTIterator for this operator
      ++it;
      return *this;
   }
   MapIterator <T1, T2>   operator ++ (int postfix)
   {
      // calls BSTIterator for this operator
      it++;
      return this;
   }
   MapIterator <T1, T2> & operator -- ()
   {
      // calls BSTIterator for this operator
      --it;
      return *this;
   }
   MapIterator <T1, T2>   operator -- (int postfix)
   {
      // calls BSTIterator for this operator
      it--;
      return this;
   }
   
  private:
   BSTIterator < Pair <T1, T2> > it;
};

/*******************************************
 * Map :: COPY CONSTRUCTOR
 *******************************************/
template <class T1, class T2>
Map < T1, T2 > :: Map(const Map < T1, T2 > & rhs)
   throw (const char *)
{
   // copy over the member variables
   numItems = rhs.numItems;
   // copy over the tree
   tree = rhs.tree;
}

/**********************************************
 * Map :: operator =
 * Allows user to assign two Maps together
 **********************************************/
template <class T1, class T2>
Map < T1, T2 > & Map < T1, T2 > :: operator = (const Map < T1, T2 > & rhs)
   throw (const char *)
{
   // copy over the member variables
   numItems = rhs.numItems;
   // copy over the tree
   tree = rhs.tree;
}

/**********************************************
 * Map :: find
 * Search for item within tree by key, returns
 * iterator pointing to where key is
 **********************************************/
template <class T1, class T2>
MapIterator <T1, T2> Map <T1, T2> :: find(T1 key)
{
   // create Pair holding key
   Pair <T1, T2> pairKey;
   // fill pair values with key
   pairKey.first = key;
   pairKey.second = T2();
   // use BST find
   MapIterator <T1, T2> it(tree.find(pairKey));
   return it;
}

/**********************************************
 * Map :: operator []
 * Retrieves data associated with the key if it
 * exists, if not, then it will create the key.
 **********************************************/
template <class T1, class T2>
T2 & Map <T1, T2> :: operator [] (T1 key)
{
   // Iterator of key location
   MapIterator <T1, T2> itKey = find(key);
   
   // check to see if key is not in tree
   if (itKey == end())
   {
      // create Pair holding key
      Pair <T1, T2> pairKey;
      // fill pair values with key and defaults
      pairKey.first = key;
      pairKey.second = T2();
      // add to key to the tree
      tree.insert(pairKey);
      // update iterator
      itKey = find(key);
      // added item
      numItems++;
   }

   // return value of key
   return *itKey;
}

#endif // Map_H
