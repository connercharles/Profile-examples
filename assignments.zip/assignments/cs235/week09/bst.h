/***********************************************************************
 * Component:
 *    Week 09, Binary Search Tree (BST)
 *    Brother Helfrich, CS 235
 * Author:
 *    Conner Charles
 * Summary:
 *    
 ************************************************************************/

#ifndef BST_H
#define BST_H

#include "bnode.h" // for BinaryNode
#include <stack>   // for stack?

/************************************************
 * BST
 * A class that holds stuff
 ***********************************************/
template <class T>
class BST
{
  public:
   // default constructor : empty and kinda useless
   BST() : root(NULL) {}

   //*************************************************NEED TO MAKE THIS
   // copy constructor : copy it
   //BST(const BST & rhs) throw (const char *);

   // destructor : free everything
   ~BST()        { if (root) clear(); }

   // is the BST currently empty
   bool empty() const  { return root == NULL;         }

   // remove all the items from the BST
   void clear()        { deleteBinaryTree(root); }

   // adds item to the tree
   void insert(T item) throw (const char *);

   // remove

   // searches tree for item
   //BSTIterator <T> find(T item);

   // begin

   // end

   // rbegin

   // rend
   
   //*************************************************NEED TO MAKE THIS
   // assignment operator overload
   //BST <T> & operator = (const BST <T> & rhs) throw (const char *);

  private:
   BinaryNode <T> * root;  // pointer to the top of the BST
};

/*******************************************
 * BST :: COPY CONSTRUCTOR
 *******************************************/
/*
template <class T>
BST <T> :: BST(const BST <T> & rhs) throw (const char *)
{
   // attempt to allocate
   try
   {
      // copies rhs contents into new BST
      
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: unable to allocate a new node for a BST";
   }

}
*/

/**********************************************
 * BST :: operator =
 * Allows user to assign two BSTs together
 **********************************************/
/*
template <class T>
BST <T> & BST <T> :: operator = (const BST <T> & rhs)
   throw (const char *)
{
   // attempt to allocate
   try
   {
      // delete lhs data BST
      clear();
      // copy over rhs and set this front to that new copy
      pfront = copy(rhs.pfront);
   }
   catch (std::bad_alloc)
   {
      throw "ERROR: unable to allocate a new node for a BST";
   }
   
   // copy over the member variables
   numItems = rhs.numItems;
   
   // pointing the new BST
   Node <T> * ending(pfront);
   // ends at the last item in the BST
   while (ending->pNext != NULL)
   {
      //traverse through the BST
      ending = ending->pNext;
   }
   
   // now pointing to the back
   pback = ending;
   
   return (*this);
}
*/
   
/**********************************************
 * BST :: insert
 * Allows user to insert item to the tree,
 * adds the element in sorted order
 **********************************************/
template <class T>
void BST <T> :: insert(T item) throw (const char *)
{
   // traveral pointer
   BinaryNode <T> * it = root;
   // for adding to the tree
   bool isLeft;

   // check if empty
   if (empty())
   {
      // attempt to allode node
      try
      {
         // create new item for the tree
         BinaryNode <T> * newItem = new BinaryNode<T> (item);
         // set root to the new item
         root = newItem;
      }
      catch(std::bad_alloc)
      {
         throw "ERROR: Unable to allocate a node";
      }
   }
   else
   {
      // loop until get to a leaf
      while (it->pLeft != NULL && it->pRight != NULL)
      {
         // goes left if less than
         if (item <= it->data)
         {
            // if you've reached the end of that side
            if (it->pLeft == NULL)
            {
               // get ready to add left
               isLeft = true;
               // get out of loop
               break;
            }
            // go left
            it = it->pLeft;
         }
         // goes right if greater than
         else
         {
            // if you've reached the end of that side
            if (it->pRight == NULL)
            {
               // get ready to add right
               isLeft = false;
               // get out of loop
               break;
            }
            // go right
            it = it->pRight;
         }
      }
   }
   
   // attempt to allode node
   try
   {
      // create new item for the tree
      BinaryNode <T> * newItem = new BinaryNode<T> (item);

      // add left
      if (isLeft)
      {
         it->addLeft(newItem);
      }
      // add right
      else
      {
         it->addRight(newItem);
      }
   }
   catch(std::bad_alloc)
   {
      throw "ERROR: Unable to allocate a node";
   }
}
   
/**************************************************
 * BST ITERATOR :: DECREMENT PREFIX
 *     advance by one. Note that this implementation uses
 *     a stack of nodes to remember where we are. This stack
 *     is called "nodes".
 * Author:      Br. Helfrich
 * Performance: O(log n) though O(1) in the common case
 *************************************************/
/*
template <class T>
BSTIterator <T> & BSTIterator <T> :: operator -- ()
{
   // do nothing if we have nothing
   if (nodes.top() == NULL)
      return *this;

   // if there is a left node, take it
   if (nodes.top()->pLeft != NULL)
   {
      nodes.push(nodes.top()->pLeft);

      // there might be more right-most children
      while (nodes.top()->pRight)
         nodes.push(nodes.top()->pRight);
      return *this;
   }

   // there are no left children, the right are done
   assert(nodes.top()->pLeft == NULL);
   BinaryNode <T> * pSave = nodes.top();
   nodes.pop();

   // if the parent is the NULL, we are done!
   if (NULL == nodes.top())
      return *this;

   // if we are the right-child, got to the parent.
   if (pSave == nodes.top()->pRight)
      return *this;

   // we are the left-child, go up as long as we are the left child!
   while (nodes.top() != NULL && pSave == nodes.top()->pLeft)
   {
      pSave = nodes.top();
      nodes.pop();
   }

   return *this;
}

*/

#endif // BST_H

