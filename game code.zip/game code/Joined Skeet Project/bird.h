
#ifndef SHOOTABLEOBJECT_H
#define SHOOTABLEOBJECT_H

#include "flyingObject.h"
#include "constants.h"


class ShootableObject : public FlyingObject
{
  protected:
   int health;
   int reward;
   bool tough;
   
  public:

   ShootableObject();
   ShootableObject(int);

   int getHealth() { return health; }
   int getReward() { return reward; }
   bool getTough() { return tough; }
   

   void addToHealth(int nHealth) { health += nHealth; }
   void setReward(int nReward) { reward = nReward; }
   void setHealth(int nHealth) { health = nHealth; }
   void setTough(bool nTough) { tough = nTough; }

   float setTrajectory(int level);


   void setBird();

   bool isTough();
   virtual void draw();
   
};


/**********************************************************************
 *  Class TOUGHBIRD
**********************************************************************/
class ToughBird : public ShootableObject
{
  private:


  public:

   ToughBird() : ShootableObject()
   {
      setReward(1);
      setHealth(3);
      tough = true;
   }

   

   void draw();
   
};



/**********************************************************************
 *  CLASS SACREDBIRD
**********************************************************************/
class SacredBird : public ShootableObject
{
  private:

  public:

   SacredBird() : ShootableObject()
   {
      setReward(-10);
      setHealth(1);
   }

   void draw();
};



/**********************************************************************
 *  CLASS NORMALBIRD
**********************************************************************/
class NormalBird : public ShootableObject
{
  private:


  public:

   NormalBird() : ShootableObject()
   {
      setReward(1);
      setHealth(1);
   }

   void draw();
};

/**********************************************************************
*  CLASS SMALLASTROID
**********************************************************************/
class SmallAsteroid : public ShootableObject
{
private:

public:

	SmallAsteroid() : ShootableObject(1)
	{
		setHealth(1);
	}

	void draw();
};

/**********************************************************************
*  CLASS MEDIUMASTROID
**********************************************************************/
class MediumAsteroid : public ShootableObject
{
private:
	

public:

	MediumAsteroid() : ShootableObject(1)
	{
		setHealth(2);
	}

	void draw();



};

/**********************************************************************
*  CLASS LARGEASTROID
**********************************************************************/
class LargeAsteroid : public ShootableObject
{
private:

public:

	LargeAsteroid() : ShootableObject(1)
	{
		setHealth(3);
	}

	void draw();

};

#endif
