/***********************************************************************
* Header File:
*    LANDER : A class representing the lunar lander
* Author:
*    Conner Charles
* Summary:
*    The lander has fuel and its' velocity it will be able to move via
*	 thrust from flames left, right, and on the bottom. 
************************************************************************/

#ifndef LANDER_H
#define LANDER_H

#include "flyingobject.h"

/**************************************
* Lander Class
* The ship that the user will fly around
***************************************/
class Lander : public FlyingObject
{
private:
	int fuel;
	bool landed;

	// For fuel cosumption
	const static int CONSUMESIDES;
	const static int CONSUMEBOTTOM;

	void consumeFuel(int amount);

	// Gameplay numbers to eliminate magic numbers
	const static float SPACEGRAVITY;

	const static float MOVE_LEFT;
	const static float MOVE_RIGHT;
	const static float MOVE_UP;

public:
	// Constructors
	Lander();
	Lander(Point startingPoint);

	// Getters
	int getFuel() const { return fuel; }
	bool hasLanded() const { return landed; }

	// Setters
	void setFuel(int fuel) { this->fuel = fuel; }
	void setLanded(bool landed) { this->landed = landed; }

	// Lander's movement-dealing methods
	bool canThrust(bool bottom) const;
	void applyGravity(float gravity);
	void applyThrustLeft();
	void applyThrustRight();
	void applyThrustBottom();

	// Lander's gameplay methods
	void advance();
	void resetLander();
	void draw();

};

#endif // Lander file