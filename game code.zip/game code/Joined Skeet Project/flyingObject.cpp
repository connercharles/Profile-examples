/***********************************************************************
 * Source File:
 *    Move 
 * Author:
 *    Logan Carpenter
 * Summary:
 *    
 ************************************************************************/

#include <iostream>
#include "flyingObject.h"
#include "constants.h"

// my constants for error checking
const int UPPER_X_LIMIT = 400;
const int LOWER_X_LIMIT = -400;
const int UPPER_Y_LIMIT = 400;
const int LOWER_Y_LIMIT = -400;

/**********************************************************************
 *  
**********************************************************************/
void FlyingObject::advance()
{
   location.addX(velocity.getDx());
   location.addY(velocity.getDy());
  
   
}

/**********************************************************************
*
**********************************************************************/
void FlyingObject::setVelocity(float nDx, float nDy)
{
	velocity.setDx(nDx);
	velocity.setDy(nDy);
}

// Setter for the radius
void FlyingObject::setRadius(int radius)
{
	this->radius = radius;
}

// Checks to see if the object is within the screen bounds
void FlyingObject::collide()
{
	// Basically if the point goes off the screen
	if (location.getX() >= SCREEN_X_MAX // X too far right
		|| location.getX() <= SCREEN_X_MIN // X too far left
		|| location.getY() >= SCREEN_Y_MAX // Y too high
		|| location.getY() <= SCREEN_Y_MIN) // Y too low
	{
		alive = false; // Kill b/c hit something
	}
}