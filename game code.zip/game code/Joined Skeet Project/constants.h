#ifndef CONSTANTS_H
#define CONSTANTS_H

const float SCREEN_X_MIN = -400;
const float SCREEN_X_MAX = 400;
const float SCREEN_Y_MIN = -400;
const float SCREEN_Y_MAX = 400;
const double SCREEN_MAX = 400;
const double SCREEN_MIN = -400;
const int BIRD_RADIUS = 30;
const int HIT_SUBTRACTION = -1;
const int OBJECT_RELEASE_TIME = 160;
const int TOUGH_REWARD = 2;
const float BIRD_SPEED = 5;
const int WINNING_SCORE = 12; // Used to be 1
const int ASTEROID_RELEASE_TIME = 50;
const int ROTATE_SPEED_LEVEL_ONE = 3;
const int ROTATE_SPEED_LEVEL_TWO = 5;
const int LEVEL_TWO_COUNT_DOWN = 500;// Used to be 18? idk how long you want it
const int LEVEL_THREE_COUNT_DOWN = 80;

static int gameLevel = 1;




#endif
