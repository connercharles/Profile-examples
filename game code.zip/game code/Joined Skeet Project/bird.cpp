/***********************************************************************
 * Source File:
 *    Bird
 * Author:
 *    Logan Carpenter
 * Summary:
 *    
 ************************************************************************/

#include <iostream>
#include "bird.h"
#include "uiDraw.h"
#include "constants.h"


/**********************************************************************
 *  
**********************************************************************/
void ShootableObject::draw()
{
   
}

/**********************************************************************
 *  
**********************************************************************/
ShootableObject::ShootableObject()
{
		location.setX(SCREEN_X_MIN);
		velocity.setDx(BIRD_SPEED);
		setHealth(0);
		velocity.setDy(BIRD_SPEED * ShootableObject::setTrajectory(1));
		setAlive(true);
		setTough(false);	
}

/**********************************************************************
*
**********************************************************************/
ShootableObject::ShootableObject(int levelTwoConstructor) 
{
	location.setY(SCREEN_Y_MAX);
	std::cout << "y location during construction: " << location.getY() << std::endl;
	velocity.setDy(-BIRD_SPEED);
	setHealth(1);
	velocity.setDx(BIRD_SPEED * ShootableObject::setTrajectory(2));
	setAlive(true);
}


/**********************************************************************
 *  
**********************************************************************/
float ShootableObject::setTrajectory(int level)
{

   double slope = 0;

   //get random y value       
   double position = 0;

   while (position == 0)
   {
      position = random(SCREEN_MIN, SCREEN_MAX);
   }
   
   //the birds y position to the y
   switch (level)
   {
   case 1:
	   location.setY(position);
	   break;
   case 2:
	   location.setX(position);
	   break;
   default:
	   break;
   }

      //to calculate positive slope
      if (position < 0)
      {
         double maxPosSlope = (-position + SCREEN_MAX);
         double slopeRange = (maxPosSlope / 800.0);
         slope = random(0.0000, slopeRange);
      }
      //to calculate negative slope
      else if (position > 0)
      {
         double maxNegSlope = (-position - SCREEN_MAX);
         double slopeRange = (maxNegSlope / 800.0);
         slope = random(slopeRange, 0.0000);
      }
      
      return slope;
}


 

/**********************************************************************
 *  
**********************************************************************/
void ToughBird::draw()
{
   drawToughBird(Point(location.getX(), location.getY()), BIRD_RADIUS, getHealth());
   advance();
}

/**********************************************************************
 *  
**********************************************************************/
void SacredBird::draw()
{
   drawSacredBird(Point(location.getX(), location.getY()), BIRD_RADIUS);
   advance();
}

/**********************************************************************
 *  
**********************************************************************/
void NormalBird::draw()
{
   drawCircle(Point(location.getX(), location.getY()), BIRD_RADIUS);
   advance();
}

/**********************************************************************
*
**********************************************************************/
void SmallAsteroid::draw()
{
	drawSmallAsteroid(Point(location.getX(), location.getY()), 5);
	
	advance();
}

/**********************************************************************
*
**********************************************************************/
void MediumAsteroid::draw()
{
	drawMediumAsteroid(Point(location.getX(), location.getY()), 5);
	advance();
}

/**********************************************************************
*
**********************************************************************/
void LargeAsteroid::draw()
{
	drawLargeAsteroid(Point(location.getX(), location.getY()), 5);
	advance();
}
