#include "asteroid.h"

const int UPPER_SCREEN_BOUND = 400;
const int LOWER_SCREEN_BOUND = -400;

// Good radi??
const int SMALLRADIUS = 10;
const int MEDIUMRADIUS = 20;
const int LARGERADIUS = 30;

Asteroid::Asteroid()
{
	setAlive(true);

	fall();
	
	size = random(1, 3);

	switch (size)
	{
	case 1:
		setRadius(SMALLRADIUS);
		break;
	case 2:
		setRadius(MEDIUMRADIUS);
		break;
	case 3: 
		setRadius(LARGERADIUS);
		break;
	default:
		setRadius(0);
		break;
	}
}

Asteroid::~Asteroid()
{
}

void Asteroid::setSize(int size)
{
	this->size = size;
}

void Asteroid::draw()
{
	switch (size)
	{
	// Small asteroid
	case 1:
		drawSmallAsteroid(getLocation(), 100);
		break;
	// Medium asteroid
	case 2:
		drawMediumAsteroid(getLocation(), 100);
		break;
	// Large asteroid
	case 3:
		drawLargeAsteroid(getLocation(), 100);
		break;
	default:
		break;
	}
}

void Asteroid::fall()
{
	int startPositionX = random(LOWER_SCREEN_BOUND, UPPER_SCREEN_BOUND);

	Point startPosition(startPositionX, UPPER_SCREEN_BOUND);

	Velocity tempVel(0, -2);

	if (startPositionX < 0)
	{
		tempVel.setDx(random(-1, 3));
		tempVel.setDy(random(-6, -3));
	}
	else
	{
		tempVel.setDx(random(-3, 1));
		tempVel.setDy(random(-6, -3));
	}

	setVelocity(tempVel.getDx(), tempVel.getDy());
	setLocation(startPosition);
}