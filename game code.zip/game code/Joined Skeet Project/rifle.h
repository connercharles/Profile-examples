/***********************************************************************
 * Source File:
 *    Rifle 
 * Author:
 *    Logan Carpenter
 * Summary:
 *    
 ************************************************************************/

#ifndef RIFLE_H
#define RIFLE_H

#include <iostream>
#include "point.h"
#include "bullet.h"


/**********************************************************************
 *  
**********************************************************************/
class Rifle
{
  private:
   Point location;
   float angle;
   Bullet bullet;

  public:

  Rifle() : angle(45) {}

   //void getBullet() { return bullet; }
   //void getLocation() { return location; }
   float getAngle() {return angle; }

   Bullet setBullet(Bullet nBullet) { bullet = nBullet; }
   Point setLocation(Point nLocation) { location = nLocation; }  
   void setAngle(float nAngle) { angle = nAngle; }
   void addAngle(float nAngle) { angle += nAngle; }
 
   
   void levelOneRotateUp();
   void levelOneRotateDown();

   void levelTwoRotateLeft();
   void levelTwoRotateRight();
   
   void fire(Bullet bullet);
   
   
   void draw();

   void drawMiddle();
   


};

#endif
