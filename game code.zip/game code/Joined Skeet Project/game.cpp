/****************************************
 * The game of Skeet
 ****************************************/

// I tried to put comments on all the things I added that were in obscure places like
// adding variables to flyingobjects or other things like that
// - Conner

#include <vector>

#include "uiDraw.h"
#include "uiInteract.h"
#include "point.h"
#include "rifle.h"
#include "flyingObject.h"
#include "velocity.h"
#include "bird.h"
#include "constants.h"
#include "lander.h"
#include "asteroid.h"
#include "ground.h"

using std::vector;

/*****************************************
 * GAME
 * The main game class containing all the state
 *****************************************/
class Game
{
public:
   
   // create the game
   Game(Point tl, Point br) : topLeft(tl), bottomRight(br), time(0), 
	   bullets(), score(0), death(false), gameoverTime(0), play(false),
	   levelTwoCountDown(LEVEL_TWO_COUNT_DOWN), level3timer(LEVEL_THREE_COUNT_DOWN),
	   storyLanderY(SCREEN_Y_MIN), startingPointLevel3(0, -150), lander(startingPointLevel3),
	   ground(Ground(topLeft, bottomRight))
   {
      bird = new ShootableObject;
   }

   ~Game()
   {
      delete[] &bullets;
      delete bird;
	  
	  for (std::vector<ShootableObject*>::iterator it = asteroid.begin(); it != asteroid.end(); it++)
	  {
		  delete *it;
		  it = asteroid.erase(it);
	  }
   }

   // handle user input
   void handleInputOne(const Interface & ui);
   void handleInputTwo(const Interface & ui);
   void handleInputThree(const Interface & ui);
   void handleInputFour(const Interface & ui);
   void handleInput(const Interface & ui);

   // advance the game
   void advance();

   // draw stuff
   void drawGameOne(const Interface & ui);
   void drawGameTwo(const Interface & ui);
   void drawGameThree(const Interface & ui);
   void drawGameFour(const Interface & ui);
   void draw(const Interface & ui);

   //tells the epic story
   void preStoryLevelOne();
   void preStoryLevelTwo();
   void preStoryLevelThree();
   void preStoryLevelFour();

   //tells the sad tell
   void gameoverStoryLevelTwo();
   void gameoverStoryLevelThree();

   //check for collision
   double collisionCheck(Point object1, Point object2);

   //cleans the vector of asteroids
   void cleanAsteroidVector();
   void cleanBulletVector();

   // We don't really need getters or setters but why not have them
   int getScore() { return score; }
   bool getDeath() { return death;  }

   void setDeath(bool nDeath) { death = nDeath;  }
   
private:
   Point topLeft;
   Point bottomRight;
   Rifle rifle;
   
   int time;
   int gameoverTime;
   int storyTime;
   int levelTwoCountDown;
   int score;
   float storyLanderY;
   bool play;
   bool death; //set death = false everytime there's a skip
   bool replay;


   // For level three
   Point startingPointLevel3;
   Lander lander;
   Lander storyLander;

   //Ground ground;

   // Vector of Astroids
   vector<Asteroid*> asteroids;

   int level3timer;

   vector <Bullet> bullets;

   // We should probably combine the vector of asteroids you have and the one I have...
   vector <ShootableObject*> asteroid;
  
   ShootableObject* bird;   
   SmallAsteroid* smallAsteroid;
   MediumAsteroid* mediumAsteroid;
   LargeAsteroid* largeAsteroid;
   Asteroid* newAsteroid;

   // Lunar Lander variables
   bool justLanded() const;

   Ground ground;

};

/******************************************
* GAME :: LANDED
* Did we land successfully?
******************************************/
bool Game::justLanded() const
{
	int platWidth = ground.getPlatformWidth() / 2;
	// So it is from the center to either end ^^

	Point landerCenter = lander.getLocation();
	Point platCenter = ground.getPlatformPosition();
	Velocity landerVelocity = lander.getVelocity();

	if (landerCenter.getY() - platCenter.getY() <= 4 // Not too high
		&& landerCenter.getY() - platCenter.getY() >= 0 // Not too low
		&& landerCenter.getX() < (platCenter.getX() + platWidth) // Not too far right
		&& landerCenter.getX() > (platCenter.getX() - platWidth) // Not too far left
		&& landerVelocity.getDx() <= 3 // Not coming in too fast
		&& landerVelocity.getDy() <= 3)
	{
		return true;
	}
	return false;
}

/**********************************************************************
*  Cleans the Asteroid Vector
**********************************************************************/
void Game::cleanAsteroidVector()
{
	std::vector<Asteroid*>::iterator it = asteroids.begin();

	// checks to see if the asteroid is alive, 
	// if not it deletes from the vector
	while (it != asteroids.end())
	{
		if (!(*it)->isAlive())
		{
			it = asteroids.erase(it);
		}
		else
		{
			it++;
		}
	}
}

/**********************************************************************
*  Cleans the Bullet Vector
**********************************************************************/
void Game::cleanBulletVector()
{
	//so the bullet can get deleted eventually
	std::vector<Bullet>::iterator itBullet = bullets.begin();

	while (itBullet != bullets.end())
	{      //checks if the bullet is alive
		if (!itBullet->isAlive())
		{  //gets rid of the bullet if it's dead
			itBullet = bullets.erase(itBullet);
		}
		else
			itBullet++; //moving on to the next bullet
	}

}

/**********************************************************************
 *  collision
**********************************************************************/
double Game::collisionCheck(Point object1, Point object2)
{
   double distance =
      sqrt(pow(object1.getX() - object2.getX(), 2) +
           pow(object1.getY() - object2.getY(), 2));

   return distance;
}

/***************************************
* GAME :: STORY
* 
***************************************/
void Game::preStoryLevelOne()
{
	drawText(Point(-200, 200), "Ah, it's nice to be in the great out doors.");
	drawText(Point(-180, 185), "Alright let's shoot some birds.");
	drawText(Point(bird->getLocation().getX() - BIRD_RADIUS - 20, bird->getLocation().getY() - BIRD_RADIUS - 20), "Shoot me, I dare you.");
	
	// Menu-like settings
	drawText(Point(-170, 100), "For Tough birds you can get 5 points");
	drawToughBird(Point(80, 100),20,3);

	drawText(Point(-170, 0), "For Normal birds you get a 1 point");
	drawCircle(Point(80, 0), 20);
	
	drawText(Point(-170, -100), "For Sacred birds you get -10 points");
	drawSacredBird(Point(80, -100), 20);

	drawText(Point(-170, -200), "They're waiting for you.");
	drawText(Point(-170, -215), "Press space bar to play");
}

/***************************************
* GAME :: STORY
*
***************************************/
void Game::preStoryLevelTwo()
{
	drawText(Point(-200, 200), "Wow nice shooting Tex!");

	storyTime++;

	if (storyTime > 30 && storyTime < 1400)
	{
		drawText(Point(-250, 185), "It's too bad you're not able to use your sick skills more often...");

		if (storyTime > 120)
		{
			drawText(Point(-200, 160), "Wait a second..");

			if (storyTime > 150)
			{
				drawText(Point(-200, 145), "What are those?!");

				if (storyTime > 190)
				{
					drawText(Point(-240, 130), "Asteroids raining from the sky!?!");

					if (storyTime > 230 )
					{
						drawText(Point(-200, 100), "New mission!");
						drawText(Point(-200, 85), "Protect planet earth for 60 seconds.");

						drawText(Point(-200, 0), "Small asteroids take one hit to kill");
						drawSmallAsteroid(Point(80, 10), 5);

						drawText(Point(-200, -100), "Medium asteroids take two hits to kill");
						drawMediumAsteroid(Point(80, -90), 5);

						drawText(Point(-200, -200), "Large asteroids take three hits to kill");
						drawLargeAsteroid(Point(80, -190), 5);

						
						drawText(Point(-200, -250), "Press r to start shooting asteroids.");
						
					}
				}
			}
		}
	}	
}

/***************************************
* GAME :: STORY
*
***************************************/
void Game::preStoryLevelThree()
{
	storyTime++;

	if (storyTime > 50)
	{
		drawText(Point(-25, 375), "That appears to be the last of them..For now");

		if (storyTime > 100)
		{
			drawText(Point(-25, 360), "I knew this time would come..");


			if (storyTime > 170)
			{
				drawText(Point(-25, 300), "It's time to go hide and eat the food I've stored away..");

				if (storyTime > 230)
				{
					drawText(Point(-25, 285), "On the moon that is.");

					if (storyTime > 290)
					{
						drawText(Point(-25, 270), "I don't think I'll ever regret buying this moon lander.");

						if (storyTime > 310)
						{
							storyLander.setLocation(-200, -400);
							drawLander(Point(-200, storyLanderY));
							drawLanderFlames(Point(-200, storyLanderY), true, false, false);
							

							if (storyTime > 360)
							{
								storyLanderY += 4;
								drawText(Point(-25, 230), "Radar says there are more incoming asteriods...");

								if (storyTime > 410)
								{
									drawText(Point(-25, 215), "This is going to be a bumpy ride...");

									if (storyTime > 600)
									{
										gameLevel = 3;
										storyTime = 0;
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

/***************************************
* GAME :: STORY
*
***************************************/
void Game::preStoryLevelFour()
{
	storyTime++;

	if (storyTime > 50)
	{
		drawText(Point(-25, 375), "Looks like the asteroids are clearing up..");

		if (storyTime > 100)
		{
			drawText(Point(-25, 360), "You've made it to the moon!");


			if (storyTime > 170)
			{
				drawText(Point(-25, 300), "But wait...");

				if (storyTime > 230)
				{
					drawText(Point(-25, 285), "It appears your auto pilot landing was damaged during the flight.");

					if (storyTime > 290)
					{
						drawText(Point(-25, 270), "You're guna have to do this manually..");

						if (storyTime > 310)
						{
							drawText(Point(-25, 255), "Dun Dun DUUUUUUUUN!!!");

							if (storyTime > 500)
							{
								gameLevel = 4;
								storyTime = 0;
								// Makes the lander ready for level 4
								lander.resetLander();
							}
						}
					}
				}
			}
		}
	}
}

/***************************************
* GAME :: GAMEOVER STORY LEVEL TWO
*
***************************************/
void Game::gameoverStoryLevelTwo()
{
	gameoverTime++;

	if (gameoverTime > 1)
	{
		drawText(Point(-200, 200), "Come on!");

		if (gameoverTime > 60)
		{
			drawText(Point(-200, 185), "You had one job! -  Protect the planet");
		
			if (gameoverTime > 180)
			{
				drawText(Point(-200, 170), "I can't even look you in the face right now.");
			
				if (gameoverTime > 300)
				{
					drawText(Point(-200, 155), "And that's not because I'm an inanimate computer.");
				
					if (gameoverTime > 480)
					{
						drawText(Point(-200, 140), "It's beacsue I'm disgusted.");
					
						if (gameoverTime > 700)
						{
							drawText(Point(-200, 115), "Press r to replay.");
						}
					}
				}
			}
		}		
	}
}

/***************************************
* GAME :: GAMEOVER STORY LEVEL THREE
*
***************************************/
void Game::gameoverStoryLevelThree()
{
	drawLanderFlames(lander.getLocation(), true, true, true);
	 
	drawText(Point(-200, 200), "Oh boy the Asteroid punctured the gas tank!");
	drawText(Point(-200, 185), "I hope you payed your tithing before you left");
	drawText(Point(-200, 170), "because I don't think you're guna make it back");

	drawText(Point(-200, 150), "press space bar to restart.");
}

/***************************************
 * GAME :: ADVANCE
 * advance the game one unit of time
 ***************************************/
void Game :: advance()
{
   // TODO: move lander and check for crashed

	if (gameLevel == 1 || gameLevel == 2)
	{
		// I put that bullet stuff into a seperate method :)
		cleanBulletVector();

		for (int i = 0; i < bullets.size(); i++)
		{
			bullets[i].advance();
			// crashing

			//I gave you a collide method in the flyingobjects that will take this away
			// out of screen
			if (bullets[i].getLocation().getX() < SCREEN_X_MIN ||
				bullets[i].getLocation().getY() > SCREEN_Y_MAX)
			{
				bullets[i].setAlive(false);
			}
		}

		if (!death)
		{
			time++;
		}

		if (score > WINNING_SCORE && gameLevel == 1)
		{
			gameLevel = 2;
			score = 0;
			time = 0;
			play = false;
		}

		//condition for beating level two
		if (levelTwoCountDown == 0)
		{
			//gameLevel = 3;
			preStoryLevelThree();
			play = false;
			time = 0;
		}
	}

   //conditions for beating level three
   if (gameLevel == 3 && play)
   {
	
		   lander.advance();

		   for (unsigned int i = 0; i < asteroids.size(); i++)
		   {
			   asteroids[i]->advance();
			   int distance = collisionCheck(lander.getLocation(), asteroids[i]->getLocation());

			   if (distance <= asteroids[i]->getRadius())
			   {
				   asteroids[i]->setAlive(false);
				   lander.setAlive(false);
			   }//if
		   }//for


		   if ((level3timer % 5 == 0) && (level3timer > 0))
		   {
			   newAsteroid = new Asteroid;
			   asteroids.push_back(newAsteroid);
		   }//if

		   cleanAsteroidVector();

		   if (lander.isAlive() && (level3timer > 0))
		   {
			   if (level3timer % 5 == 0)
			   {
				   newAsteroid = new Asteroid;
				   asteroids.push_back(newAsteroid);
			   }//if


			   level3timer--;
		   }

		   cleanAsteroidVector();

	  
	   
		   if (level3timer == 0)
		   {
			   preStoryLevelFour();
		   }
	   // Stops game if you die
		   if (!lander.isAlive())
		   {
			   gameoverStoryLevelThree();
		   }
   }// if it's level 3

   // If it's level 4
   if (gameLevel == 4 && play)
   {
	   Point text(220, 375);
	   Point otherText(-220, 300);

	   // If you crashed
	   if (ground.crashed(lander.getLocation()))
	   {
		   lander.setAlive(false);
		   drawText(text, "You died in a fiery explosion.");
		   drawText(otherText, "Press Space to start over.");
		   drawLanderFlames(lander.getLocation(), true, true, true);
	   }
	   // If you are alive and haven't landed
	   else if (lander.isAlive() && !justLanded())
	   {
		   lander.advance();
	   }
	   // If you win
	   else if (justLanded())
	   {
		   drawText(text, "You landed!");
		   drawText(otherText, "To be continued...");
		   lander.setLanded(true);
	   }
   }
}


/***************************************
* GAME :: HANDLE INPUT ONE
* advance the game one unit of time
***************************************/
void Game::handleInputOne(const Interface & ui)
{
	if (play)
	{
		if (ui.isLeft()) //to move right
		{
			rifle.levelOneRotateDown();
		} // if

		if (ui.isRight()) //to move left
		{
			rifle.levelOneRotateUp();
		} // if

		if (ui.isSpace())
		{
			Bullet temp(rifle.getAngle(), gameLevel);
			bullets.push_back(temp);
		}
	}
	else
	{
		if (ui.isSpace())
		{
			play = true;
			time = 0;
			storyTime = 0;
		}
	}

	if (ui.isN())
	{
		gameLevel++;
	}
}


/***************************************
* GAME :: HANDLE INPUT TWO
* advance the game one unit of time
***************************************/
void Game::handleInputTwo(const Interface & ui)
{
	if (!death && play)
	{
		if (ui.isLeft()) //to move right
		{
			rifle.levelTwoRotateLeft();
		} // if

		if (ui.isRight()) //to move left
		{
			rifle.levelTwoRotateRight();
		} // if

		if (ui.isSpace())
		{
			Bullet temp(rifle.getAngle(), gameLevel);
			bullets.push_back(temp);
		}
	}
	else if (!replay)
	{
		if (ui.isR()) //CONNER  try changing to listen for 'r' because then when
			//you're playing and furiously pressing the space bar to try and stay alive 
			//you don't accidentally skip the funny message that comes with death
		{
			play = true;
			time = 0;
			storyTime = 0;
			gameoverTime = 0;
			levelTwoCountDown = LEVEL_TWO_COUNT_DOWN;
			setDeath(false);
			replay = true;			

			//get rid of the asteroids that caused the gameover
			std::vector<ShootableObject*>::iterator itAsteroid = asteroid.begin();
			while (itAsteroid != asteroid.end())
			{
				delete *itAsteroid;
				itAsteroid = asteroid.erase(itAsteroid);
			}//while
		}// if
	}// else if 

	if (ui.isN())
	{
		gameLevel++;
		time = 0;
		storyTime = 0;
		gameoverTime = 0;
	}
}


/***************************************
* GAME :: HANDLE INPUT THREE
* advance the game one unit of time
***************************************/
void Game::handleInputThree(const Interface & ui)
{
	//Conner paste your code in here   :)

	if (lander.isAlive())
	{
		if (ui.isLeft())
		{
			lander.applyThrustLeft();
		}
		if (ui.isRight())
		{
			lander.applyThrustRight();
		}
		if (ui.isDown())
		{
			lander.applyThrustBottom();
		}
	}
	if (ui.isSpace())
	{
		play = true;
		level3timer = LEVEL_THREE_COUNT_DOWN;
		lander.setLocation(0.0, 0.0);
		lander.setVelocity(0.0, 0.0);
		lander.setAlive(true);

		//get rid of the asteroids that caused the gameover
		std::vector<Asteroid*>::iterator itAsteroid = asteroids.begin();
		while (itAsteroid != asteroids.end())
		{
			delete *itAsteroid;
			itAsteroid = asteroids.erase(itAsteroid);
		}//while
	}
	// I added the is N method to the uiInteract
	if (ui.isN())
	{
		gameLevel++;
		lander.resetLander();
	}
}

/***************************************
* GAME :: HANDLE INPUT FOUR
* advance the game one unit of time
***************************************/
void Game::handleInputFour(const Interface & ui)
{
	if (ui.isLeft())
	{
		lander.applyThrustLeft();
	}
	if (ui.isRight())
	{
		lander.applyThrustRight();
	}
	if (ui.isDown())
	{
		lander.applyThrustBottom();
	}
	// Allows you to press space if you died to restart that level
	if (ui.isSpace() && !lander.isAlive())
	{
		lander.setAlive(true);

		ground.generateGround();
		lander.resetLander();
	}
}

/***************************************
 * GAME :: HANDLE INPUT
 * accept input from the user
 ***************************************/
void Game :: handleInput(const Interface & ui)
{
	switch (gameLevel)
	{
	case 1:
		handleInputOne(ui);
		break;
	case 2:
		handleInputTwo(ui);
		break;
	case 3:
		handleInputThree(ui);
		break;
	case 4:
		handleInputFour(ui);
		break;
	default:
		break;
	}
}


/********************************************
* GAME :: DRAW GAME ONE
*	
*********************************************/
void Game::drawGameOne(const Interface & ui)
{
	rifle.draw();

	if (!play)
	{
		preStoryLevelOne();
	}

	for (int i = 0; i < bullets.size(); i++)
	{
		bullets[i].draw();
	}//for

	drawNumber(Point(SCREEN_X_MIN + 5, SCREEN_Y_MAX - 5), score);

	if (time % OBJECT_RELEASE_TIME == 0)
	{
		delete bird; //makes way for the new bird

		switch (random(1, 10) % 3)
		{
		case 0:
			bird = new ToughBird;
			break;
		case 1:
			bird = new SacredBird;
			break;
		case 2:
			bird = new NormalBird;
			break;
		default:
			break;
		}//switch

	

	}//if

	if (bird->isAlive())
	{
		bird->draw();
	}//if


	for (int i = 0; i < bullets.size(); i++)
	{
		double distance = collisionCheck(bird->getLocation(), bullets[i].getLocation());
		if (distance < BIRD_RADIUS && bird->isAlive())
		{
			bird->addToHealth(HIT_SUBTRACTION);
			bullets[i].setAlive(false);
			
			if (gameLevel == 1)
			{
				score += bird->getReward();
			}

			if (bird->getHealth() == 0)
			{
				bird->setAlive(false);

				if (bird->getTough())
				{
					score += TOUGH_REWARD;
				}//if
			}//if
		}//if     
	}//for
}


/*********************************************
* GAME :: DRAW GAME TWO
* Draw everything on the screen
*********************************************/
void Game::drawGameTwo(const Interface & ui)
{
	rifle.drawMiddle();

	if (!play && levelTwoCountDown > 1)
	{
		preStoryLevelTwo();
	}
	else if (play)
	{ 
		drawText(Point(SCREEN_X_MAX - 150, SCREEN_Y_MAX - 15), "Time Remaining:");
		drawNumber(Point(SCREEN_X_MAX - 40, SCREEN_Y_MAX - 15), levelTwoCountDown / 30);
		
		if (!death)
		{
			levelTwoCountDown--;
		}


		for (int i = 0; i < bullets.size(); i++)
		{
			bullets[i].draw();
		}//for


		if (time % ASTEROID_RELEASE_TIME == 0 && !death)
		{
			switch (random(1, 10) % 3)
			{
			case 0:
				smallAsteroid = new SmallAsteroid;
				asteroid.push_back(smallAsteroid);
				break;
			case 1:
				mediumAsteroid = new MediumAsteroid;
				asteroid.push_back(mediumAsteroid);
				break;
			case 2:
				largeAsteroid = new LargeAsteroid;
				asteroid.push_back(largeAsteroid);
				break;
			default:
				break;
			}//switch
		}//if

		std::vector<ShootableObject*>::iterator itAsteroid = asteroid.begin();
		while (itAsteroid != asteroid.end())
		{      //checks if the bullet is alive
			if (!(*itAsteroid)->isAlive())
			{  //gets rid of the bullet if it's dead
				itAsteroid = asteroid.erase(itAsteroid);
			}//if
			else
			{
				(*itAsteroid)->draw();
				itAsteroid++; //moving on to the next bullet
			}//else
		}//while


		for (int i = 0; i < asteroid.size(); i++)
		{
			if (asteroid[i]->getLocation().getY() < SCREEN_Y_MIN)
			{
				setDeath(true);
				asteroid[i]->setVelocity(0, 0);
				//asteroid[i]->setAlive(false);
				drawExplosion(Point(asteroid[i]->getLocation().getX(), SCREEN_Y_MIN), 40);
				gameoverStoryLevelTwo();
				replay = false;
			}//if
		}//for



		for (int i = 0; i < bullets.size(); i++)
		{
			for (int j = 0; j < asteroid.size(); j++)
			{
				double distance = collisionCheck(asteroid[j]->getLocation(), bullets[i].getLocation());
				if (distance < BIRD_RADIUS && asteroid[j]->isAlive())
				{
					asteroid[j]->addToHealth(HIT_SUBTRACTION);
					bullets[i].setAlive(false);
					score += asteroid[j]->getReward();

					if (asteroid[j]->getHealth() == 0)
					{
						asteroid[j]->setAlive(false);
					}//if
				}//if 
			}//for  int = j
		}//for  int = i
	}//else if (play)
}

/*********************************************
* GAME :: DRAW GAME THREE
* Draw everything on the screen
*********************************************/
void Game::drawGameThree(const Interface & ui)
{
	//Conner paste your code in here   :)
	lander.draw();

	if (play)
	{
		Point text(220, 375);

		// If you win
		if (level3timer > 0)
		{
			// draws the time left
			drawNumber(Point(-390, 390), level3timer);
		}

		// draws asteroids
		for (unsigned int i = 0; i < asteroids.size(); i++)
		{
			asteroids[i]->draw();
		}
	}
	else
	{
		drawText(Point(-50, 0), "Press space to start");
	}
}


/*********************************************
* GAME :: DRAW GAME FOUR
* Draw everything on the screen
*********************************************/
void Game::drawGameFour(const Interface & ui)
{
	//ground.generateGround();
	lander.draw();

	// TODO: draw the fuel
	Point tlFuel(-390, 390);
	drawNumber(tlFuel, lander.getFuel());

	// draw ground
	ground.draw();
}


/*********************************************
 * GAME :: DRAW
 * Draw everything on the screen
 *********************************************/
void Game :: draw(const Interface & ui)
{

	switch(gameLevel)
	{
	case 1:
		drawGameOne(ui);
		break;
	case 2:
		drawGameTwo(ui);
		break; 
	case 3:
		drawGameThree(ui);
		break;
	case 4:
		drawGameFour(ui);
		break;
	default:
		break;
		
	}   
}//function


/*************************************
 * All the interesting work happens here, when
 * I get called back from OpenGL to draw a frame.
 * When I am finished drawing, then the graphics
 * engine will wait until the proper amount of
 * time has passed and put the drawing on the screen.
 **************************************/
void callBack(const Interface *pUI, void *p)
{
   Game *pGame = (Game *)p;
   
   pGame->advance();
   pGame->handleInput(*pUI);
   pGame->draw(*pUI);
}




/*********************************
 * Main is pretty sparse.  Just initialize
 * the game and call the display engine.
 * That is all!
 *********************************/
int main(int argc, char ** argv)
{
   Point topLeft(SCREEN_X_MIN, SCREEN_Y_MAX);//SCREEN_X_MIN, SCREEN_Y_MAX);
   Point bottomRight(SCREEN_X_MAX, SCREEN_Y_MIN);//SCREEN_X_MAX, SCREEN_Y_MIN);
  
   Interface ui(argc, argv, "Skeet", topLeft, bottomRight);
   Game game(topLeft, bottomRight);
   ui.run(callBack, &game);
  

   
   
   return 0;
}
