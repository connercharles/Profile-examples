/***********************************************************************
* Source File:
*    Lander : The representation of the lander on the screen
* Author:
*    Conner Charles
* Summary:
*    This is the lander.cpp file where all the lander's methods are called
*	 The lander is able to thrust fire left, right, and down. It checks to 
*	 make sure the lander has enough fuel, advances the lander, and draws
*	 it.
************************************************************************/

#include "Lander.h"
#include "uiDraw.h"

// For lunar lander
const int Lander::CONSUMESIDES = 1;
const int Lander::CONSUMEBOTTOM = 3;

// Each level's gravity
const float Lander::SPACEGRAVITY = -.1;

// Normal velocity
const float Lander::MOVE_LEFT = .1;
const float Lander::MOVE_RIGHT = -.1;
const float Lander::MOVE_UP = .3;

const int LANDERRADIUS = 10;

/******************************************
* LANDER : Consume Fuel
* Takes passed in amount and subtracts from fuel amount.
* Then sets the new amount as the new fuel amount.
*****************************************/
void Lander::consumeFuel(int amount)
{
	setFuel(fuel - amount);
}

/******************************************
* LANDER : Reset Lander
* Resets the lander variables to ready it
* for the next level.
*****************************************/
void Lander::resetLander()
{
	Point newPoint(380, 380);
	setLocation(newPoint);
	setFuel(500);
	setVelocity(0, 0);
}

/******************************************
* LANDER : CONSTRUCTOR
* Sets the default values of lander variables.
*****************************************/
Lander::Lander()
{
	setAlive(true);
	setLocation(Point(180, 180));
	setFuel(500);
	setRadius(LANDERRADIUS);
}

/******************************************
* LANDER : CONSTRUCTOR FOR LEVEL 3
* Sets the default values of lander variables.
*****************************************/
Lander::Lander(Point startingPoint)
{
	setAlive(true);
	setLocation(startingPoint);
	setFuel(50000);
	setRadius(LANDERRADIUS);
}

/******************************************
* LANDER : Can Thrust
* Checks lander fuel to see if it is possible to thrust.
*****************************************/
bool Lander::canThrust(bool isBottom) const
{
	// Will need to change it is the bottom thruster
	if (isBottom)
	{
		if (getFuel() >= 3) // 3 b/c thrusting bottom decreases by 3
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else if (getFuel() > 0) // If you are out of fuel
	{
		return true;
	}
	else
	{
		return false;
	}
}

/******************************************
* LANDER : Apply Gravity
* Applies passed in value of gravity to Lander.
* Should be a negative number!
*****************************************/
void Lander::applyGravity(float gravity)
{
	Velocity tempVel = getVelocity();
	tempVel.addOntoDy(gravity);
	setVelocity(tempVel.getDx(), tempVel.getDy());
}

/******************************************
* LANDER : Apply Thrust Left
* Shoots fire on the left side and pushes the 
* lander's inertia to the right.
*****************************************/
void Lander::applyThrustLeft()
{
	if (canThrust(false))
	{
		Velocity tempVel = getVelocity();
		tempVel.addOntoDx(MOVE_LEFT);
		drawLanderFlames(getLocation(), false, true, false);
		setVelocity(tempVel.getDx(), tempVel.getDy());
		consumeFuel(CONSUMESIDES);
	}	
}

/******************************************
* LANDER : Apply Thrust Right
* Shoots fire on the right side and pushes the
* lander's inertia to the left.
*****************************************/
void Lander::applyThrustRight()
{
	if (canThrust(false))
	{
		Velocity tempVel = getVelocity();
		tempVel.addOntoDx(MOVE_RIGHT);
		drawLanderFlames(getLocation(), false, false, true);
		setVelocity(tempVel.getDx(), tempVel.getDy());
		consumeFuel(CONSUMESIDES);
	}
}

/******************************************
* LANDER : Apply Thrust Bottom
* Shoots fire on the botton and pushes the 
* lander's inertia up.
*****************************************/
void Lander::applyThrustBottom()
{
	if (canThrust(true))
	{
		Velocity tempVel = getVelocity();
		tempVel.addOntoDy(MOVE_UP);
		drawLanderFlames(getLocation(), true, false, false);
		setVelocity(tempVel.getDx(), tempVel.getDy());
		consumeFuel(CONSUMEBOTTOM);
	}
}

/******************************************
* LANDER : Advance
* Checkes to see what level the user is on
* then it calls on the movement of the lander
* and the gravity that applies to the level.
*****************************************/
void Lander::advance()
{
	Point tempPos = getLocation();

	applyGravity(SPACEGRAVITY); // B/c we're flying through earth's atmosphere.
	tempPos.addX(velocity.getDx());
	tempPos.addY(velocity.getDy());

	setLocation(tempPos);

	collide();
}

/******************************************
* LANDER : Draw
* Draws the lander using its' center point.
*****************************************/
void Lander::draw()
{
	drawLander(getLocation());
}