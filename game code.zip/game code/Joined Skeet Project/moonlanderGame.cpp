///****************************************
//* The game of moonlander
//****************************************/
//
//#include <unistd.h>
//#include <ctime>            // for ::Sleep();
////#include <cstdl:b>
//
////#include "game.cpp"
//
//#define FUEL        500    // initial fuel for the game
//#define MIN_SPEED   3.0    // minimal landing speed
//#define FALL_HEIGHT 4.0    // greatest height we can fall from
//#define ABS(value)((value > 0) ? value : value *-1)
//#define SEC_TO_WAIT    1
//
//// set the bounds of the drawing rectangle
//#define X_SIZE       400
//float Point::xMin = -(X_SIZE / 2.0);
//float Point::xMax = (X_SIZE / 2.0);
//float Point::yMin = -200.0;
//float Point::yMax = 200.0;
//float Lander::GRAVITY = -.1;
//float Lander::STARTING_X = 100;
//float Lander::STARTING_Y = 150;
//float Lander::STARTING_FUEL = 500;
//float Ground::MAX_SPEED_TO_LAND = 3;
//float Ground::HEIGHT_ALOUD_ABOVE_PLATFORM = 4;
//float Velocity::STARTING_DX = 0;
//float Velocity::STARTING_DY = 0;
//
//
///*****************************************
//* GAME
//* The main game class containing all the state
//*****************************************/
//class Game
//{
//public:
//	// create the game
//	Game() : dead(false), landed(false), fuel(FUEL), waiting(900) {}
//
//	// handle user input
//	void handleInput(const Interface & ui);
//
//	// advance the game
//	void advance();
//
//	// draw stuff
//	void draw(const Interface & ui);
//
//	// tells a sad story
//	void crashStory();
//
//private:
//	bool justLanded();
//
//	int  fuel;
//	bool dead;
//	bool landed;
//	Ground ground;
//	Lander lander;
//	int waiting;  //so the death message can be put out at the right time
//
//				  // TODO: add any objects or variables that are required
//};
//
///******************************************
//* GAME :: LANDED
//* Did we land successfully?
//******************************************/
//bool Game::justLanded()
//{
//	Point landerPosition = lander.getPoint();
//	Point platformCenter = ground.getPlatformPosition();
//	int platformWidth = (ground.getPlatformWidth() / 2);
//
//	//lander's x is grater than the left side of the platform
//	if (landerPosition.getX() >= (platformCenter.getX() - platformWidth)
//		//lander's x is less than the left side of the platform
//		&& landerPosition.getX() <= (platformCenter.getX() + platformWidth)
//		// lander's y is within 4 pixels of the top of the platform
//		&& (landerPosition.getY()) - (platformCenter.getY()) <= 4
//		&& (landerPosition.getY()) - (platformCenter.getY()) >= -4
//		//lander's x velocity isn't faster than 3 pixels per frame
//		&& lander.getVelocity().getDx() <= 3
//		&& lander.getVelocity().getDx() >= -3
//		//lander's y velocity isn't faster than 3 pixels per frame
//		&& lander.getVelocity().getDy() <= 3
//		&& lander.getVelocity().getDy() >= -3)
//	{
//		drawText(Point(20, 175), "Winner winner chicken dinner!!!");
//		drawText(Point(20, 160), "Press space to play again.");
//		lander.setLanded(true);
//		return true;
//	}
//
//	return false;
//}
//
///**********************************************************************
//*
//**********************************************************************/
//void Game::crashStory()
//{
//	if (waiting < 900 && waiting > 800)
//	{
//		lander.setCrashed(true);
//		drawText(Point(0, 145), "Darn you crashed, but don't worry.");
//	}
//
//	if (waiting < 800 && waiting > 650)
//	{
//		drawText(Point(-100, 135), "I mean, count your blessings. You're still alive right?");
//	}
//
//	if (waiting < 650 && waiting > 550)
//	{
//		drawLanderFlames(lander.getPoint(), true, true, true, true);
//		drawText(Point(0, 115), "Oh shoot a fire broke out!");
//	}
//
//	if (waiting < 550 && waiting > 450)
//	{
//		drawLanderFlames(lander.getPoint(), true, true, true, true);
//		drawText(Point(-80, 115), "Quick! get out before your nuclear core Explodes!");
//	}
//
//	if (waiting < 450 && waiting > 430)
//	{
//		for (int i = 50; i > 1; i--)
//		{
//			drawCircle(lander.getPoint(), i, 1);
//		}
//		drawText(Point(0, 115), "You're screwed.");
//
//		lander.setAlive(false);
//	}
//
//	if (waiting < 440 && waiting > 300)
//	{
//		drawExplosion(lander.getPoint(), 500);
//		//drawToughBird(lander.getPoint(), 500, 1);
//	}
//
//	if (!lander.isAlive() && waiting < 300)
//	{
//		if (waiting > 298)
//			waiting++;
//		drawText(Point(0, 115), "Better luck next time.");
//		drawText(Point(0, 100), "Press space to play again.");
//	}
//
//	waiting--;
//}
//
///***************************************
//* GAME :: ADVANCE
//* advance the game one unit of time
//***************************************/
//void Game::advance()
//{
//	// TODO: move lander and check for crashed
//	if (!justLanded()
//		&& !ground.crashed(lander.getPoint())
//		&& !ground.platformCrash(lander.getPoint(), lander.getVelocity().getDx(), lander.getVelocity().getDy()))
//	{
//		lander.advance();
//	}//if
//	 //if the lander chrashes here's what happens
//	else if (ground.crashed(lander.getPoint()) ||
//		ground.platformCrash(lander.getPoint(),
//			lander.getVelocity().getDx(),
//			lander.getVelocity().getDy()))
//	{
//		crashStory();
//	}
//
//}
//
//
///***************************************
//* GAME :: input
//* accept input from the user
//***************************************/
//void Game::handleInput(const Interface & ui)
//{
//	if (ui.isLeft()) //to move right
//	{
//		lander.applyThrustLeft();
//	} // if
//
//	if (ui.isRight()) //to move left
//	{
//		lander.applyThrustRight();
//	} // if
//
//	if (ui.isDown())  //to move up
//	{
//		lander.applyThrustBottom();
//	} // if
//
//	if (ui.isUp()) //to move down
//	{
//		lander.applyThrustUp();
//	} // if
//
//	  //if space is pressed while crashed into platform and/or ground
//	  //OR you've just landed
//	if (ui.isSpace() &&
//		(lander.hasLanded() || lander.getCrashed()))
//	{
//		lander.newLander();
//		ground.generateGround();
//		ground.draw();
//		waiting = 900;
//	}
//}
//
///*********************************************
//* GAME :: DRAW
//* Draw everything on the screen
//*********************************************/
//void Game::draw(const Interface & ui)
//{
//	if (lander.isAlive())
//	{
//		//draw the fuel        
//		drawNumber(Point(-190, 190), lander.getFuel());
//		//draws the lander on the screen
//		lander.draw();
//		//draws the ground
//		ground.draw();
//	}//if
//}
//
///*************************************
//* All the interesting work happens here, when
//* I get called back from OpenGL to draw a frame.
//* When I am finished drawing, then the graphics
//* engine will wait until the proper amount of
//* time has passed and put the drawing on the screen.
//**************************************/
//void callBack(const Interface *pUI, void *p)
//{
//	Game *pGame = (Game *)p;
//
//	pGame->advance();
//	pGame->handleInput(*pUI);
//	pGame->draw(*pUI);
//}
//
//
///*********************************
//* Main is pretty sparse.  Just initialize
//* the game and call the display engine.
//* That is all!
//*********************************/
//int main(int argc, char ** argv)
//{
//	Interface ui(argc, argv, "Moon Lander");
//	Game game;
//	ui.run(callBack, &game);
//
//	return 0;
//}
