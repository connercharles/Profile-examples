#ifndef ASTEROID_H
#define ASTEROID_H

#include "flyingobject.h"

class Asteroid : public FlyingObject
{
private:
	int size;

	void fall();

public:
	Asteroid();
	~Asteroid();

	// Getters
	int getSize() const { return size; }

	// Setters
	void setSize(int size);

	void draw();

};

#endif