/***********************************************************************
* Source File:
*    Lander : The representation of the lander on the screen
* Author:
*    Conner Charles
* Summary:
*    This is the lander.cpp file where all the lander's methods are called
*	 The lander is able to thrust fire left, right, and down. It checks to 
*	 make sure the lander has enough fuel, advances the lander, and draws
*	 it.
************************************************************************/

#include "Lander.h"
#include "uiDraw.h"

int Lander::consumeSides = 1;
int Lander::consumeBottom = 3;

// Each level's gravity
const float Lander::MOONGRAVITY = -.1;
const float Lander::MARSGRAVITY = -.2;

// Normal velocity
const float Lander::MOVE_LEFT = .1;
const float Lander::MOVE_RIGHT = -.1;
const float Lander::MOVE_UP = .3;

/******************************************
* LANDER : Consume Fuel
* Takes passed in amount and subtracts from fuel amount.
* Then sets the new amount as the new fuel amount.
*****************************************/
void Lander::consumeFuel(int amount)
{
	setFuel(fuel - amount);
}

/******************************************
* LANDER : Reset Lander
* Resets the lander variables to ready it
* for the next level.
*****************************************/
void Lander::resetLander()
{
	Point newPoint(180, 180);
	setPoint(newPoint);
	setFuel(500);
	setLanded(false);

	Velocity newVelocity(0, 0);
	setVelocity(newVelocity);
}

/******************************************
* LANDER : CONSTRUCTOR
* Sets the default values of lander variables.
*****************************************/
Lander::Lander() : point(180, 180)
{
	fuel = 500;
	alive = true;
	landed = false;	
}

/******************************************
* LANDER : Set Point
* Sets passed in point value as new value.
*****************************************/
void Lander::setPoint(Point point)
{
	this->point = point;
}

/******************************************
* LANDER : Set Velocity
* Sets passed in velocity value as new value.
*****************************************/
void Lander::setVelocity(Velocity velocity)
{
	this->velocity = velocity;
}

/******************************************
* LANDER : Set Fuel
* Sets passed in fuel value as new value.
*****************************************/
void Lander::setFuel(int fuel)
{
	this->fuel = fuel;
}

/******************************************
* LANDER : Set Alive
* Sets passed in alive value as new value.
*****************************************/
void Lander::setAlive(bool alive)
{
	this->alive = alive;
}

/******************************************
* LANDER : Set Landed
* Sets passed in landed value as new value.
*****************************************/
void Lander::setLanded(bool landed)
{
	this->landed = landed;
}

/******************************************
* LANDER : Can Thrust
* Checks lander fuel to see if it is possible to thrust.
*****************************************/
bool Lander::canThrust(bool isBottom) const
{
	// Will need to change it is the bottom thruster
	if (isBottom)
	{
		if (getFuel() >= 3) // 3 b/c thrusting bottom decreases by 3
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	else if (getFuel() > 0) // If you are out of fuel
	{
		return true;
	}
	else
	{
		return false;
	}
}

/******************************************
* LANDER : Apply Gravity
* Applies passed in value of gravity to Lander.
* Should be a negative number!
*****************************************/
void Lander::applyGravity(float gravity)
{
	velocity.addOntoDy(gravity);
}

/******************************************
* LANDER : Apply Thrust Left
* Shoots fire on the left side and pushes the 
* lander's inertia to the right.
*****************************************/
void Lander::applyThrustLeft()
{
	if (canThrust(false))
	{
		velocity.addOntoDx(MOVE_LEFT);
		consumeFuel(consumeSides);
		drawLanderFlames(point, false, true, false);
	}
}

/******************************************
* LANDER : Apply Thrust Right
* Shoots fire on the right side and pushes the
* lander's inertia to the left.
*****************************************/
void Lander::applyThrustRight()
{
	if (canThrust(false))
	{
		velocity.addOntoDx(MOVE_RIGHT);
		consumeFuel(consumeSides);
		drawLanderFlames(point, false, false, true);
	}
}

/******************************************
* LANDER : Apply Thrust Bottom
* Shoots fire on the botton and pushes the 
* lander's inertia up.
*****************************************/
void Lander::applyThrustBottom()
{
	if (canThrust(true))
	{
		velocity.addOntoDy(MOVE_UP);
		consumeFuel(consumeBottom);
		drawLanderFlames(point, true, false, false);
	}
}

/******************************************
* LANDER : Advance
* Checkes to see what level the user is on
* then it calls on the movement of the lander
* and the gravity that applies to the level.
*****************************************/
void Lander::advance(int &gameLevel)
{
	switch (gameLevel)
	{
	case 1:
		applyGravity(MOONGRAVITY); // B/c we're on the moon.
		point.addX(velocity.getDx());
		point.addY(velocity.getDy());
		break;
	case 2:
		applyGravity(MARSGRAVITY); // B/c we've finally made it to mars.
		point.addX(velocity.getDx());
		point.addY(velocity.getDy());
		break;
	case 3:
		applyGravity(MOONGRAVITY); // Back to normal gameplay.
		point.addX(velocity.getDx());
		point.addY(velocity.getDy());
		break;
	default:
		break;
	}
}

/******************************************
* LANDER : Draw
* Draws the lander using its' center point.
*****************************************/
void Lander::draw() const
{
	drawLander(point);
}
